﻿var Connectors = []
var CustomConnectors = []
var gPages = [];
var knowdldebugMode = false;
var gTemplates = [];


var gCaseId = '';
var gPulishedVersionId = '';
var gCaseTitle = '';
var gPackageType = '';
var gScoringToolFormat = {}
var gCaseProperties = {}
var gVideoLibraryEntries = []
var MenuData = [];
var gAllowEdit = 'false';
var knowdlBaseUrl = '';
//knowdlBaseUrl = knowdlBaseUrl.replace("https://", "http://");
//replace these value using theme values
var BreakPoint_LOW = 300;
var BreakPoint_MEDIUM = 600;
var BreakPoint_HIGH = 1024;
//Anu 29-apr-2015 score for scorecard parameter
var gSimScore = {};
var gPageScore = {};
var gTotalSimScore = 0;

var g_GroupScoreArray = [];

var gActionScoreTracking = false;
var ContainerPixelWidth = 974;

//2-apr-2014 Additional res open effect
var AdditionalResSlideScrn = 'SideScreen';
var AdditionalResFullScrn = 'FullScreen';
var AdditionalResOpenType = AdditionalResFullScrn;
//END

var gEarlierPgId = -1;
var gRankedOptionIdArray = [];
var responsesArr = [];

var gNextPageId = "";
var gCurrPageObj;
var gCurrPageIndex = 1;
var gPrevPageIdArray = [];
var gSelectedOptionId = "";
var gRanTempArray = [];
var iPadClickStatus = "";
var isSwipeRequired = "";
var rmpanelOpen = "false";

var gNavigatedPageIds = "";
var gReviewMode = "false";

var gTotalScore = [];
var gTotalScoreMode = "false";
var gCurrentScore = [];
var gTotalScorePgArray = [];

var gPollResult = [], gAssessmentResult = [];
//30-oct-2014-Anu-poll-chart-
var gPreviewOrPublish = ''; //Preview or Publish
var gLoggedInUserId;
var gPollStartTime = new Date();
//
var ElapsedTime = new Date().getTime();
var ShowResponseResult = false;
var gOptLables = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
var gRomanLabels = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII", "XIII", "XIV", "XV"]
var knowdl_scorm_package_id = '';

var gRMID = '';
var gRMAttemptData = {};
var gRevelProvider = "KnowdlIT";

//AR 19 May 2015 - Temperory aray for question titles, should pick the aray from page script
var questionShortTitles = ["Choose Your Processor", "How Much RAM?", "Size of Hard Drive", "External Storage", "Optical Storage", "Communication Devices", "Audio Devices", "Video Output Options", "Video Output Options", "Input Devices", "Input Devices", "Output Devices"];
var baseUnitName = "";
var totalValue = "";
var gLicenseId = '';

// SCRORM object
var lms_studentId;
var lms_studentName;
var lms_timeSpent;
var lms_suspendData;
var lms_completionstatus;
var lms_lessonlocation;
var lms_score;
var lms_mode;

var gPageTransitionDuration = 500;
//anu 18-feb-2015 droppable component
// below flag used goto next page after pop up close in droppable component case
var gotoNextPageFlag = false;
//RA 04June2015 - to check whether the browser is IE11 or not
var isIE11version = !!navigator.userAgent.match(/Trident.*rv\:11\./);
var gThemeId;
var gThemeProperties;
var isSPP = false; //for single page preview
var gFirstLoadFlag = true;
$(window).unload(function () {
    fUpdateAttemptDetails();
});


$('.disabled').live('click', function (event) {
    event.preventDefault();
    return false;
});
//deva 09June2015 - to resolve IE11 scroll issue on loading first time
$.fn.preload = function () {
    this.each(function () {
        //$('<img/>')[0].src = this;
        JSAsyncCall(this.toString());
        //console.log(this.toString() + " Loaded");
    });
}
$.fn.preloadVid = function () {
    this.each(function () {
        //$('<video/>')[0].src = this;
        JSAsyncCall(this.toString());
        //console.log(this.toString() + " Loaded");
    });
}
function addSourceToVideo(element, src, type) {
    var source = document.createElement('source');
    source.src = src;
    source.type = type;
    element.appendChild(source);
}
//var deva_video;
$(window).on("orientationchange", function () {
    /*if ((screen.availHeight || screen.height - 30) <= window.innerHeight) {
        // browser is almost certainly fullscreen
        return;
    }*/
    //availWidth on apple devices always shows potrait width.
    //alert("On orientation change: Screen avail width is - " + k_DeviceManager.GetClientWidth());
    //alert("On orientation change: Screen avail width is - " + window.innerWidth);
    setTimeout(function () {
        k_windowResize(k_DeviceManager.GetClientWidth());
    }, 300)
});
$(document).ready(function () {
	if(isIE11version == true ){
		$("body").attr("browser","ie11");
	}
	else if((/Firefox[\/\s](\d+\.\d+)/.test(navigator.userAgent)))
	{
		$("body").attr("browser","ff");
	}
	else if(navigator.vendor.indexOf("Apple")==0 && /\sSafari\//.test(navigator.userAgent))
	{
		$("body").attr("browser","safari");
	}

    //$("#restOftheContent").addClass("prevWrapperBorder")
    if (IsPreview())//gp 26-08-2015 added for quick preview
    {
        top.$("#divPagePreview").hide();
        top.$("#divMapPagePreview").hide();//Anu 28-feb-2017
        //top.$("#divPagePreview").find(".loader").hide();  /*DDeva:20/07/16*/
        var RMDisplayName;
        gPreviewOrPublish = 'Preview';
        var ifrm = parent.GetActiveTabiFrame();
        var Hpp = getParameterByName("HPP");
        var spp = getParameterByName("SPP"); //gp 7 sept 2015 added condition for single page preview
        if (spp != undefined && (spp == true || spp == "true")) {
            isSPP = true;
        }//Anu 11-nov-2016 map refinements
        else {
            spp = false;
        }
        if (!spp) {
            var caseId = getParameterByName("CaseId");
            var fileName = getParameterByName("FileName");
            //Anu 11-nov-2016 map refinements
            if (fileName != undefined && fileName != "") {
                $("<script/>", {
                    type: "text/javascript",
                    src: "/PreviewCases/" + caseId + "/" + fileName + ".js",
                }).appendTo("head");
            }
        }

        // preview from case listing page
        if (Hpp != undefined && (Hpp == "true" || Hpp == true)) {
            Connectors = previewConnectors;
            CustomConnectors = previewCustomConnectors;
            gPages = previewPages;
            MenuData = previewMenuData;
            gCaseTitle = previewCaseTitle;
            AdditionalResOpenType = previewAdditionalResOpenType;
            gCaseId = previewCaseId;
            gThemeId = previewThemeId;
            RMDisplayName = previewRMDisplayName;
            gCaseProperties = previewCaseProperties;
            gLoggedInUserId = previewLoggedInUserId;
            gThemeProperties = previewThemeProperties;
            gAllowEdit = previewAllowEdit;
            gTemplates = previewTemplates;
            gScoringToolFormat = previewScoringToolFormat;
            gSimScore = previewSimScore;
            gPageScore = previewPageScore;

        }
        else {  // preview from the map page link
            gCaseId = ifrm.contentWindow.caseId;
            Connectors = ifrm.contentWindow.Connectors;
            CustomConnectors = ifrm.contentWindow.CustomConnectors;
            gCaseProperties = ifrm.contentWindow.CaseProperties;
            gThemeId = Number(ifrm.contentWindow.gThemeId)
            gThemeProperties = ifrm.contentWindow.ThemeProperties;
            gTemplates = ifrm.contentWindow.f_GetTemplateList();
            gScoringToolFormat = ifrm.contentWindow.gScoringToolFormat;
            gSimScore = ifrm.contentWindow.gSimScore;
            gPageScore = ifrm.contentWindow.gPageScore;
            MenuData = ifrm.contentWindow.MenuData;
            gCaseTitle = ifrm.contentWindow.gTempCaseTitle;
            gLoggedInUserId = ifrm.contentWindow.gLoggedInUserId;
            if (ifrm.contentWindow.RMViewMode == "Layer")
            {
                AdditionalResOpenType = AdditionalResFullScrn;
            } else {
                AdditionalResOpenType = AdditionalResSlideScrn;
            }
            gAllowEdit = ifrm.contentWindow.gAllowEdit;
            RMDisplayName = ifrm.contentWindow.RMDisplayName;
            var tmpid = getParameterByName("tmpid");
            if (tmpid != undefined && tmpid != "") {
                gPages[0] = JSON.parse(top.gLocalTemplateData.TemplateData);
            } else {
                var Spp = getParameterByName("SPP");
                if (Spp != undefined && (Spp == "true" || Spp == true)) {
                    gPages = ifrm.contentWindow.gPages;
                }
                else {
                    gPages = previewPages;
                    gCaseProperties = previewCaseProperties;
                    gThemeProperties = previewThemeProperties;
                    gTemplates = previewTemplates;
                    gScoringToolFormat = previewScoringToolFormat;
                    gSimScore = JSON.parse(previewSimScore);
                    gPageScore = JSON.parse(previewPageScore);
                    gThemeId = previewThemeId;
                }
            }
        }


            $(".BrandingBarContainer").show();
            $(".BrandingBarClone").show();
            top.$(".scriptPreviewTitle").hide();

        $(".pagingTextWrap").html("<div class='pagingText'></div>");
        $(".CaseTitle").html("<p style='text-align:center'>###CaseTitle###</p>");
        if (gThemeId < 0) {//apply default theme
            $("<link/>", {//append theme
                rel: "stylesheet",
                type: "text/css",
                href: "/themes/themedefault/theme.css?nm=" + Math.random()
            }).appendTo("head");
            $("<link/>", {//append theme
                rel: "stylesheet",
                type: "text/css",
                href: "/themes/themedefault/casestyles.css?nm=" + Math.random()
            }).appendTo("head");
        }
        else//apply theme css
        {
            $("<link/>", {//append theme
                rel: "stylesheet",
                type: "text/css",
                href: "/themes/" + gThemeId + "/theme.css?nm=" + Math.random()
            }).appendTo("head");
            $("<link/>", {//append theme
                rel: "stylesheet",
                type: "text/css",
                href: "/themes/" + gThemeId + "/theme.css?nm=" + Math.random()
            }).appendTo("head");
            $("<link/>", {//append theme
                rel: "stylesheet",
                type: "text/css",
                href: "/themes/" + gThemeId + "/casestyles.css?nm=" + Math.random()
            }).appendTo("head");
            if (gThemeProperties != undefined) {
                if (gThemeProperties.Case_Title_Format != undefined && gThemeProperties.Case_Title_Format != "") {
                    var caseTitle = gThemeProperties.Case_Title_Format.replace("<p", "<div class='cke_format_wrap' ").replace("</p>", "</div>").replace("Set format for case title", "###CaseTitle###")
                    $(".CaseTitle").html(caseTitle);
                }
                if (gThemeProperties.Case_BodyText != undefined) {
                    var QResults = gThemeProperties.Case_BodyText.replace("<p", "<div class='cke_format_wrap' ").replace("</p>", "</div>").replace("Set format for body text", "###QResults###")
                    $(".qresults").html(QResults);
                }
                if (gThemeProperties.Case_PagerText != undefined && gThemeProperties.Case_PagerText !=  "") {
                    var pageText = gThemeProperties.Case_PagerText.replace("<p>", "<div class='cke_format_wrap' ").replace("</p>", "</div>").replace("Set format for page #", "<div class='pagingText'></div>")
                    $(".pagingTextWrap").html(pageText);
                }
                if (gThemeProperties.Case_FooterText != undefined) {
                    $(".footer").html(gThemeProperties.Case_FooterText);
                    $(".footer").removeClass("disNone");
                }
                BreakPoint_LOW = gThemeProperties.BreakPoint_LOW;
                BreakPoint_HIGH = gThemeProperties.BreakPoint_HIGH;
                BreakPoint_MEDIUM = gThemeProperties.BreakPoint_MEDIUM;
            }
        }
        if (RMDisplayName != undefined) {
            $(".RMSliderLink a span").html(RMDisplayName);
        }
        var btnSeq = null;
        if (gThemeId > 0 && gThemeProperties != undefined && gThemeProperties != null && gThemeProperties.Button_Sequence != undefined && gThemeProperties.Button_Sequence != null) {
            btnSeq = gThemeProperties.Button_Sequence;
        }
        SetButtonSequence(btnSeq, RMDisplayName);
        $("#bodyTextThemeFormat").html("Set format for body text");
        $("#ElementDescription").html("Set format for description text");
        //DDeva:30/05/16 -Screen resolution fill dropdown
        k_DeviceManager.Init({ IsResponsive: gCaseProperties.IsResponsive, isPlayer: true,isPreview:true });
        var arrResolns = k_DeviceManager.GetDevices();
        var $select = top.$("#selResoDD");
        $select.empty();
        $.each(arrResolns, function (key, value) {
            $select.append('<option value=' + value.Id + '>' + value.Name + '</option>');
        });
        //DDeva:03/06/16-set user selected resolution else default
        var scrnreso = getParameterByName("scrnreso");
        scrnreso = (scrnreso == undefined || scrnreso == "") ? "default" : scrnreso;
        $select.val(scrnreso).trigger('change');
        //$("#restOftheContent").css('margin-top', 39);
        k_DeviceManager.IdentifyModeAndUpdatePlayerLayout(k_DeviceManager.GetClientWidth(), Number(gCaseProperties.StageSize))
    }
    else {

        $("#BrandingButtonBar").hide();
        //DDeva:20/07/16
        try {
            top.$("#divPagePreview").hide();
            top.$("#divMapPagePreview").hide();//Anu 28-feb-2017
        } catch (d) { }
        //nav-device 02 june 16 - not required to call when preview.
        //alert("On Document Ready: Screen avail width is - " + k_DeviceManager.GetClientWidth());
        k_DeviceManager.Init({ IsResponsive: gCaseProperties.IsResponsive, isPlayer: true });
        //k_DeviceManager.IdentifyModeAndUpdatePlayerLayout(k_DeviceManager.GetClientWidth(), Number(gCaseProperties.StageSize))
    }

    iPadClickStatus = getParameterByName("iPadClickStatus");
    isSwipeRequired = getParameterByName("isSwipeRequired");
    if (iPadClickStatus == "true") {
        removeHover();
    }

    // for iPad - Not inside iPadClickStatus check, as required when access on ipad in browser.
    $.getScript('content/scripts/jquery.ui.touch-punch.min.js', function (data, textStatus, jqxhr) {
        setTimeout(setDropAction, 2000)
        // setDropAction();
    });

    $(".wrapper").css("overflow", "hidden");
    //Get local ipaddress and location in javascript.
    try {
        /*if (top.document.location.href.indexOf('https://') == -1) {
            if (gRMID != undefined && gRMID != null && gRMID != "") {
                //$.getJSON("http://www.telize.com/geoip?callback=?",
                $.getJSON("http://ip-api.com/json?callback=?",
                function (json) {
                    //alert(json.ip + " - " + json.country + " - " + json.latitude + " - " + json.longitude);
                    if (gRMAttemptData == undefined) gRMAttemptData = {};
                    gRMAttemptData.ISP_IPAddress = json.query;
                    gRMAttemptData.Location = json.city + ", " + json.country;
                });
            }
        }*/
    }
    catch (s) { }

 /*   if (IsPreview()) {
        $(".PreviewClose").show();
        //Naveen - Added Search box to map  if it is not preview.
        //Also changed to add search in branding bar and not in clone.
        //Anu 25-feb-2015 if case is locked by other author then not allow edit though logged in user is editor
        var mode = getParameterByName("MODE");
        if (gAllowEdit == "true" && mode == '' && !isSPP) {
            var brandingBarContainer = $(".BrandingBarContainer");
            brandingBarContainer.find(".BrandingButtonBar").append("<div class='EditPage'> <a href='javascript:void(0)'>Edit this page</a></div> ");
            brandingBarContainer.find(".BrandingButtonBar").append("<div class='SearchPageContent'><input id='ipSearchBox' placeholder='Search' type='text' style='width:125px;height:20px;border:0;padding-left:5px;' class='ipSearchBoxDefault'/><span class='searchIcon seachIcondisplaynone'></span><br /> <div id='divSearchhResult' style='width:427px;max-height:575px; overflow-x:hidden;overflow-y:auto;display:none;'></div> </div>");
            brandingBarContainer.find(".EditPage").show();
            brandingBarContainer.find(".SearchPageContent").show();
        }

    }*/

    $("#mapAreaHeader").append("<div class='SearchPageContent'>" +
                    "<input id='ipSearchBox' placeholder='Search' type='text' style='width:125px;height:20px;border:0;padding-left:5px;' class='ipSearchBoxDefault'/>" +
                    "<span class='searchIcon seachIcondisplaynone'></span><br />" +
                    "<div id='divSearchhResult' style='width:427px;max-height:575px; overflow-x:hidden;overflow-y:auto;display:none;'></div> </div>");

    $(".SearchPageContent").show();


    if (gPages.length > 0) {

        //Set Case Title
        var caseTitle = $(".CaseTitle");
        caseTitle.html(caseTitle.html().replace("###CaseTitle###", gCaseTitle));
        caseTitle.attr('title', gCaseTitle);

        $(".ChapterPanelPlayer").hide();
        $(".templateScoringTool").hide();
        $(".ScoringToolWrap").hide();
        if (gScoringToolFormat != undefined && gScoringToolFormat != null) {
            if (gScoringToolFormat.ActionTracking != undefined && gScoringToolFormat.ActionTracking != null && gScoringToolFormat.ActionTracking != false) {
                gActionScoreTracking = true;
                $("#ScoringTool").hide();
            }
            else if (gScoringToolFormat.ScoringToolDetails != undefined && gScoringToolFormat.ScoringToolDetails != null && gScoringToolFormat.ScoringToolDetails.length > 0) {
                $("#ScoringTool").html(gScoringToolFormat.Title);
            }
        }

        if (gCaseProperties != undefined) {
            if (!gCaseProperties.ShowMap) {
                $(".AlgoMapWrap").hide();
            }
            if (!gCaseProperties.ShowVideoLibrary) {
                $(".AlgoVideoLibraryWrap").hide();
            }
            if (!gCaseProperties.ShowMenu) {
                $(".MenuIconWrap").hide();

            }
            if (!gCaseProperties.ShowPagingText) {
                $(".pagingTextWrap").hide();
            }
            if (!gCaseProperties.ShowHome) {
                $(".HomeIconWrap").hide();
            }

        }

        var spp = getParameterByName("SPP");
        if (spp != undefined && (spp == true || spp == "true")) {
            $("#HomeIcon").addClass("disabled");
            $("#VideoLibIcon").addClass("disabled");
            $("#AlgoMap").addClass("disabled");
            $("#InfoIcon").addClass("disabled");
            $("#PrevPage").addClass("disabled");
            $("#NextPage").addClass("disabled");
            $("#ChapterMenu").addClass("disabled");
            //$(".ChapterSliderLink a").addClass("disabled");
        }

        var hpp = getParameterByName("HPP");
        if (hpp != undefined && (hpp == true || hpp == "true")) {
            $(".PreviewMap").show();
        }

        gReviewMode = getParameterByName("RevMode");
        var gBookmarkedPageId = Number(getParameterByName("BM"));
        // Rahul 03March-2015 Scorm 2004 Update
        if (gPackageType != 'SCORM 1.2' && gPackageType != 'SCORM 2004') {
            if (gBookmarkedPageId == 0 || gBookmarkedPageId == 1 || gBookmarkedPageId == null || typeof (gBookmarkedPageId) === 'undefined') {
                setTimeout(fStart, 300);
                //gNavigatedPageIds = "";
            }
            else {
                if (gReviewMode == "true" || gReviewMode == "") {
                    if (confirm('Are you sure you want to start from bookmarked page?')) {
                        //gNavigatedPageIds = getParameterByName("NPIds");
                        setTimeout(fStart(gBookmarkedPageId), 300);
                    }
                    else {
                        setTimeout(fStart, 300);
                        //gNavigatedPageIds = "";
                    }
                }
                else {
                    setTimeout(fStart, 300);
                    //gNavigatedPageIds = "";
                }
            }
        }
    }
    else {
        top.$.fancybox.close();
    }

    /*$('#contentContainer').css('marginTop', $('#BrandingBarContainer').outerHeight(true));*///naveen- commented as it is not working. Need "margin-top".
    var lnvgbtncontainer = $(".nvgbtncontainer");
    if ($(".ReferenceIconWrap").is(":visible")) {
        var widthToIncrease = 265
        //if ($(".GlossaryIconWrap").is(":visible")) {//gp commented  for glossary
        //    //lnvgbtncontainer.css("width", lnvgbtncontainer.width() + 40);
        //    widthToIncrease = widthToIncrease + 40
        //}
        if ($(".ReferenceIconWrap").is(":visible")) {
            //    lnvgbtncontainer.css("width", lnvgbtncontainer.width() + 40);
            widthToIncrease = widthToIncrease + 40
        }
        lnvgbtncontainer.css("width", lnvgbtncontainer.width() + widthToIncrease);
    }

    //24-nov-2014-Anu-ARS
    if (gPackageType == 'ARS_PowerVote-v2.1') {
        //$("#Template_DTP").append($('<input type=button id="StartPV" onclick="StartPVNow()" value="Start voting"/>&nbsp;<input type=button id="StopPV" onclick="StopPVNow()" value="Stop voting"/>&nbsp;<input type=button id="ShowPV" onclick="ShowPVResult()" value="Show result"/>'));
        $("#Template_DTP").append($('<div id="VotingDiv" style="margin-left: 30%;top: 92%;position: absolute;z-index: 2000;"> <div style="border: 1px solid #717171;background-color: #EEE;width: 220px;padding: 5px;"> <input id="btnStart" type="button" value="Start" onclick ="StartPVNow()" class="timerBtn"/> <input id="btnStop" type="button" value="Stop" disabled="disabled" onclick="StopPVNow()" class="timerBtn" /> <input id="btnResults" type="button" value="Results" style="width:75px" disabled="disabled" onclick="ShowPVResult()" class="timerBtn" /> </div> <div id="divJsTimer" style="margin-top: 2px;"> Time elapsed: <span id="lblTimeElapsed" style="text-align: center;"></span> <br> Votes Received: <label id="lblResults">0</label> </div> </div>'));
    }
    else {
        /*
        var mq1 = window.matchMedia("(max-width: " + BreakPoint_LOW + "px)");
        mq1.addListener(function (changed) {
            ExecuteMatchPointCode();
        });
        var mq2 = window.matchMedia("(max-width: " + BreakPoint_MEDIUM + "px)");
        mq2.addListener(function (changed) {
            ExecuteMatchPointCode();
        });
        var mq3 = window.matchMedia("(max-width: " + BreakPoint_HIGH + "px)");
        mq3.addListener(function (changed) {
            ExecuteMatchPointCode();
        });
        */
        }

    // remove footer if theme does not specify anything
    if ($(".footer").text().trim() == "") {
        $(".footer").remove();
    }

    setTimeout(callafterTenSec, 5000);

    $("#divPlayerLoader").hide();

    /*IE 11 and lower having issue for responsive case. AdjustPosition() receiving unexpected value for image
    on first time loading and so extra space added between components, as below style was in css and so it is moved
    to document.ready function here in player. */
    if(k_DeviceManager.Is_IE11_and_Lower()){
        setTimeout(function(){
            var navfromstylecss = ".k-element-image, .k-element-image-clone {width:100%;height:100%;}";
            var htmlDiv = document.createElement('style');
            htmlDiv.innerHTML = navfromstylecss;
            document.getElementsByTagName('head')[0].appendChild(htmlDiv);
        },500);
    }
    else{
        var navfromstylecss = ".k-element-image, .k-element-image-clone {width:100%;height:100%;}";
        var htmlDiv = document.createElement('style');
        htmlDiv.innerHTML = navfromstylecss;
        document.getElementsByTagName('head')[0].appendChild(htmlDiv);
    }
    //End IE 11 and Lower first time loading issue for responsive case.
   if(IsRevel()){
        $("<script/>",{
            type: "text/javascript",
            src: "/content/revelsims/commonfiles/Revel.js"
        }).appendTo("head");
   }
});
//NM-document.ready end
function callafterTenSec()
{

    //deva 09June2015 - to resolve IE11 scroll issue on loading first time
    // this will not work as the pagecontent.text is removed while packaging
    // if we load pagecontent.text from js file, this code will load all pages data which will affect performance.
    // ** need to relook at this later
    var _gPgs = $(gPages), imgArr = [], vidArr = [];
    for (var cntr = 0, tot = _gPgs.length; cntr < tot; cntr++) {
        // pre-cache the pageId.js files
        if (!IsPreview()) {
            PgContentCacheJSAsyncCall("content/scripts/JSONData/" + _gPgs[cntr].PageId + "Text.js");
            if (_gPgs[cntr].IsScriptAdded !== undefined && _gPgs[cntr].IsScriptAdded == true) {
            JSAsyncCall("content/scripts/JSONData/" + _gPgs[cntr].PageId + "Script.js");
            }
            if (_gPgs[cntr].IsMCQDetailAdded !== undefined && _gPgs[cntr].IsMCQDetailAdded == true) {
            JSAsyncCall("content/scripts/JSONData/" + _gPgs[cntr].PageId + "MCQArray.js");
            }
            if (_gPgs[cntr].IsReferencesAdded !== undefined && _gPgs[cntr].IsReferencesAdded == true) {
            JSAsyncCall("content/scripts/JSONData/" + _gPgs[cntr].PageId + "References.js");
            }
        }
        if (_gPgs[cntr].PageContent != undefined && _gPgs[cntr].PageContent.Text != undefined) {
            $(_gPgs[cntr].PageContent.Text).find('img').each(function () {
                if (this.src != "") {
                    if ($.inArray(this.src, imgArr) == -1) {
                        imgArr.push(this.src);
                    }
                }
            });
            $(_gPgs[cntr].PageContent.Text).find('.k-element-video').each(function () {
                var fsrc = $(this).attr('fsrc');
                if (fsrc != "") {
                    if ($.inArray(fsrc, vidArr) == -1) {
                        vidArr.push(fsrc);
                        //deva_video = document.getElementsByTagName('video')[0];
                        //addSourceToVideo(deva_video, fsrc, "video/mp4");
                        //deva_video.addEventListener("progress", vidProgressHandler, false);
                    }
                }
            });
        }
    }

    // Usage:

    $(imgArr).preload();
    $(vidArr).preloadVid();
    //end

}

function ExecuteMatchPointCode() {
    var contentArea = $(".ContentArea");
    /*DDeva:�v3.1.0:slide in nav menu*/
    var devicewidth = BreakPoint_HIGH; //contentArea.width();
    var col_org_wd, col_org_ht, col_cal_wd, col_cal_ht;

    contentArea.find(".column").each(function () {
        var ths_column = $(this);
        col_org_wd = ths_column.attr("ow");
        col_org_ht = ths_column.attr("oh");
        col_cal_wd = getPerc(col_org_wd, devicewidth);

        if (parseInt(col_org_wd) > parseInt(devicewidth)) {
            col_cal_ht = 100 * col_org_ht / col_org_wd;
            ths_column.css({
                "width": "100%"
                //, "height": ""
		    , "position": "relative"
                //, "padding-top": col_cal_ht + "%"
            });
        }
        else {
            col_cal_ht = col_cal_wd * col_org_ht / col_org_wd;
            ths_column.css({
                "width": col_cal_wd + "%"
                //, "height": col_cal_ht + "%"
		    , "position": "relative"
                //, "padding-top": col_cal_ht + "%"
            });
        }
    });

    contentArea.find(".TvidArea").each(function () {
        var ths_column = $(this);
        col_org_wd = ths_column.css("width");
        col_org_ht = ths_column.css("height");
        col_cal_wd = getPerc(col_org_wd, devicewidth);
        if (parseInt(col_org_wd) > parseInt(devicewidth)) {
            col_cal_ht = 100 * col_org_ht / col_org_wd;
            ths_column.css({
                "width": "100%"
		    , "height": ""
		    , "position": "relative"
		    , "padding-top": col_cal_ht + "%"
            });
            $(".TvideoDescription").css({
                "width": "100%"
            });
        }
        else {
            col_cal_ht = col_cal_wd * col_org_ht / col_org_wd;
            ths_column.css({
                "width": col_cal_wd + "%",
                "height": col_cal_ht + "%"
		    , "position": "relative"
		    , "padding-top": col_cal_ht + "%"
            });
        }
    });
}

$("#AlgoMap").live("click", function () {
    if ($(this).hasClass("disabled")) {
        return;
    }
    else {
        launchreadonlymap();
    }
});

$(".PreviewMap a").live("click", function () {
    if ($(this).hasClass("disabled")) {
        return;
    }
    else {
        launchreadonlymap();
    }
});

var mapCanvas_graphics;
function launchreadonlymap(sPreview) {
    //Rahul 23-Feb-2015 to update map height according to window height
    var windowHeight = $(window).height();
    var brandingbarHeight = $(".BrandingBarContainer").height();
    var mapArea = $("#mapArea");
    var mapCanvas = $("#mapCanvas");
    //mapCanvas.css({ "height": (windowHeight - (brandingbarHeight+2)) + "px" });

    //Naveen - Removed iframe and added inline div.
    $("#mapcanvasContainer").show();
    if (mapArea.find("div[pagetype]").length <= 0) {
        mapCanvas_graphics = new Graphics('mapArea');
        InitCanvas(sPreview);
        //mapArea.css({ "height": ($('#mapCanvas')[0].scrollHeight + 100) + "px", "width": ($('#mapCanvas')[0].scrollWidth + 100) });
    }
    else {
        //reset zoom on relaunch
        mapArea.find("div[pagetype]").removeClass("selected");
        mapArea.find("#div_" + gCurrPageObj.PageId).addClass("selected");
        $('#zoomSliderTextBox').val(100);
        ZoomContent(100);

    }
    if (navigator.userAgent.indexOf("Firefox") == -1) {
        mapCanvas.css({ "overflow": "auto" })
        //mapCanvas.find(".nicescroll-rails").remove();
        //mapCanvas.niceScroll({ autohidemode: false });
    }
}

$("#ScoringTool").live("click", function () {
    var isVisible = $(".templateScoringTool").is(":visible");
    if (!isVisible) {
        $(".templateScoringTool").fadeIn("slow");
        $(".ScoringToolWrap").fadeOut();
    }
    else {
        $(".templateScoringTool").fadeOut("slow");
        $(".ScoringToolWrap").fadeIn();
    }
    checkTheme(gCurrPageObj);
});

$(".templateScoringTool .closeScoringTool").live("click", function () {
    $(".templateScoringTool").fadeOut("slow");
    $(".ScoringToolWrap").fadeIn();
    checkTheme(gCurrPageObj, "None");
    //$(".nvgbtncontainerwrapper").css({ "height": "30px" });
});

$("#HomeIcon").live("click", function () {
    if ($(this).hasClass("disabled")) return;
    closeAllPopups()
    fHome();
});

$("#InfoIcon").live("click", function () {
    if ($(this).hasClass("disabled")) return;
});

function setXcodeCloseStatus() {
    setXcodeStartStatus();
}

function setXcodeStartStatus() {

    iPadClickStatus = "true";
    /*if (isSwipeRequired != "false") {
        $.getScript('content/scripts/jquery.mobile-1.3.2.min.js', function (data, textStatus, jqxhr) {
            // do some stuff after script is loaded
            //setSwipeAction();
            setTimeout(setSwipeAction, 2000);
        });
        $.getScript('content/scripts/jquery.mobile-1.4.0-alpha.2.min.js', function (data, textStatus, jqxhr) {
            //  setSwipeAction();
        });
        $.getScript('content/scripts/jquery.ui.touch-punch.min.js', function (data, textStatus, jqxhr) {
            setTimeout(setDropAction, 2000)
            // setDropAction();
        });
    }
    var cssLink = $("<link rel='stylesheet' type='text/css' href='content/styles/styles-ipad.css'>");
    $("head").append(cssLink);
    */
}

function sendXcodeAttemptData() {
    var attemptData = "";
    if (gRMAttemptData.PostStatus == "Failed") {
        attemptData = JSON.stringify(gRMAttemptData);
    }
    return attemptData;
}

function setSwipeAction() {
    $(".wrapper").on("swipeleft", function () {
        if ($("#NextPage").hasClass('disabled') === true || $("#NextPage").hasClass('customNext') === true) {
            return false;
        } else {
            if (gCurrPageObj.PageType != "RNP" && rmpanelOpen == "false") {
                gotoNextPageFlag = false;//Anu 18-feb-2015 droppable component
                closeAllPopups();
                if (iPadClickStatus == "true") {
                    $(".ContentArea").animate({
                        opacity: 0
                    }, gPageTransitionDuration, "linear", function () {
                        fNext();
                    });

                } else {
                    $(".ContentArea").animate({
                        opacity: 0
                    }, gPageTransitionDuration, "linear", function () {
                        fNext();
                    });
                }
            }
        }
    });

    $(".wrapper").on("swiperight", function () {
        if ($("#PrevPage").hasClass('disabled') === true) {
            return false;
        } else {
            if (gCurrPageObj.PageType != "RNP" && rmpanelOpen == "false") {
                gotoNextPageFlag = false;//Anu 18-feb-2015 droppable component
                closeAllPopups();
                if (iPadClickStatus == "true") {
                    $(".ContentArea").animate({
                        opacity: 0
                    }, gPageTransitionDuration, "linear", function () {
                        fPrev();
                    });

                } else {
                    $(".ContentArea").animate({
                        opacity: 0
                    }, gPageTransitionDuration, "linear", function () {
                        fPrev();
                    });
                }
            }
        }
    });
}

function swipeLeftAction() {
    if ($("#NextPage").hasClass('disabled') === true || $("#NextPage").hasClass('customNext') === true) {
    	if (typeof swipeCustomLeftAction == 'function') {
                swipeCustomLeftAction();
         }
        return false;
    } else {
        if (gCurrPageObj.PageType != "RNP" && rmpanelOpen == "false") {
            gotoNextPageFlag = false;//Anu 18-feb-2015 droppable component
            closeAllPopups();
            if (iPadClickStatus == "true") {
                $(".ContentArea").animate({
                    opacity: 0
                }, gPageTransitionDuration, "linear", function () {
                    fNext();
                });

            } else {
                $(".ContentArea").animate({
                    opacity: 0
                }, gPageTransitionDuration, "linear", function () {
                    fNext();
                });
            }
        }
    }
}

function swipeRightAction() {
    if ($("#PrevPage").hasClass('disabled') === true) {
        return false;
    } else {
        if (gCurrPageObj.PageType != "RNP" && rmpanelOpen == "false") {
            gotoNextPageFlag = false;//Anu 18-feb-2015 droppable component
            closeAllPopups();
            if (iPadClickStatus == "true") {
                $(".ContentArea").animate({
                    opacity: 0
                }, gPageTransitionDuration, "linear", function () {
                    fPrev();
                });

            } else {
                $(".ContentArea").animate({
                    opacity: 0
                }, gPageTransitionDuration, "linear", function () {
                    fPrev();
                });
            }
        }
    }
}
function setDropAction() {

    var rtpDrags = $("li.RTPDrags");
    rtpDrags.sortable();
    rtpDrags.disableSelection();
    rtpDrags.on("sortstop", function (event, ui) { });

}

$("#closePlayer").live("click", function () {
    //call to update attempt data on click.
    fUpdateAttemptDetails();
    //24-nov-2014-Anu-ARS
    if (gPackageType == 'ARS_PowerVote-v2.1') {
        window.external.closeApp();
        return;
    }
    $(".ContentArea").find("div.video-js").each(function () {
        var videoID = $(this).attr("id");
        if (videoID != undefined && videoID != null && videoID != "") {
            var myPlayer = videojs(videoID);
            myPlayer.pause();
        }
    });
    if (iPadClickStatus == "true")
        window.open("http://www.google.com");

    if (gPackageType == '' || gPackageType == 'Knowdl Platform' || gPackageType == 'Stanalone')
        parent.exitFullscreen();

    // Rahul 03March-2015 Scorm 2004 Update
    if (gPackageType == 'SCORM 1.2' || gPackageType == 'SCORM 2004') {
        end();
    }
    else {
        //closeAllPopups();
        top.$("#divCasePreviewoverlay").hide();
        //Reset overflow to scroll.
        top.$('html').css({ "overflow": "auto" });
        top.$(".templatepopup").css({ "overflow": "auto" });

        top.$("#divCasePreview").hide();
        top.$("#ifrmCasePrev").attr("src", "/map/blank.htm");
        if (gPackageType != 'Standalone' || gPackageType != "") {
            $('#CBACaseSearchForm').submit();
        }
    }

    try {
        if (gPackageType == 'Knowdl Platform') {
            //top.$.fancybox.close();
            top.$("#divCasePreviewoverlay").hide();
            //Reset overflow to scroll.
            top.$('html').css({ "overflow": "auto" });
            top.$(".templatepopup").css({ "overflow": "auto" });
            top.$("#divCasePreview").hide();
            top.$("#ifrmCasePrev").attr("src", "/map/blank.htm");
        }
        else if (gPackageType == 'Standalone') {
            if (top.$.fancybox.close === undefined) {
                window.close();
            }
            else {
                top.$.fancybox.close();
            }
        }
        else {
            var spp = getParameterByName("SPP");
            if (spp != undefined && (spp == true || spp == "true")) {
                try {
                    $.colorbox.close();
                } catch (er) {
                    top.$.colorbox.close();
                }
            }
            else {
                $.fancybox.close();
                top.$.fancybox.close();
            }
        }
    }
    catch (err) {
        try {
            window.close();
        }
        catch (err) { }
    }

    try {
        top.$.fancybox.close();
    }
    catch (err) { }
});

$(".PreviewClose a").live("click", function () {
    $(".ContentArea").find("div.video-js").each(function () {
        var videoID = $(this).attr("id");
        if (videoID != undefined && videoID != null && videoID != "") {
            var myPlayer = videojs(videoID);
            myPlayer.pause();
        }
    });
    top.$("#divCasePreviewoverlay").hide();
    //Reset overflow to scroll.
    top.$('html').css({ "overflow": "auto" });
    top.$(".templatepopup").css({ "overflow": "auto" });
    top.$("#divCasePreview").hide();
    top.$("#ifrmCasePrev").attr("src", "/map/blank.htm");
});
$(".PreviewRestart a").live("click", function () {//gp 26-08-2015 added for restarting preview
    var iframe = parent.$("#divCasePreview").find("iframe");
    if (iframe.length > 0) {
        iframe.attr('src', iframe.attr('src'));
    }
    else
    {
        location.reload();
    }
});

$("#PrevPage").live("click", function () {
    if ($(this).hasClass('disabled') === true) {
        return false;
    }
    else {
        gotoNextPageFlag = false;//Anu 18-feb-2015 droppable component
        closeAllPopups();
        if (iPadClickStatus == "true") {
            $(".ContentArea").animate({
                opacity: 0
            }, gPageTransitionDuration, "linear", function () {
                fPrev();
            });

        } else {
            $(".ContentArea").animate({
                opacity: 0
            }, gPageTransitionDuration, "linear", function () {
                fPrev();
            });
        }
    }
});

$("#NextPage").live("click", function () {
    if ($(this).hasClass('disabled') === true || $("#NextPage").hasClass('customNext') === true) {
        return false;
    }
    else {
        gotoNextPageFlag = false;//Anu 18-feb-2015 droppable component
        closeAllPopups();
        if (iPadClickStatus == "true") {
            $(".ContentArea").animate({
                opacity: 0
            }, gPageTransitionDuration, "linear", function () {
                fNext();
            });

        } else {
            $(".ContentArea").animate({
                opacity: 0
            }, gPageTransitionDuration, "linear", function () {
                fNext();
            });

        }
    }
});

$("#ResetRanking").live("click", function () {
    //LoadPageContent(gCurrPageObj);
    var contentArea = $(".ContentArea");
    LoadRNPPageContent(gCurrPageObj, contentArea);
    $("#ResetRanking").show();
});


$("#OptionSubmit").live("click", function () {
    //Anu 9-feb-2017 add feedback for dtp option
    var _opt = FindObjectInArray(gCurrPageObj.PageContent.Options, "OptionId", gSelectedOptionId);
    if (_opt != undefined && _opt != null) {
        if (_opt != undefined && $("div" + _opt.FeedbackText + "</div>").find(".k-element-box").length > 0) {
            var _cont = $("#contentContainer .ContentArea .ToptDTP");
            //nav-dtp new change
            _cont.after('<div class="ToptFeedbackDTP"></div>');

            var _dtpdiv = $(".ToptFeedbackDTP").html(_opt.FeedbackText);
            //nav - dtp new changes
            _dtpdiv.find(".k-element-box").replaceWith(_dtpdiv.find(".k-element-box").find(".k-element-text"))
            _dtpdiv.find(".qfdbktext").removeAttr("style");
            //end
            _dtpdiv.find(".k-element-text").attr("contenteditable", "false");
            _dtpdiv.find(".k-element-strip").remove();
            _dtpdiv.find(".k-asset-Resize").remove();
            _dtpdiv.find(".block-controls").remove();
            _dtpdiv.find(".ui-resizable-handle").remove();
            _cont.find(".Options,.OptionSubmitBtn").css({ "pointer-events": "none", "background-color": "transparent", "opacity": "0.7" });

            $("body, html").animate({
                scrollTop: $(document).height()
            }, 400)

            var nextpageid = $(".ToptDTP .Options li.selected a.DTPOption").attr("nextpageid");
            if (nextpageid != undefined) {
                gNextPageId = nextpageid;
                HandleNextLink(gCurrPageObj);
            }

            if (typeof k_Cust_DTPSubmit == 'function') {
                k_Cust_DTPSubmit();
            }
            removeUIClasses();
            removeUIObjects();
            return;
        }
        else {
            fNext();
        }
    }
    else {
        fNext();
    }
});

$("#sldr").live('click', function (e) {
    e.preventDefault();
    $(".RMContainer").toggle('slow', function () {
        var w;
        if ($(this).is(':visible') === true) {
            w = Number($(".RMDisplay").width() - 215);
            $("#sldr").text('Hide');
        }
        else {
            w = Number($(".RMDisplay").width() + 215);
            $("#sldr").text('Show');
        }
        $(".RMDisplay").width(w);
        $(".RMDisplay>div img").parent().width(w - 10);
        $(".iframeCls").width(w);

    });
});

function closeAllPopups() {
    if ($("#ExtLinkDialog").hasClass('ui-dialog-content')) {
        $("#ExtLinkDialog").dialog("close");
    }
    $(".RMContentArea").hide();
    $("#RefTextDiv").hide();
}

function fHome() {
    gPrevPageIdArray = [];

    $("#PrevPage").addClass("disabled");

    gCurrPageObj = gPages[0];
    gCurrPageIndex = 1;
    gNextPageId = gCurrPageObj.NextPageId;
    //Always last statement as inside function next and prev button active is desided.
    LoadPageContent(gCurrPageObj);

    //Anu 23-feb-2015 - check if Disable Next button called func instead of inline code
    HandleNextLink(gCurrPageObj);
}

function fStart(bmPageId) {
    var flagIsFirstPage = false;
    $(".EdditPage a").attr("data-caseid", gCaseId);
    //Initialize Release Module attempt data object
    if (gRMAttemptData == undefined) gRMAttemptData = {};
    gRMAttemptData.ReleaseModuleId = gRMID;
    gRMAttemptData.AttemptId = "";
    gRMAttemptData.CurrentKnowdId = "";
    gRMAttemptData.StartTime = getFormatedDate(GetServerTimeFromLocalTime(), 4);
    gRMAttemptData.EndTime = getFormatedDate(GetServerTimeFromLocalTime(), 4);
    gRMAttemptData.Status = "In Progress";
    gRMAttemptData.AccessMode = "Browser";
    gRMAttemptData.Async = "false";
    gRMAttemptData.KnowdResponses = [];
    gRMAttemptData.TrackingData = [];

    //NM- Moved this call here before load page content.
    GetLMSDataToLocalVariables();

    var appuserid = getParameterByName("appuserid");
    if (appuserid != undefined && appuserid != null && appuserid != "") {
        gRMAttemptData.AppUserId = appuserid;
    }


    gPrevPageIdArray = [];
    var selPageId = getParameterByName("PageId");
    if (bmPageId != undefined && bmPageId != null) {
        selPageId = bmPageId;
    }
    var tmpid = getParameterByName("tmpid");
    if (selPageId != null && selPageId != "" && (tmpid == undefined || tmpid == "")) {

        gCurrPageObj = GetPage(selPageId)
        gNextPageId = gCurrPageObj.NextPageId;
        LoadPageContent(gCurrPageObj);
        //check if Disable Next button
        if (gNextPageId == "") {
            $("#NextPage").addClass("disabled");
        } else {
            $("#NextPage").removeClass("disabled");
        }
        //Check if Disable prev button.
        if (gCurrPageObj.PrevPageId == "") {
            $("#PrevPage").addClass("disabled");
        }
        else {
            $("#PrevPage").removeClass("disabled");
        }
    }
    else {
        $("#PrevPage").addClass("disabled");

        gCurrPageObj = gPages[0];
        flagIsFirstPage = true

        gNextPageId = gCurrPageObj.NextPageId;

        //Release module attempt data
        gRMAttemptData.CurrentKnowdId = gCurrPageObj.PageId;

        //Always last statement as inside function next and prev button active is desided.
        LoadPageContent(gCurrPageObj);
    }
    //NM- Moved this call to top of fstart()/ in the same function.
    //GetLMSDataToLocalVariables();

    if (getParameterByName("SPP") == "true") {
        $("#PrevPage").addClass("disabled");
        $("#NextPage").addClass("disabled");
    }
    else {
        //Anu 23-feb-2015 - check if Disable Next button called func instead of inline code
        HandleNextLink(gCurrPageObj);
    }
    if (getParameterByName("HScriptPreview") != undefined && (getParameterByName("HScriptPreview") == true || getParameterByName("HScriptPreview") == "true")) {
        //Anu 11-nov-2016 map refinements
        var mode = getParameterByName("MODE");
        if (mode != "MapPreview") {
            launchreadonlymap(true);
        }
            $("#mapcanvasContainer").css({ "width": "46%" });
           // $("#mapCanvas").css({"height":"auto"})
            $("#contentContainer").css({ "margin-left": "50%" });
            $(".nvgbtncontainer").hide();
            $(".pageWrapper").css({ "width": "100%" })
            $("#mapAreaHeader").find(".close").hide();
            //$(".BrandingBarContainer").find(".BrandingBar").hide();
            $(".sliderContainer").css({ "margin-left": "52%" });
            $(".mapArea").css({ "height": "580px" });
            top.$(".BrandingButtonBar").css({ "width": "100%" ,"margin":"0","left":"0"})
            top.$(".scriptPreviewTitle").show();
            top.$(".scriptPreviewTitle").text(gCaseTitle);
            top.$(".restartBtn").hide();
            top.$(".PreviewMap").hide();
            //Anu 11-nov-2016 map refinements
            if (mode == "MapPreview") {
                //top.$('#resizeMapPreview').css({ "left": "50%", "display": "block" });
            }
            else {
                top.$('#resizeScriptPreview').css({ "left": "46%", "display": "block" });
            }
            if (mode == 'ScriptPreview') {
                top.$(".EditPage").show();
            }
            else {
                top.$(".EditPage").hide();
            }
            top.$("#selResoDD").hide();
            $(".ContentArea").css("position", "absolute");
            $(".ContentArea").css("overflow", "auto");
            if (mode == "MapPreview") {
                $(".ContentArea").css("left", "20px");
                $(".ContentArea").css("overflow", "visible");
                $(".wrapper").css("overflow", "visible");
            }
            else {
                $(".ContentArea").css("left", top.$('#resizeScriptPreview').position().left);
            }
            //end
            $("#restOftheContent").css("border", "0")
            // top.$("#divCasePreview").css({ "top": "-10px" });
            $(".BrandingBarContainer").css("max-width", "100%")
            $(".BrandingBarContainer").css("width", "100%")
            //Anu 11-aug-2016 show open notes count for current page
            top.ShowPreviewCurrPageNSCount(gCurrPageObj.PageId);
    }
    if(!(lms_mode != undefined && lms_mode == "review")){
        setTimeout("scormBookmarkRedirect()",300);
    }
}
function scormBookmarkRedirect(){
        if (gPackageType == 'SCORM 1.2' || gPackageType == 'SCORM 2004') {
            var bookmark = getBookMark();
	        if (Number(gCurrPageObj.PageId) != Number(bookmark)) {
                 GotoPageId(bookmark);
            }
          }
}
function UpdateVisitedPageArray(selPage)
{
    if (selPageId != null && selPageId != "") {
        visitedNodesArray = "";
       var pageObj = GetPage(selPageId);
       if (visitedNodesArray.indexOf("," + pageObj.PageId + ",") < 0)
       {
           visitedNodesArray = "," + pageObj.PageId + ",";
       }
       var prevPageId = pageObj.PrevPageId;
       while(prevPageId !=null)
       {
           if (visitedNodesArray.indexOf("," + prevPageId + ",") < 0) {
               visitedNodesArray = "," + prevPageId + ",";
               pageObj = GetPage(prevPageId);
               prevPageId = pageObj.PrevPageId;
           }
       }
    }
}

function GetLMSDataToLocalVariables() {
    // ***SCORM if it is scorm course, get student data
    if (gPackageType == 'SCORM 1.2') {
        // Fill values for first time in SCRORM object
        lms_studentId = scorm.get('cmi.core.student_id');
        lms_studentName = scorm.get('cmi.core.student_name');
        lms_timeSpent = scorm.get('cmi.core.total_time');
        lms_suspendData = scorm.get('cmi.suspend_data');
        lms_completionstatus = scorm.get('cmi.core.lesson_status');   // (possible values: completed, incomplete, passed, failed
        lms_lessonlocation = scorm.get('cmi.core.lesson_location');
        lms_score = scorm.get('cmi.core.score.raw')
        lms_mode = scorm.get('cmi.mode')
        if(lms_mode==undefined || lms_mode=="")
        {
            lms_mode = scorm.get('cmi.core.mode');
        }
    }
    // Rahul 03March-2015 Scorm 2004 Update
    if (gPackageType == 'SCORM 2004') {
        // Fill values for first time in SCRORM object
        lms_studentId = scorm.get('cmi.learner_id');
        lms_studentName = scorm.get('cmi.learner_name');
        lms_timeSpent = scorm.get('cmi.total_time');
        lms_suspendData = scorm.get('cmi.suspend_data');
        lms_completionstatus = scorm.get('cmi.completion_status');   // (possible values: completed, incomplete, passed, failed
        lms_lessonlocation = scorm.get('cmi.location');
        lms_score = scorm.get('cmi.score.raw')
        lms_mode = scorm.get('cmi.mode')
    }
}
function SetSelectedOption(pageToLoad) {
    //if (IsPreview()) return false;
    if (gPackageType != 'Knowdl Platform') return;
    //caseid - case identity
    var caseid = gPulishedVersionId;  //parent.$('.hiddenCaseData').attr("data-cbacaseid");
    if (typeof (caseid) === 'undefined' || caseid == null) return;

    var attemptId = getParameterByName("AId");

    $.ajax({
        type: 'POST',
        url: "/Learning/GetOptionId",
        data: "caseid=" + caseid + "&AId=" + attemptId + "&BPId=" + Number(gCurrPageObj.PageId),
        success: function (data) {
            if (data != "")
                $("ul.Options li:eq(" + Number(data) + ")").addClass('selected');
        },
        error: function (xhr, data, message) {
            ElapsedTime = new Date().getTime();
        }
    });
}

function fNext() {

    gTotalScoreMode = "false";
    //Call to set release module responses for current page. called before we load next page for selected option.
    SetReleaseModuleResponces();
    //End
    if ((gSelectedOptionId != "" && gSelectedOptionId != undefined && gSelectedOptionId != null)
    || (gRankedOptionIdArray != undefined && gRankedOptionIdArray.length > 0)) {
        var qAnswered = false;
        var optText = "";
        if (gCurrPageObj.PageType == "DTP") {
            for (var i = 0; i < gCurrPageObj.PageContent.Options.length; i++) {
                if (gCurrPageObj.PageContent.Options[i].OptionId == gSelectedOptionId) {
                    optText = gCurrPageObj.PageContent.Options[i].Text;
                    break;
                }
            }
        }
        for (index = 0; index < responsesArr.length; index++) {
            if (responsesArr[index].question == gCurrPageObj.PageId) {
                qAnswered = true;
                if (gCurrPageObj.PageType == "DTP") {
                    responsesArr[index].answer = [];
                    responsesArr[index].answer.push({ "Text": optText, "Id": gSelectedOptionId });
                }
                else
                    responsesArr[index].answer = gRankedOptionIdArray.slice(0);
                break;
            }
        }
        if (qAnswered != true) {
            responsesArr.push({});
            responsesArr[index].question = gCurrPageObj.PageId;
            if (gCurrPageObj.PageType == "DTP") {
                responsesArr[index].answer = [];
                responsesArr[index].answer.push({ "Text": optText, "Id": gSelectedOptionId });
            }
            else
                responsesArr[index].answer = gRankedOptionIdArray.slice(0);
        }
    }

    //Set scorm suspended data for selected Option; LoadPageContent() reset selectedoption
    // Rahul 03March-2015 Scorm 2004 Update
    if ((gPackageType == 'SCORM 1.2' || gPackageType == 'SCORM 2004') && (gSelectedOptionId != null && gSelectedOptionId != 'null' && gSelectedOptionId != "")) {
        setQuestionStatus("Q-" + gCurrPageObj.PageId, gSelectedOptionId);
        gSelectedOptionId = "";
    }

    $(".ContentArea").animate({
        opacity: 1
    }, gPageTransitionDuration, "linear");
    if (gNextPageId != "") {
        $.fancybox.showActivity();
        var nextPage = GetPage(gNextPageId)
        gPrevPageIdArray.push(gCurrPageObj.PageId);
        gCurrPageObj = nextPage;
        gNextPageId = nextPage.NextPageId;

        //Always last statement as inside function next and prev button active is desided.
        LoadPageContent(nextPage);

        //Enable Prev button
        $("#PrevPage").removeClass("disabled");
        //Anu 23-feb-2015 - check if Disable Next button called func instead of inline code
        HandleNextLink(gCurrPageObj);

        $.fancybox.hideActivity();
    }
}

//Anu 23-feb-2015 - check if Disable Next button func
function HandleNextLink(gCurrPageObj) {
    if (gNextPageId == "") {
        $("#NextPage").addClass("disabled");
    }
    else if (gCurrPageObj.PageType == "Poll") {
        var disablenext = IsDisableNextForSurvey();
        if (disablenext) {
            $("#NextPage").addClass("disabled");
        }
        else {
            $("#NextPage").removeClass("disabled");
        }
        // DDeva: 6Apr15
        if (gCurrPageObj.Assessment === true) {
            $("#PrevPage").addClass("disabled");
            $("#NextPage").addClass("disabled");
        }
    }
    else if (gCurrPageObj.PageType != 'CEP') {
        if ($("#NextPage").hasClass("disabled")) {
            $("#NextPage").removeClass("disabled");
        }
    }
}

//Anu 23-feb-2015 - check if Disable Prev button func
function HandlePrevLink(gCurrPageObj) {
    if (gPrevPageIdArray.length <= 0 && gCurrPageObj.PrevPageId == "") {
        $("#PrevPage").addClass("disabled");
    } else if ($("#PrevPage").hasClass("disabled")) {
        $("#PrevPage").removeClass("disabled");
    }
}

//end

function IsDisableNextForSurvey() {
    var isdisabled = false;
    if (gCurrPageObj.DisableNext != undefined && ((gCurrPageObj.DisableNext + "") == "true")) {
        isdisabled = true;
        if (GetAttemptedQuestionCount() == GetNoOfQuestions()) {
            isdisabled = false;
        }
    }
    else if (gCurrPageObj.AllQuestion != undefined && ((gCurrPageObj.AllQuestion + "") == "true")) {
        isdisabled = true;
        if (GetAttemptedQuestionCount() == GetNoOfQuestions()) {
            isdisabled = false;
        }
    }
    return isdisabled;
}

function fPrev() {
    gTotalScoreMode = "true";
    $(".ContentArea").animate({
        opacity: 1
    }, gPageTransitionDuration, "linear");
    var prevPage;
    if (gPrevPageIdArray.length > 0) {
        prevPage = GetPage(gPrevPageIdArray.pop())
    }
    else {
        prevPage = GetPage(gCurrPageObj.PrevPageId)
    }

    if (prevPage != undefined && prevPage != null) {
        $.fancybox.showActivity();
        gNextPageId = gCurrPageObj.PageId;
        gEarlierPgId = gCurrPageObj.PageId;
        gCurrPageObj = prevPage;

        //Always last statement as inside function next and prev button active is desided.
        LoadPageContent(prevPage);

        //Enable Next button if PageType != DTP
        if (gCurrPageObj.PageType == "DTP") {
            gNextPageId == "";
            gSelectedOptionId = "";
            if (!$("#NextPage").hasClass("disabled")) {
                $("#NextPage").addClass("disabled");
            }
        }
        else if (gCurrPageObj.PageType == "Poll") {
            var disablenext = IsDisableNextForSurvey();
            if (disablenext) {
                $("#NextPage").addClass("disabled");
            }
            else {
                $("#NextPage").removeClass("disabled");
            }
        }
        else {
            $("#NextPage").removeClass("disabled");
        }

        //Anu 23-feb-2015 - Check if Disable prev button called func instead of inline code
        HandlePrevLink(gCurrPageObj)

        $.fancybox.hideActivity();
    }
}


$(".Options li").live("click", function () {
    var spp = getParameterByName("SPP");

    var _anc = $(this).find("a.DTPOption");
    gNextPageId = _anc.attr("NextPageId");
    gSelectedOptionId = _anc.attr("OptionId");
    //Remove prev selection.
    $(".ContentArea a.DTPOption").closest("li").removeClass("selected");
    _anc.closest("li").addClass("selected");
    $(".ToptDTP .Options li").removeClass("over")
    $(".ToptDTP .Options li").removeClass("selected")
    $(this).addClass("selected");

    if (spp != undefined && (spp == true || spp == "true")) {
        $("#OptionSubmit").attr("disabled", "disabled").css("cursor", "default");
    }
    else {
        if (gCurrPageObj.PageContent.IsSubmitReqd) {
            $("#OptionSubmit").removeAttr("disabled").css("cursor", "pointer");
        } else {
            $("#OptionSubmit").attr("disabled", "disabled").css("cursor", "pointer");
            if (gNextPageId != null && gNextPageId != "") {
                //$("#NextPage").removeClass("disabled");
                fNext();
            }
        }
    }
});


function RankingSelect(nxtPId) {
    gNextPageId = nxtPId;
    if (gNextPageId != "" && !isSPP) {//gp 7 sept 2015 added condition for single page preview
        $("#NextPage").removeClass("disabled");
    }
}

function SelectPageFromMap(pgid, callback) {
    $("#mapArea div").removeClass("selected");
    $("#div_" + pgid).addClass("selected");
    var spp = getParameterByName("SPP");
    if (spp != undefined && (spp == true || spp == "true")) { return; }
    closeAllPopups()
    //Reset PrevPageId Array
    if (gCurrPageObj != undefined)
        gPrevPageIdArray.push(gCurrPageObj.PageId);
    gCurrPageObj = GetPage(pgid);
    //Anu 11-nov-2016 map refinements
    if(true){ // (gCurrPageObj.IsLayout == true) {
        gNextPageId = gCurrPageObj.NextPageId;
        LoadPageContent(gCurrPageObj);
        //Anu 23-feb-2015 - check if Disable Next button called func instead of inline code
        HandleNextLink(gCurrPageObj);
        //Anu 23-feb-2015 - Check if Disable prev button called func instead of inline code
        HandlePrevLink(gCurrPageObj);
        if (getParameterByName("HScriptPreview") == undefined || getParameterByName("HScriptPreview") == false || getParameterByName("HScriptPreview") == "false") {
            $("#mapcanvasContainer").hide();
        }
        else {
           // $(".BrandingBarContainer").find(".BrandingBar").hide();
            //Anu 11-aug-2016
            top.ShowPreviewCurrPageNSCount(pgid);
        }
        //RA-13June2016 - Next page load animation effect.
        if (callback != undefined && typeof callback == 'function')
            callback();
    }
    else {
        //Anu 11-nov-2016 map refinements
        $("#pageScriptDiv").empty();
        $(".pageWrapper").find(".TbodyText").empty();
        $(".TpageTitle").hide();
    }
}

function GotoPage(arrayIndex) {
	if(Number(arrayIndex)<=0)
	return ;
    var spp = getParameterByName("SPP");
    if (spp != undefined && (spp == true || spp == "true")) { return; }
    closeAllPopups()

    gPrevPageIdArray.push(gCurrPageObj.PageId);

    //Get page from Array Index - parameter should be one less the actual array index
    gCurrPageObj = gPages[Number(arrayIndex) - 1]
    gCurrPageIndex = Number(arrayIndex);

    gNextPageId = gCurrPageObj.NextPageId;
    LoadPageContent(gCurrPageObj);

    //Anu 23-feb-2015 - check if Disable Next button called func instead of inline code
    HandleNextLink(gCurrPageObj);
    //Anu 23-feb-2015 - Check if Disable prev button called func instead of inline code
    HandlePrevLink(gCurrPageObj);

    $("#mapcanvasContainer").hide();
}

//NM:It is copy of function GotoPage() - which is index base navigation to the page.
//This function is improved to navigate based on page id.
function GotoPageId(paramPageId) {
    var spp = getParameterByName("SPP");
    if (spp != undefined && (spp == true || spp == "true")) { return; }
    closeAllPopups()

    gPrevPageIdArray.push(gCurrPageObj.PageId);

    //Get page from Array Index - parameter should be one less the actual array index
    for(var pgidx=0;pgidx<gPages.length;pgidx++)
    {
        if((paramPageId + "") == (gPages[pgidx].PageId + "")){
            gCurrPageObj = gPages[pgidx];
            gCurrPageIndex = pgidx + 1;
            break;
        }
    }

    gNextPageId = gCurrPageObj.NextPageId;
    LoadPageContent(gCurrPageObj);

    //Anu 23-feb-2015 - check if Disable Next button called func instead of inline code
    HandleNextLink(gCurrPageObj);
    //Anu 23-feb-2015 - Check if Disable prev button called func instead of inline code
    HandlePrevLink(gCurrPageObj);

    $("#mapcanvasContainer").hide();
}


function GetPage(paramPageId) {
    var page;
    for (var i = 0; i < gPages.length; i++) {
        if (gPages[i].PageId == paramPageId) {
            page = gPages[i];
            page.ArrayIndex = i;
            gCurrPageIndex = i + 1;
            break;
        }
    }
    return page;
}

function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        results = regex.exec(location.search);
    return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

function getPerc(pelement, pcontainer) {
    pelement = (pelement + "").replace("px", "");
    pcontainer = (pcontainer + "").replace("px", "");
    var result = (parseFloat(pelement) / parseFloat(pcontainer)) * 100.00;
    return result;
}

var totalRemainingNodeInPath = 0;
var totalVisitedNodes = 0;
var visitedNodesInCurrentPath = "";
var visitedNodesArray = "";
var CurrentPage;
// gp added on 24-02-2015 for progress bar changes
function DisplayProgressInPercent(pageToLoad) {
    totalRemainingNodeInPath = 0;
    totalVisitedNodes = 0;
    visitedNodesInCurrentPath = "";
    visitedNodesArray = visitedNodesArray + "," + pageToLoad.PageId + ",";
    var visitedNodes = 0;
    visitedNodes = GetTotalNodesVisited(pageToLoad.PageId) + 1;
    visitedNodesInCurrentPath = "";
    var remainingNodes = GetTotalNodesToBeVisited(pageToLoad.PageId)
    var percentCompleted = Math.round(((visitedNodes) / (visitedNodes + remainingNodes) * 100));

    var title = percentCompleted + "% completed";
	if ($(".pagingText").find(".progressBackground").length > 0) {
		$(".pagingText").find(".progressBackground").attr("title", title)
		$(".pagingText").find(".progressBackground").attr("moduleProgress", title)
		$(".pagingText").find(".progressForeground").css({ "width": percentCompleted + "%" })
	}
	else {
    $(".pagingText").html("<div class='progressBackground' moduleProgress='" + title + "' title='" + title + "'><div class='progressForeground ProgressForeGroundColor' style='width:" + percentCompleted + "%' ></div></div>");
    }
}
// gp added on 24-02-2015 for progress bar changes
function getPageFromPageArray(pgId) {
    var currPage;
    for (var i = 0; i < gPages.length; i++) {
        if (gPages[i].PageId == pgId) {
            currPage = gPages[i];
            break;
        }
    }
    return currPage;
}
// gp added on 24-02-2015 for progress bar changes
function GetTotalNodesToBeVisited(pgid) {

    var currPage = getPageFromPageArray(pgid);
    CurrentPage = currPage;
    var isNext = true;
    var isLoop = false;
    var isCaseContainDTP = false;
    for (var i = 0; i < gPages.length; i++) {
        if (gPages[i].PageType == "DTP" || gPages[i].PageType == "RNP") {
            isCaseContainDTP = true;
            break;
        }
    }
    while (isNext) {
        if (currPage != undefined && currPage != null) {
            visitedNodesInCurrentPath = visitedNodesInCurrentPath + "," + currPage.PageId + ",";
            if (isCaseContainDTP) {
                if ((currPage.PageType == "DTP" || currPage.PageType == "RNP")) {
                    // for dtp calcute path for each option and get longest
                    totalRemainingNodeInPath = totalRemainingNodeInPath + GetDTPNodeCount(currPage.PageId)
                    isNext = false
                }
                else if (currPage.NextPageId != undefined && currPage.NextPageId != null && currPage.NextPageId != "") {
                    currPage = getPageFromPageArray(currPage.NextPageId);
                    totalRemainingNodeInPath = totalRemainingNodeInPath + 1;
                }
                else {
                    isNext = false;
                }
            }

            else {
                //loop for linear case check whether node is covered while traversing current path of calculation as well as main path

                if (currPage.NextPageId != undefined && currPage.NextPageId != null && currPage.NextPageId != ""
                    && visitedNodesInCurrentPath.indexOf("," + currPage.NextPageId + ",") < 0 && visitedNodesInCurrentPath.indexOf("," + currPage.NextPageId + ",") < 0) {
                    currPage = getPageFromPageArray(currPage.NextPageId);
                    totalRemainingNodeInPath = totalRemainingNodeInPath + 1;
                }
                else {
                    isNext = false;
                }
            }
        }
        else {
            isNext = false;
        }
    }
    return totalRemainingNodeInPath;
}
// gp added on 24-02-2015 for progress bar changes
function CheckIfCCExistFor(srcPgId, trgPgId) {
    var isCustomConnExist = false
    // Check custom connectors for this page and take care of it
    for (var P = 0; P < CustomConnectors.length; P++) {
        if (CustomConnectors[P].SourceId == srcPgId && CustomConnectors[P].TargetId == trgPgId) {
            isCustomConnExist = true;
        }
    }
    return isCustomConnExist;
}
// gp added on 24-02-2015 for progress bar changes
function GetDTPNodeCount(pageId) {

    var dtpPage = getPageFromPageArray(pageId);
    if (dtpPage != undefined && dtpPage != null) {
        var DTPPathDetails = [];
        for (var cntOptions = 0 ; cntOptions < dtpPage.PageContent.Options.length ; cntOptions++) {
            var optionPageId = dtpPage.PageContent.Options[cntOptions].TargetPageId;
            var nodeCounter = 0;
            var isNext = true;
            var isLoop = false;
            if (optionPageId != undefined && optionPageId != null && optionPageId != "") {
                while (isNext) {
                    var optionPage = getPageFromPageArray(optionPageId);

                    //get array of previous nodes from starting node for current option
                    if (visitedNodesInCurrentPath.indexOf("," + optionPageId + ",") >= 0) {
                        isNext = false;
                        isLoop = true;
                    }
                    var PreviousNodes = GetPreviousNodesForCurrentNode(optionPageId);
                    nodeCounter++;
                    //check whether it is going in loop if yes break
                    if (optionPage.NextPageId != undefined && optionPage.NextPageId != null && optionPage.NextPageId != "" && PreviousNodes.indexOf("," + optionPage.NextPageId + ",") >= 0) {
                        isNext = false;
                        isLoop = true;
                    }
                    if (!isLoop) {
                        //recursive call for dtp
                        visitedNodesInCurrentPath = visitedNodesInCurrentPath + "," + optionPage.PageId + ",";
                        if (optionPage.PageType == "DTP" || optionPage.PageType == "RNP") {
                            nodeCounter = nodeCounter + GetDTPNodeCount(optionPage.PageId);
                            isNext = false;
                        }
                            //get next knowd and continue
                        else if (optionPage.NextPageId != undefined && optionPage.NextPageId != null && optionPage.NextPageId != "") {

                            optionPageId = optionPage.NextPageId;
                        }
                        else {
                            isNext = false;
                        }
                    }
                }
            }
            //if loop is not present in current traversing path push nodeCounter in array
            if (!isLoop) {
                DTPPathDetails.push(nodeCounter);
            }
        }
        //return maximum value in array DTPPathDetails (which means option who has maximum knowds)
        if (DTPPathDetails != undefined && DTPPathDetails.length > 0) {
            DTPPathDetails.sort(function (a, b) {
                return a - b;
            });
            DTPPathDetails.reverse();
            return DTPPathDetails[0]
        }
        else {
            return 0;
        }
    }
    return 0;

}
// gp added on 24-02-2015 for progress bar changes
//get array of previous nodes from starting node for current Node
function GetPreviousNodesForCurrentNode(pgid) {
    var currPage = getPageFromPageArray(pgid);
    var isNext = true;
    var PreviousNodesArray = "";
    if (currPage != undefined && currPage != null) {
        while (isNext) {
            if (currPage != undefined && currPage != null) {
                //for first page
                if (currPage.ArrayIndex == 0) {
                    isNext = false;
                }
                else if (currPage.PrevPageId != undefined && currPage.PrevPageId != null && currPage.PrevPageId != "") {
                    PreviousNodesArray = PreviousNodesArray + "," + currPage.PrevPageId + ","
                    currPage = getPageFromPageArray(currPage.PrevPageId);
                }
                else {
                    isNext = false;
                }
            }
            else {
                isNext = false;
            }
        }
    }
    return PreviousNodesArray;
}
// gp added on 24-02-2015 for progress bar changes
//get already visited node count from 1st node
function GetTotalNodesVisited(pgid) {
    var isCaseContainDTP = false;
    for (var i = 0; i < gPages.length; i++) {
        if (gPages[i].PageType == "DTP" || gPages[i].PageType == "RNP") {
            isCaseContainDTP = true;
            break;
        }
    }
    if (isCaseContainDTP) {
        var currPage = getPageFromPageArray(pgid);


        if (currPage != undefined && currPage != null) {
            if (currPage.ArrayIndex == 0) {
                return totalVisitedNodes;
            }
            if (currPage.PrevPageId != undefined && currPage.PrevPageId != null && currPage.PrevPageId != "") {
                totalVisitedNodes = totalVisitedNodes + 1;
                GetTotalNodesVisited(currPage.PrevPageId);
            }
        }
    }
        // for linear case return index of page
    else {
        var currPage = getPageFromPageArray(pgid);

        if (currPage != undefined && currPage != null) {
            visitedNodesInCurrentPath = visitedNodesInCurrentPath + "," + currPage.PageId + ",";
            //loop for linear case check whether node is covered while traversing current path of calculation as well as main path
            //check for 1st node
            if (currPage.ArrayIndex == 0) {
                return 0;
            }
            else if (currPage.PrevPageId != undefined && currPage.PrevPageId != null && currPage.PrevPageId != ""
                 && visitedNodesInCurrentPath.indexOf("," + currPage.PrevPageId + ",") < 0) {
                totalVisitedNodes = totalVisitedNodes + 1;
                GetTotalNodesVisited(currPage.PrevPageId);
            }
        }
    }
    return totalVisitedNodes;
}

function checkTheme(pageToLoad, param1) {
    if (param1 == undefined) {
        param1 = $(".templateScoringTool").css("display");
    }
    if ((pageToLoad.PageContent.AdditionalResources == undefined || pageToLoad.PageContent.AdditionalResources == null) && ($(".nvgbtncontainer").css("margin-top") > "0px")) {
        if (gScoringToolFormat != undefined && gScoringToolFormat != null && param1 == "block") {
            $(".nvgbtncontainerwrapper").css({ "height": "0px" });
        } else if (gScoringToolFormat == undefined || gScoringToolFormat == null) {
            $(".nvgbtncontainerwrapper").css({ "height": "0px" });
        } else {
            // $(".nvgbtncontainerwrapper").css({ "height": "30px" });
        }
    } else {
        if (pageToLoad.PageContent.AdditionalResources != undefined && pageToLoad.PageContent.AdditionalResources != null && pageToLoad.PageContent.AdditionalResources.length == 0) {
            if (gScoringToolFormat != undefined && gScoringToolFormat != null && param1 == "block") {
                $(".nvgbtncontainerwrapper").css({ "height": "0px" });
            } else if (gScoringToolFormat == undefined || gScoringToolFormat == null) {
                $(".nvgbtncontainerwrapper").css({ "height": "0px" });
            } else {
                // $(".nvgbtncontainerwrapper").css({ "height": "30px" });
            }
        }
        else {
            // $(".nvgbtncontainerwrapper").css({ "height": "30px" });
        }
    }
}
function loadScripts(scriptArray) {
    if (getParameterByName("HScriptPreview") != undefined && (getParameterByName("HScriptPreview") == true || getParameterByName("HScriptPreview") == "true")) {
        return;
    }
    if (scriptArray == null) return;
    var pageScriptDiv = $("#pageScriptDiv");
    for (var k = 0; k < scriptArray.length; k++) {
        if (scriptArray[k].value == undefined) {
            pageScriptDiv.append(
                ('<script type="text/javascript">' + scriptArray[k] + '</script>')
            );
        } else {
            pageScriptDiv.append(
                ('<script type="text/javascript">' + scriptArray[k].value + '</script>')
            );
        }
    }
}
function JSAsyncCall(url) {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
    xhr.send(null);
}
function PgContentCacheJSAsyncCall(url) {
    $.ajax({
        async: true,
        url: url,
        type: 'GET',
        success: function (data) {
            try {
                var recvPageTxt = $.parseJSON(data);
                var imgArr = [], vidArr = [];
                    $(recvPageTxt).find('img').each(function () {
                        if (this.src != "") {
                            if ($.inArray(this.src, imgArr) == -1) {
                                imgArr.push(this.src);
                            }
                        }
                    });
                    $(recvPageTxt).find('.k-element-video').each(function () {
                        var fsrc = $(this).attr('fsrc');
                        if (fsrc != "") {
                            if ($.inArray(fsrc, vidArr) == -1) {
                                vidArr.push(fsrc);
                                //deva_video = document.getElementsByTagName('video')[0];
                                //addSourceToVideo(deva_video, fsrc, "video/mp4");
                                //deva_video.addEventListener("progress", vidProgressHandler, false);
                            }
                        }
                    });
                    $(imgArr).preload();
                    $(vidArr).preloadVid();
                    //end
            }
            catch (e) {
                console.log("Could not load page content cache for " + setPageId)
            }
        }
    });

}
function loadCss(CssString)
{
    $('html head').append($('<style type = "text/css">' + CssString + '</style>'));
}

function GetTemplateData(_tid) {
    var templateData;
    if (isSPP) {
        templateData = top.GetTemplateObject(_tid);
    }
    else {
    if (gTemplates != undefined && gTemplates.length > 0) {
        for (var i = 0; i < gTemplates.length; i++) {
            if (IsPreview && gTemplates[i].TemplateUniqueId!=undefined  && gTemplates[i].TemplateUniqueId == _tid) {
                templateData = gTemplates[i]
                break;
            }
            else if (gTemplates[i].TemplateId != undefined && gTemplates[i].TemplateId == _tid) {//gp 30dec2015 added for publlished cases
                templateData = gTemplates[i]
                break;
            }
        }
    }
    }
    return templateData;

}
function LoadPageContent(pageToLoad) {
    //Revel LifeCycleEvent .onunload
    if(IsRevel() && (pageToLoad.PageId + "" != gPages[0].PageId + "")){LifeCycleEvents.OnUnloadFromPlayer();}
    window.scrollTo(0, 0);
    //sync with template after html set.
    if (pageToLoad.TemplateId != undefined && pageToLoad.TemplateId != "") {
        //naveen - player GetTemplateData is different from cbscreen. where as need to remove it from cbscreen.
        var templateobj = GetTemplateData(pageToLoad.TemplateId);
        if (templateobj!=undefined)
	{
            if (IsPreview && templateobj.TemplateData != undefined) {
            var jsonTempData = JSON.parse(templateobj.TemplateData);
            SyncDataWithTemplate(jsonTempData, pageToLoad)
            }
            else//gp 30dec2015 added for publlished cases
            {
                SyncDataWithTemplate(templateobj, pageToLoad)
            }
        }
    }
    //end

    $("#pageScriptDiv").empty();

   // $(".wrapper").css("overflow", "visible");


    //Anu 25-feb-2015 if case is locked by other author then not allow edit though logged in user is editor
    var mode = getParameterByName("MODE");
    if (gAllowEdit == "true" && mode == '') {
        var editPageAnchor = $(".EditPage a");
        var ipSearchBox = $("#ipSearchBox");
        editPageAnchor.removeAttr("data-pageid");
        editPageAnchor.attr("data-pageid", pageToLoad.PageId);
        ipSearchBox.val('');
        ipSearchBox.trigger("blur");
    }

    //clear audio
    var audioContent = $(".audiocontent");
    $(".audioplayer").find(".audioplayer-playpause[title='Play']").click();
    $("audio").removeAttr("src");
    audioContent.remove("audio");
    audioContent.html("");
    //End
    $("#divSearchhResult").hide();
    //Anu 24-feb-2015 -
    //gp 16 march 2015 Show / hide ModuleTitle
    if (getParameterByName("HScriptPreview") == undefined || getParameterByName("HScriptPreview") == false || getParameterByName("HScriptPreview") == "false") {
        if (pageToLoad.HideModuleTitle == undefined) {
            $(".BrandingBar").show();
        }
        else if ((pageToLoad.HideModuleTitle == true || pageToLoad.HideModuleTitle == "true")) {
            $(".BrandingBar").hide();
        }
    }

    //Anu 23-feb-2015 - 2 new page properties
    if (pageToLoad.HidePageTitle != undefined && (pageToLoad.HidePageTitle == true || pageToLoad.HidePageTitle == "true")) {
        $(".TpageTitle").hide();
    }
    else {
        $(".TpageTitle").show();
    }

    if (pageToLoad.DisableNextUntil != undefined && (pageToLoad.DisableNextUntil == true || pageToLoad.DisableNextUntil == "true")) {
        $("#NextPage").addClass("disabled");
    }
    else {
        $("#NextPage").removeClass("disabled");
    }
    //end

    var htmlContent = "";
    if (pageToLoad.IsAudioAdded != undefined && pageToLoad.IsAudioAdded == true && pageToLoad.AudioFilePath) {
        if (iPadClickStatus == "true") {
            htmlContent = "<div class='divAudioPlayer'> <audio preload='auto'  style='height:37px;' id='' type='audio/mp3' controls='controls'  src ='" + pageToLoad.AudioFilePath + "'></audio></div>";
            audioContent.html(htmlContent);

            $("audio").mediaelementplayer({
                defaultAudioWidth: 30, success: function (player, node) {
                    $(".mejs-controls .mejs-play button").hide();
                    $(".mejs-horizontal-volume-slider").text('').css({ 'height': 0, 'width': 0 });
                    player.addEventListener('play', function () {
                        $(".mejs-controls .mejs-play button").hide();
                        $(".mejs-controls .mejs-pause button").show();
                    }, false);
                    player.addEventListener('pause', function () {
                        $(".mejs-controls .mejs-play button").show()
                        $(".mejs-controls .mejs-pause button").hide();
                    }, false);
                }
            });
        } else {
            htmlContent = "<div class='divAudioPlayer'> <audio preload='auto'  id='' type='audio/mp3' controls='controls'  src ='" + pageToLoad.AudioFilePath + "'></audio></div>";
            audioContent.html(htmlContent);


            $("audio").mediaelementplayer({
                defaultAudioWidth: 30, features: ['volume'], success: function (player, node) {
                    $(".mejs-horizontal-volume-slider").text('').css({ 'height': 0, 'width': 0 });
                }
            });
        }
        audioContent.show();
        htmlContent = "";
        if($(".divAudioPlayer").length>0 && $(".divAudioPlayer").find("audio").length>0){
        var player = MediaElementPlayer($(".divAudioPlayer").find("audio"));
        // DDeva:21Sept15:PAge audio disabled for navigated pages
        if (gNavigatedPageIds.indexOf("," + pageToLoad.PageId + ",") == -1)
        {
        player.play();
        }
        }
    }
    else {
        audioContent.hide();
    }
    $(".ContentArea").empty();
    var contentArea = $(".ContentArea");
    $('.qtip').remove(); //RA-10Sep15- to remove previous page qtip.
    switch (pageToLoad.PageType) {
        case "Poll":
            LoadPollPageContent(pageToLoad, contentArea);
            break;
        case "Assessment":
            LoadAssessmentPageContent(pageToLoad, contentArea);
            break;
        case "CEP":
            LoadCEPPageContent(pageToLoad, contentArea);
            break;
        case "TOP":
            htmlContent = GetTemplateString(pageToLoad, $("#Template_TOP").html());
            contentArea.html(htmlContent);
            break;
        case "IOP":
            htmlContent = GetTemplateString(pageToLoad, $("#Template_IOP").html());
            contentArea.html(htmlContent);
            break;
        case "TIP":
            LoadTIPPageContent(pageToLoad, contentArea);
            break;
        case "VOP":
            htmlContent = GetTemplateString(pageToLoad, $("#Template_VOP").html());
            contentArea.html(htmlContent);
            fLoadVideoJsPlayer(contentArea.find(".TvidArea .jsvideo_tvp"), pageToLoad);
            break;
        case "SMP":
            LoadSMPPageContent(pageToLoad, contentArea);
            break;
        case "TVP":
            LoadTVPPageContent(pageToLoad, contentArea);
            break;
        case "DTP":
            LoadDTPPageContent(pageToLoad, contentArea);
            break;
        case "RNP":
            LoadRNPPageContent(pageToLoad, contentArea);
            break;
        case "Excel":
            LoadExcelPageContent(pageToLoad, contentArea);
            break;
        default:
    }
    //loadpagecontent end switch

    //nav-device 01june16 //if asset inialization is done before
    //then need to initialise assets like video, audio, droppable draggable
    if (!IsPreview()) {
        k_DeviceManager.IdentifyModeAndUpdatePlayerLayout(k_DeviceManager.GetClientWidth(), Number(gCaseProperties.StageSize))
    }
    k_DeviceManager.RenderContentForMode("#contentContainer","",true);
    k_DeviceManager.TempInitiateElements("#contentContainer");
    //
    //Naveen-25-march-2015-defaultvisibility
    $(".k-element-box[defaultVisibility='Hidden']").hide();

    $(".TbodyText li").wrapInner(function () {
        return "<span style='color:black;'></span>";
    });

    if (pageToLoad.PageType == "RNP") {
        $("#ResetRanking").show();
        $("#OptionSubmit").hide();
        $("#NextPage").addClass("disabled");
    } else if (pageToLoad.PageType == "DTP") {
        $("#ResetRanking").hide();
        if (pageToLoad.PageContent.IsSubmitReqd) {
            $("#OptionSubmit").show();
        }
        else {
            $("#OptionSubmit").hide();
        }

    } else {
        $("#ResetRanking").hide();
        $("#OptionSubmit").show();
    }
    if (pageToLoad.PageContent.AdditionalResources != undefined && pageToLoad.PageContent.AdditionalResources != null) {

        $(".RMArea .RMThumbnail a").click(function (e) {
            e.preventDefault();
            $(".ContentArea").find("div.video-js").each(function () {
                var videoID = $(this).attr("id");
                if (videoID != undefined && videoID != null && videoID != "") {
                    var myPlayer = videojs(videoID);
                    myPlayer.pause();
                }
            });
            if (!$(this).parent().parent().hasClass('selected')) {
                //selection
                $(".RMArea .RMThumbnail a").each(function () {
                    $(this).parent().parent().hasClass('selected');
                    $(this).parent().parent().removeClass('selected');
                });
                $(this).parent().parent().addClass('selected');

                $(".RMDisplay").html('');
                var fileHref = $(this).find('img').attr('href');
                var rmtitle = $(this).find('img').attr('title')
                var srctype = $(this).find('img').attr('data-srctype')
                /**2-apr-2014 additioanla res side src*/
                if (AdditionalResOpenType == AdditionalResFullScrn)
                    ActionOnFileExtension(fileHref, "RMDisplay", rmtitle, srctype);
                else {
                    if (iPadClickStatus == "true") {
                        //  $(".RMDisplay3").html('');
                        ActionOnFileExtension(fileHref, "RMDisplay3", rmtitle, srctype);
                        //var str = "<div style='text-align:right;padding:20px;'><a id='linkCloseRes'><img src='content/images/close-new.png'></a></div>";
                        //$(".RMDisplay3").prepend(str).show();
                    }
                    else {
                        $(".RMDisplay2").html('');
                        ActionOnFileExtension(fileHref, "RMDisplay2", rmtitle, srctype);
                        var str = "<div style='text-align:right;padding:20px;'><a id='linkCloseRes'><img src='content/images/close-new.png'></a></div>";
                        $(".RMDisplay2").prepend(str).show();
                    }
                }
                //END
            }
            return false;
        });

        $(".RMDisplay").html('');

        /*2-apr-2014 additioanla res side src*/
        $(".RMDisplay2").html('');
        $(".RMDisplay3").html('');
        //END

        if (pageToLoad.PageContent.AdditionalResources.length > 0) {
            var fileHref = pageToLoad.PageContent.AdditionalResources[0].ResourcePath;
            var rmtitle = pageToLoad.PageContent.AdditionalResources[0].Description;
            var srctype = pageToLoad.PageContent.AdditionalResources[0].SourceType;
            /**2-apr-2014 additioanal res side src*/
            //Nav - Layer = fullscreen and Panel = slidescreen
            if (AdditionalResOpenType == AdditionalResFullScrn) {
                ActionOnFileExtension(fileHref, "RMDisplay", rmtitle, srctype);
                //$(".mCSB_scrollTools").css('display')
                $(".RMArea").eq(0).addClass('selected');
            }
            //END
            $(".RMSliderLink").show();

        }
        else {
            $(".RMSliderLink").hide();
        }

    }
    else {
        $(".RMSliderLink").hide();
        $(".RMDisplay").html('');
        /*2-apr-2014 additioanal res side src*/
        $(".RMDisplay2").html('');
        $(".RMDisplay3").html('');

        //END
    }

    //Scoring Tool
    $(".templateScoringTool .properties").empty();
    if (gScoringToolFormat != undefined && gScoringToolFormat != null && !gActionScoreTracking) {
        if (gScoringToolFormat.ScoringToolDetails != undefined && gScoringToolFormat.ScoringToolDetails != null && gScoringToolFormat.ScoringToolDetails.length > 0) {
            $(".templateScoringTool").show();
            $(".ScoringToolWrap").show();

            var chkTotalPageScore = "false";
            if (gTotalScorePgArray.length != undefined) {
                for (var pgtc = 0; pgtc < gTotalScorePgArray.length; pgtc++) {
                    if (Number(gTotalScorePgArray[pgtc]) == Number(gCurrPageObj.PageId)) {
                        chkTotalPageScore = "true";
                        break;
                    }
                }
            }

            var propStr = "<div class='stProperty'><table><tr><td>###propName###</td><td rowspan='3' class='scoreunit'>###propUnit###</td></tr><tr><td class='scorevalue' style='###propVStyle###'>###propValue###</td></tr><tr><td>###propRange###</td></tr></table></div>";
            for (var i = 0; i < gScoringToolFormat.ScoringToolDetails.length; i++) {
                var prscore = gScoringToolFormat.ScoringToolDetails[i];
                if (prscore != null && prscore != undefined) {
                    var tmpPropStr = propStr.replace("###propName###", prscore.Name);
                    tmpPropStr = tmpPropStr.replace("###propUnit###", prscore.ScoreUnit);
                    if (prscore.ShowTargetRange || prscore.ShowTargetRange == "true") {
                        tmpPropStr = tmpPropStr.replace("###propRange###", prscore.TargetRangeLowValue + "-" + prscore.TargerRangeHighValue);
                    }
                    else {
                        tmpPropStr = tmpPropStr.replace("###propRange###", "");
                    }
                    var tempScoreValue = prscore.StartValue;
                    var tempColorcode = prscore.BelowScoreColor

                    //Get Range Value
                    if (pageToLoad.PageContent.ScoringTool != undefined && pageToLoad.PageContent.ScoringTool != null) {
                        for (var j = 0; j < pageToLoad.PageContent.ScoringTool.Scores.length; j++) {
                            if (prscore.Name == pageToLoad.PageContent.ScoringTool.Scores[j].Name) {
                                tempScoreValue = pageToLoad.PageContent.ScoringTool.Scores[j].ScoreValue;
                            }
                        }
                    }

                    /*DDeva:v1.1.1*/
                    if (gTotalScore[i] == undefined) {
                        gTotalScore[i] = Number(tempScoreValue);
                        gCurrentScore[i] = Number(tempScoreValue);
                    } else {
                        if (gTotalScoreMode == "false") {
                            if (chkTotalPageScore == "false") {
                                gTotalScore[i] = Number(gTotalScore[i]) + Number(tempScoreValue);
                            }
                        } else {
                            gTotalScore[i] = Number(gTotalScore[i]) - Number(gCurrentScore[i]);
                            if (gTotalScorePgArray.length != undefined) {
                                for (var q = 0; q < gTotalScorePgArray.length; q++) {
                                    if (Number(gTotalScorePgArray[q]) == Number(gEarlierPgId)) {

                                        gTotalScorePgArray.splice(q, 1);
                                    }
                                }
                            }
                        }
                    }
                    //    set colorcode
                    if (parseFloat(gTotalScore[i]) < parseFloat(prscore.TargetRangeLowValue)) {
                        tempColorcode = prscore.BelowScoreColor;
                    }
                    else if (parseFloat(gTotalScore[i]) > parseFloat(prscore.TargerRangeHighValue)) {
                        tempColorcode = prscore.AboveScoreColor;
                    }
                    else {
                        tempColorcode = prscore.WithinScoreColor;
                    }
                    tmpPropStr = tmpPropStr.replace("###propValue###", gTotalScore[i]);
                    gCurrentScore[i] = Number(tempScoreValue);
                    tmpPropStr = tmpPropStr.replace("###propVStyle###", "color:" + tempColorcode);
                    $(".templateScoringTool .properties").append($(tmpPropStr));
                }
            }
            if (chkTotalPageScore == "false") {
                gTotalScorePgArray.push(Number(gCurrPageObj.PageId));
            } else {
                chkTotalPageScore == "true";
            }
        }
    }
    //End scoring settings
    //Show page navigation progress
    //Show page navigation text
    //Aditi - 9 April 2014 For displaying preview page numbers
    var spp = getParameterByName("SPP");
    if (spp != undefined && (spp == true || spp == "true")) {
        var TPages = getParameterByName("TPages");
        var cpageIndex = getParameterByName("cpageIndex");
        if (TPages != undefined && cpageIndex != undefined) {
            cpageIndex = Number(cpageIndex) + 1;
            //alert("cpageIndexvvv" + cpageIndex);
            if (gCaseProperties.PagingInfo == 'x') {
                $(".pagingTextWrap .pagingText").html("Page " + cpageIndex + " ");
            }
            else if (gCaseProperties.PagingInfo == 'percentage') {
                DisplayProgressInPercent(pageToLoad);
            }
            else {
                $(".pagingTextWrap .pagingText").html("Page " + cpageIndex + " of " + TPages)
            }
        }
    }
    else {
        if (gCaseProperties.PagingInfo == 'x') {
            $(".pagingTextWrap .pagingText").html("Page " + gCurrPageIndex + " ");
        }
        else if (gCaseProperties.PagingInfo == 'percentage') {
            DisplayProgressInPercent(pageToLoad);
        }
        else {
            $(".pagingTextWrap .pagingText").html("Page " + gCurrPageIndex + " of " + gPages.length);
        }
    }
    //apply padding to content
    $("#contentContainer").addClass("contentTopPosition");
    if (pageToLoad.PageContent.Heading != "") {
        $(".TpageTitle").addClass("titlePadding");
    }
    else {
        $(".TpageTitle").removeClass("titlePadding");
    }
    if ($(".RMArea").length > 0) {
        $(".RMContainer img").load(function () {
            //$(".RMContainer.customScroll").mCustomScrollbar("update");
        });
    }

    //Set scorm Bookmark
    // Rahul 03March-2015 Scorm 2004 Update
    if (gPackageType == 'SCORM 1.2' || gPackageType == 'SCORM 2004') {
        if( (gPages[0].PageId+"") != (gCurrPageObj.PageId+ "") ){
            if(!(lms_mode != undefined && lms_mode == "review")){
                setBookMark(pageToLoad.PageId);
            }
        }
    }



    // Rahul 03March-2015 Scorm 2004 Update
    if ((gPackageType == 'SCORM 1.2' || gPackageType == 'SCORM 2004') && gCurrPageObj.IsCompletion) {
        //nav-09-Aprl-15-this shoud be set from assessment page.
        //setScore(40);
        if(!(lms_mode != undefined && lms_mode == "review")){
            complete();
        }
    }
    else if (gNextPageId == "") {
        if ((gPackageType == 'SCORM 1.2' || gPackageType == 'SCORM 2004') && gCurrPageObj.PageType != 'DTP' && gCurrPageObj.PageType != 'RNP') {
            //nav-09-Aprl-15-this shoud be set from assessment page.
            //setScore(40);
            // complete();
        }
    }

    //if (IsPreview()) return false;
    //if (gPackageType != 'Knowdl Platform') return false;

    // ***SCORM data post
    //nav-31-March-2015 - removed lms data tracking from here as it is enabled against release/published version.
    /*
    if (gPackageType == 'SCORM 1.2') {
        // Fill values for first time in SCRORM object
        //Need to validate json data before post
        lms_studentId = scorm.get('cmi.core.student_id');
        lms_studentName = scorm.get('cmi.core.student_name');

        //lms_timeSpent = scorm.get('cmi.core.session_time');
        lms_timeSpent = scorm.get('cmi.core.total_time');

        lms_suspendData = scorm.get('cmi.suspend_data');
        lms_completionstatus = scorm.get('cmi.core.lesson_status');   // (possible values: completed, incomplete, passed, failed
        lms_lessonlocation = scorm.get('cmi.core.lesson_location');

        var jsonData = "CaseId=" + knowdl_scorm_package_id + "&StudentId=" + lms_studentId + "&StudentName=" + lms_studentName + "&SuspendedData=" + lms_suspendData + "&LessonLocation=" + lms_lessonlocation + "&CompletionStatus=" + lms_completionstatus + "&TimeSpent=" + lms_timeSpent;
        $.ajax({
            type: 'POST',
            url: "###LMSFullURL###",
            data: jsonData,
            success: function (data) {

            },
            error: function (xhr, data, message) {

            }
        });
    }

    // ***SCORM data post for SCORM 2004 // Rahul 03March-2015 Scorm 2004 Update
    if (gPackageType == 'SCORM 2004') {
        // Fill values for first time in SCRORM object
        //Need to validate json data before post
        lms_studentId = scorm.get('cmi.learner_id');
        lms_studentName = scorm.get('cmi.learner_name');

        //lms_timeSpent = scorm.get('cmi.session_time');
        lms_timeSpent = scorm.get('cmi.total_time');

        lms_suspendData = scorm.get('cmi.suspend_data');
        lms_completionstatus = scorm.get('cmi.completion_status');   // (possible values: completed, incomplete, passed, failed
        lms_lessonlocation = scorm.get('cmi.location');

        var jsonData = "CaseId=" + knowdl_scorm_package_id + "&StudentId=" + lms_studentId + "&StudentName=" + lms_studentName + "&SuspendedData=" + lms_suspendData + "&LessonLocation=" + lms_lessonlocation + "&CompletionStatus=" + lms_completionstatus + "&TimeSpent=" + lms_timeSpent;


        $.ajax({
            type: 'POST',
            url: "###LMSFullURL###",
            data: jsonData,
            success: function (data) {

            },
            error: function (xhr, data, message) {

            }
        });
    }*/

    //Vinod C
    if (pageToLoad.PageContent.Scripts != undefined && pageToLoad.PageContent.Scripts != undefined && pageToLoad.PageContent.Scripts != "") {
        //if (gNavigatedPageIds.indexOf("," + pageToLoad.PageId + ",") == -1)
        //{
        loadScripts(pageToLoad.PageContent.Scripts);
        // }
    }
    else {
        // get the data from pageIdScript.js synchronously
        if (pageToLoad.IsScriptAdded != undefined && pageToLoad.IsScriptAdded != null && pageToLoad.IsScriptAdded == true) {
            pageToLoad.PageContent.Scripts = getDataFromJsFile(pageToLoad.PageId + "Script.js");
            loadScripts(pageToLoad.PageContent.Scripts);
        }
    }
    gSelectedOptionId = "";
    gRankedOptionIdArray = [];

    $(".ui-resizable").removeClass("ui-resizable");
    $(".ui-draggable").removeClass("ui-draggable");
    $(".ui-draggable-dragging").removeClass("ui-draggable-dragging");
    $(".ui-widget-content").removeClass("ui-widget-content");
    $(".TICContent").attr("contenteditable", "false");
    //Anu 12-feb-2015 - Droppable Component
    handleDroppableAndDraggableComp(pageToLoad);




    //Rahul 07-April-2015 to stop audio on start of video
    $(".ContentArea").find("div.video-js").each(function () {
        var videoID = $(this).attr("id");
        if (videoID != undefined && videoID != null && videoID != "") {
            var player = videojs(videoID);
            player.ready(function () {
                this.on("play", function (event) {
                    if ($('.audiocontent').html() != '') {
                        var player = MediaElementPlayer($('.audiocontent').find('audio'));
                        player.pause();
                    }
                });
            });
        }
    });


    $(".ContentArea").find(".k-element-box[temptype='Button']").each(function () {
        var eleBtn = $(this).find('.k-element-button');
        if (eleBtn.attr("rollovertext") != undefined) {
            $(this).qtip({
                content: {
                    text: $("<span style='font-family:arial narrow;color:#FFFFFF;font-size:15px;'>" + $(eleBtn.attr("rollovertext")).text() + "</span>")
                },
                position: {
                    at: 'bottom center',
                    my: 'top center',
                    viewport: $(window)
                },
                style: {
                    classes: 'qtip-tipsy',
                    width: 250,
                    maxWidth: 300
                }
            });
        }
    });
    checkTheme(pageToLoad);
    //end of loadpage

    // show glossary button if required
    if (typeof (gGlossary) != 'undefined') {
        $(".GlossaryIconWrap").show();

    }
    else {
        $(".GlossaryIconWrap").hide();
    }

    // show reference button if required
    if (typeof (gReference) != 'undefined') {
        $(".ReferenceIconWrap").show();

    }
    //Anu 17-apr-2015 page pop up
    //AR 28 April 2015 - Update for add/delete load page popup
    //naveen - popup Preview
    var prevpopup = getParameterByName("prevpopup"); //gp 7 sept 2015 added condition for single page preview
    if (prevpopup != undefined && (prevpopup == true || prevpopup == "true")) {
        prevpopup = true;
    }
    else
    {
        prevpopup = false;
    }
    if (prevpopup) {
        fShowPopupPreview();
    } else {
    if (pageToLoad.PagePopUp != undefined && pageToLoad.PagePopUp != "") {
        if (pageToLoad.LoadPagePopupAlways != undefined && (pageToLoad.LoadPagePopupAlways == true || pageToLoad.LoadPagePopupAlways == "true")) {
            //For Scorm Review Mode
            if (typeof fCheckScormReviewMode == 'function') {
              var isReview = fCheckScormReviewMode();
                if(isReview){
                    return false;
                  }
              }
            fshowRefQtipPopup(pageToLoad.PagePopUp);
        }
        else if (gNavigatedPageIds.indexOf("," + pageToLoad.PageId + ",") == -1) {
            if (typeof fCheckScormReviewMode == 'function') {
              var isReview = fCheckScormReviewMode();
                if(isReview){
                    return false;
                  }
              }
            fshowRefQtipPopup(pageToLoad.PagePopUp);

            }
        }
    }
    gNavigatedPageIds = gNavigatedPageIds + "," + gCurrPageObj.PageId + ",";
    //Anu 29-apr-2015 score for scorecard parameter
    resetPageScore();
    showSimScore(false);
    if (typeof fgetscrollposition == 'function') {
			fgetscrollposition();
	}
    ////RA-24Dec15-TabIndex
    if (/Edge/.test(navigator.userAgent)) {
        setTimeout(function(){
            $(".ContentArea").find(".k-element-box").each(function () {
                var _kElement = $(this);
                setAccessibilityData(_kElement);
            });
        },50)
    }
    else {
        $(".ContentArea").find(".k-element-box").each(function () {
            var _kElement = $(this);
            setAccessibilityData(_kElement);
        });
    }


    if (typeof changeTableStructure == 'function') {
        changeTableStructure();
    }

    if(typeof k_Cust_LoadPageContentComplete == 'function')
    {
        k_Cust_LoadPageContentComplete();
    }

    //add attr aria-hidden="true" for hidden div's.
    SetAriaHidden();

    removeUIClasses();
    removeUIObjects();
    //Revel lifecycleevent onLoad.
    if(IsRevel()){LifeCycleEvents.OnLoadFromPlayer();}

    //Update branding bar clone height
    setTimeout(function () { $(".BrandingBarClone").css("height", $(".BrandingBarContainer ").height()) }, 0);
	//Update release module attempt data. //Need to check data posting for scorm - should be last statement in load page content
    fUpdateAttemptDetails();

}
//end LoadPageContent()

$('#GlossaryIcon').live('click', function (event) {
    ShowGlossary(gGlossaryPage);
});
$('#ReferenceIcon').live('click', function (event) {
    ShowReference(gReferencePage);
});

//gp 15 april added for assessment
var actionCounter = 0;
var currentActionStep = {};
var cellFormulaArray = [];
function DisplayNextActionButton() {
    if (gCurrPageObj.NextPageId != undefined && gCurrPageObj.NextPageId != null && gCurrPageObj.NextPageId != "") {
        //$(".nextAction").show();
        //$(".successMsg").html("<b>Success!</b> You have completed this task successfully.<br /><br />");
        //$(".nextMsg").html("Please click <b>Next</b> to continue.<br/><br/>");
        //$("#btnNextExcelAction").show();
    }
    else {
        //$(".nextAction").show();
        //$(".successMsg").html("<b>Congrats!</b> You have completed all the tasks in this demo.");
        //$(".nextMsg").html("");
        //$("#btnNextExcelAction").hide();
    }
}
function SetExcelAction() {
    currentActionStep = null;
    if (gCurrPageObj.ActionBuilders != undefined && gCurrPageObj.ActionBuilders != null) {
        if (actionCounter == 0) {
            $(".nextAction").hide();
            $(".actionInstruction").empty();
            $(".actionInstruction").html(gCurrPageObj.ActionBuilders.InstructionText);
        }
        if (gCurrPageObj.ActionBuilders.Steps.length > 0 && actionCounter < gCurrPageObj.ActionBuilders.Steps.length) {
            currentActionStep = gCurrPageObj.ActionBuilders.Steps[actionCounter];
            actionCounter++;
            if (currentActionStep.Instruction != undefined && currentActionStep.Instruction != null) {
                $(".actionSteps ul").append("<li>" + currentActionStep.Instruction + "</li>");
            }
            if ($(".instructionPanel").hasScrollBar()) {
                $('.instructionPanel').scrollTop($('.instructionPanel')[0].scrollHeight);
            }
            if (actionCounter == gCurrPageObj.ActionBuilders.Steps.length) {
                currentActionStep.IsLastStep = true;
                if (currentActionStep.ValidationAction == undefined || currentActionStep.ValidationAction == "" || currentActionStep.ValidationAction == "Select Action") {
                    DisplayNextActionButton();
                }
            }
            if (currentActionStep.hasCRef == undefined || currentActionStep.hasCRef == false || currentActionStep.hasCRef == "false") {
                currentActionStep.CorrectRefId = gCurrPageObj.ActionBuilders.Steps[0].CorrectRefId;
            }
            if (currentActionStep.hasICRef == undefined || currentActionStep.hasICRef == false || currentActionStep.hasICRef == "false") {
                currentActionStep.InCorrectRefId = gCurrPageObj.ActionBuilders.Steps[0].InCorrectRefId;
            }
        }
    }
}
(function ($) {
    $.fn.hasScrollBar = function () {
        return this.get(0).scrollHeight > this.height();
    }
})(jQuery);
function LoadExcelPageContent(pageToLoad, contentArea) {
    return; // vb commented
    isLastStep = false;
    actionCounter = 0;
    currentActionStep = null;
    $(".nextAction").hide();
    $(".actionInstruction").empty();
    $(".actionSteps ul").empty();
    SetExcelAction();
    htmlContent = $("#Template_Excel").html();
    contentArea.empty();
    contentArea.append(htmlContent);
    contentArea.find("#excelFrame").attr("src", "ExcelDemo/demo/Excel.html?rnd=" + Math.random());
}
var QuestionArray = [];

function LoadAssessmentPageContent(pageToLoad, contentArea) {

    $(".TSideBar").hide();

    htmlContent = GetTemplateString(pageToLoad, $("#Template_Assessment").html());
    /*DDeva:�v3.1.0:slide in nav menu*/
    var devicewidth = BreakPoint_HIGH; //contentArea.width();
    var obj = $(htmlContent);
    var col_org_wd, col_org_ht, col_cal_wd, col_cal_ht;
    var quesDiv;
    QuestionArray = [];
    obj.find(".k-element-box").each(function () {
        if (!$(this).closest(".band").is(':first-child')) {
            $(this).css({ "height": "", "position": "" });
        }
    });
    obj.find(".k-element-box-clone").each(function () {
        if ($(this).closest(".qtextdata").length <= 0) {
            if ($(this).attr("temptype") == "Text") {
                //$(this).css({ "height": "", "position": "" });
                $(this).css({}); // Rahul 11Feb-2015 to solve poll question component issue
            }
        }
    });


    obj.find(".qtext").each(function () {
        $(this).css({ "width": "" });

    });

    obj.find(".k-element-question").each(function () {
        $(this).closest(".band").addClass("questionBand");
        //gp 28april 2015 added for assessment
        if (pageToLoad.HideQuestionNumber != undefined && pageToLoad.HideQuestionNumber == true)//hide question number
        {
            $(this).find(".qno").hide();
        }
    });
    if (pageToLoad.ShowRandomQuestions == true) {  //display random option/question

        var questionBands = obj.find(".questionBand");
        var indexArray = [];
        for (i = 0; i < questionBands.length ; i++) {
            indexArray.push(i);
        }
        indexArray.sort(function () { return 0.5 - Math.random() });
        obj.find(".questionBand").remove();

        for (i = 0; i < indexArray.length ; i++) {
            //obj.find(".band:last").after(questionBands[indexArray[i]]);
            obj.find(".assessmentFooter").before(questionBands[indexArray[i]]);
        }
        var i = 0;
        obj.find(".questionBand").each(function () {
            $(this).find(".qno").text((i + 1) + ")");
            i++;
        });
    }
    if (pageToLoad.ShowRandomOptions == true) {

        obj.find(".k-element-question").each(function () {
            var options = $(this).find(".optionrow");

            var indexArray = [];
            for (i = 0; i < options.length ; i++) {
                indexArray.push(i);
            }
            indexArray.sort(function () { return 0.5 - Math.random() });
            $(this).find(".optionrow").remove();
            $(this).find(".optspace").remove();
            var table = $(this).find(".qtextdata").closest("tbody");
            var optformat = $(this).attr("optformat");
            var outspace = '<tr class="optspace"></tr>';
            for (i = 0; i < indexArray.length ; i++) {
                var option = options[indexArray[i]];
                table.append(option);
                table.append(outspace);
            }
            if (optformat != "bullet") {
                var i = 0;
                $(this).find(".optionrow").each(function () {
                    var OptNumberText = GetOptionNumberText(optformat, i);
                    $(this).find(".optno").text(OptNumberText);
                    i++;
                })
            }

        });
    }
    obj.find(".k-element-strip").remove();
    obj.find(".k-element-text").attr("contenteditable", "false");
    obj.find(".k-element-textentry").attr("contenteditable", "true");
    obj.find("span.colNum").remove();
    obj.find("span.colWdt").remove();
    obj.find("span.colHght").remove();
    obj.find(".k-asset-Resize").remove();
    obj.find(".block-controls").remove(); //will remove k-element-handle,k-element-delete,k-element-edit,k-element-copy

    obj.find(".ui-resizable-handle").remove();

    contentArea.empty();
    contentArea.append(obj);
    //gp 28april 2015 added for assessment
    contentArea.find(".k-element-box[temptype='Image']").each(function (index) {
        addImageOriginalHeightAndWidthToBox($(this));
    });
    CEPShowHotspots(pageToLoad);
    //Initialize videojs player
    contentArea.find(".k-element-video").each(function (index) {
        var wt = $(this).closest(".k-element-box").width();
        var ht = $(this).closest(".k-element-box").height();
        var fsrc = $(this).attr("fsrc");
        var ftype = $(this).attr("ftype");
        fLoadVideoJsPlayer($(this), undefined, { "src": fsrc, "vidtype": ftype, "wt": wt, "ht": ht });
    });

    contentArea.find(".k-element-video-clone").each(function (index) {
        var wt = $(this).closest(".k-element-box-clone").width();
        var ht = $(this).height();
        var fsrc = $(this).attr("fsrc");
        var ftype = $(this).attr("ftype");
        fLoadVideoJsPlayer($(this), undefined, { "src": fsrc, "vidtype": ftype, "wt": wt, "ht": ht });
    });

    //Rahul 12-jan-2015 - Audio Component
    contentArea.find(".k-element-audio").each(function (index) {
        var wt = $(this).closest(".k-element-box").width();
        $(this).empty();
        InitializeAudioJs($(this), wt);
    });

    //Rahul 12-jan-2015 - Audio Component
    contentArea.find(".k-element-audio-clone").each(function (index) {
        var wt = $(this).closest(".k-element-box-clone").width();
        $(this).empty();
        InitializeAudioJsClone($(this), wt);
    });


    if (!pageToLoad.ShowAllQuestions) {
        contentArea.find(".band").each(function () {
            var _ths = $(this);

            if (!_ths.is(':first-child') && !_ths.hasClass('assessmentFooter')) {//gp 28april 2015 added for assessment
                _ths.css({ "position": "absolute", "left": pageToLoad.QuestionPositionX + "px", "top": pageToLoad.QuestionPositionY + "px", "width": _ths.find(".column").width(), "width": "100%", "height": "" });

                if (pageToLoad.Assessment === true) {
                    _ths.css({ "display": "none" });
                }
            }
            else {
                _ths.find(".k-element-box").each(function () {
                    $(this).css({ "z-index": "0" });
                });
            }
            // Show 1st question by default
            if (_ths.is(':nth-child(2)')) {
                _ths.show();
                quesDiv = _ths;

            }
        });
        var i = 0;
        var seperateNextButton = pageToLoad.SeperateNextButton != undefined && pageToLoad.SeperateNextButton == true ? true : false;
        var disablePrev = pageToLoad.DisablePreviousQuestion != undefined && pageToLoad.DisablePreviousQuestion == true ? true : false;
        var showSummary = pageToLoad.ShowSimulationSummary != undefined && pageToLoad.ShowSimulationSummary == true ? true : false;
        //AR 19 May 2015 - To show instruction one by one
        var showInstructionOneByOne = pageToLoad.ShowInstructionOneByOne;
        contentArea.find(".column").each(function () {
            var _ths = $(this);
            if (!_ths.closest(".band").is(':first-child') && !_ths.closest(".band").hasClass('assessmentFooter')) {
                _ths.css({ "height": "" });
                //gp 22 april 2015 changed to hide previous button of question

                if (!seperateNextButton) {
                    if (disablePrev) {
                        _ths.append('<input type="button" class="btnAssessSubmit" onClick="saveAssessmentLocal(this , true,' + i + ',' + showSummary + ',' + showInstructionOneByOne + ')" value="Submit" />');
                    }
                    else {
                        _ths.append('<input type="button" id="btnPreviousQuestion" value="Go to previous question" disabled="disabled"> <input type="button" class="btnAssessSubmit" onClick="saveAssessmentLocal(this , true,' + i + ',' + showSummary + ',' + showInstructionOneByOne + ')" value="Submit" />');
                    }
                }
                else {
                    if (disablePrev) {
                        _ths.append('<input type="button" class="btnAssessSubmit" onClick="SaveAssessmentAnswer(this ,' + i + ',' + showSummary + ')" value="Submit" /><input type="button" class ="btnAssessmentNext" onClick="AssessmentNextQuestion(this,' + i + ',' + showSummary + ',' + showInstructionOneByOne + ')" value="Next" />');
                    }
                    else {
                        _ths.append('<input type="button" id="btnPreviousQuestion" value="Go to previous question" disabled="disabled"> <input type="button" class="btnAssessSubmit" onClick="saveAssessmentLocal(this , true,' + i + ',' + showSummary + ',' + showInstructionOneByOne + ')" value="Submit" />');
                    }
                }
                i++;
            }
        });

        //AR 9 Sept 2015 - Place assessment footer after submit button to avoid overlap
        var top = $(".ContentArea").find(".questionBand").position().top;
        if (top != undefined) {
            $(".ContentArea").find(".assessmentFooter").css({ "top": top + "px" });
        }
    }
    else {
        //AR 9 Sept 2015 - Place assessment footer after submit button to avoid overlap
        contentArea.find(".assessmentFooter").before('<input type="button" class="btnAssessSubmit btnAssessSubmitAllQuestion" onClick="saveAssessmentLocal(this,false)" value="Submit" />');
        contentArea.find(".k-element-box").each(function (index) {
            $(this).css({ "position": "absolute" });
        });
    }





    $(".ui-widget-content").removeClass("ui-widget-content");
    //30-oct-2014-Anu-poll-start time
    gPollStartTime = new Date();
    contentArea.find("input:checked").removeAttr("checked");
    contentArea.find("tr.selected").removeClass("selected");

    if (pageToLoad.Assessment === true) {
        if (gRMAttemptData.TrackingData != undefined) {
            if (gRMAttemptData.TrackingData.length > 0) {
                for (var i = 0; i < gRMAttemptData.TrackingData.length; i++) {
                    if (gRMAttemptData.TrackingData[i].PageId == pageToLoad.PageId) {
                        $(".band").hide();
                        $(".band:first-child").show()
                        contentArea.find(".TbodyText").append($(gRMAttemptData.TrackingData[i].scorecard));
                        $("#k-element-text2626").closest(".k-element-box").hide();
                        //$("#k-element-text2640").closest(".k-element-box").show();
                    }
                }

            }
        }
    }
    if (gCurrPageObj.AssessmentAsSimulation != undefined && gCurrPageObj.AssessmentAsSimulation == true) {
        contentArea.find(".TbodyText").addClass("TbodyTextAssessment");
        $(".TSideBar").show();

        var cAHeight = contentArea.outerHeight();
        if (cAHeight != undefined) {
            $(".TSideBar").css({ "height": cAHeight + "px" });
        }
        var heading = "<div class='quesInstructionHeader'>Instructions</div>";
        $(".TSideBar").append(heading);
        if (quesDiv != undefined && quesDiv != null) {
            DisplayQuestionInstruction(quesDiv);
        }
    }
    //AR 19 May 2015 - To show instruction one by one
    if (gCurrPageObj.ShowInstructionOneByOne == true) {
        var isReviewMode=false;
        if (typeof fCheckScormReviewMode == 'function') {
            isReviewMode = fCheckScormReviewMode();
        }
        if (!isReviewMode) {
            var heading = "Instructions";
            quesInstruction = obj.find(".k-element-question").attr("questioninstruction");

            if (quesInstruction != undefined) {
                //AR NOTE:This is a temporary popup - Will need to create a functionality like "Edit page load popup"
                $(".TSideBar").find(".quesionInstruction").remove();
                $(".TSideBar").empty();
                var refText = "";
                refText = "<div style='display:none'><div id='instructionDiv' style='left:11px;top:11px;width:493px;height:325px;'><span style='font-size:20px;padding:15px;'><span style='font-family:arial narrow;'><span style='color:#333;'><b>" + questionShortTitles[0] + "</b></span></span></span><p></p><br/><p style='padding:15px'><span style='font-size:16px;'><span style='font-family:arial narrow;'><span style='color:#333;'>" + quesInstruction + "</span></span></span></p><div class='k-element-box' temptype='Button' style='z-index: 2; position: absolute; left: 405px; top: 295px; padding: 3px; border-radius: 5px; width: 71px; height: 24px; border-color: rgb(0, 0, 0); border-width: 0px; opacity: 1; background-color: rgb(20, 189, 212);' sizeprop='FTC' defaultvisibility='Visible'><div class='k-element-button div-edit-properties' contenteditable='false' id='instructionButton' onclick='$.fancybox.close();' btn-type='ELLiP' image-avail='false' img-dname='' action-type='SCRIPT' action-value='' style='width: 71px; height: 24px;padding:0px;'><img class='lblImg dis-none'><span class='lbl' style='float:none;'><p><strong><span style='font-size:16px;'><span style='font-family:arial narrow;'><span style='color:#333;'>Next</span></span></span></strong></p></span></div></div></div></div>";

                $(".TSideBar").append(refText);
                //NM-25-09-2017-AR- IT Sim 2016 - Assessment Change.
                var showCustomLoadPopup = false;
                if ((gPackageType == 'SCORM 1.2' || gPackageType == 'SCORM 2004')) {
                  var suspend_data = scorm.get('cmi.suspend_data');
                  if(suspend_data != ""){
                   suspend_data = JSON.parse(suspend_data);
                   if(typeof suspend_data.showCustomLoadPopup != "undefined" && suspend_data.showCustomLoadPopup == "true"){
                      showCustomLoadPopup = true;
                   }
                  }
                }
                if(!showCustomLoadPopup){
                    $.fancybox({
                        content: $('#instructionDiv'),
                        modal: true
                    });
                }
                //End
            }
        }
    }
    if (typeof setCustomAssessmentView == 'function') {
        setCustomAssessmentView();
    }
    //For Scorm Review Mode
    if (typeof fSetScormReviewMode == 'function') {
            fSetScormReviewMode();
    }
}

//gp 15 april added for assessment
function LoadPollPageContent(pageToLoad, contentArea) {
    $(".btnpollingdone").parent().show();
    htmlContent = GetTemplateString(pageToLoad, $("#Template_Poll").html());
    //htmlContent = htmlContent.replace(/&#8203/g, "")
    /*DDeva:�v3.1.0:slide in nav menu*/
    var devicewidth = BreakPoint_HIGH; //contentArea.width();
    var obj = $(htmlContent);

    var col_org_wd, col_org_ht, col_cal_wd, col_cal_ht;

    obj.find(".band").each(function () {
        var _ths = $(this);

        if (!_ths.is(':first-child')) {
            _ths.css({ "position": "", "left": pageToLoad.QuestionPositionX + "px", "top": pageToLoad.QuestionPositionY + "px", "width": _ths.find(".column").width(), "width": "100%", "height": "" });

            if (pageToLoad.Assessment === true) {
                _ths.css({ "display": "none" });
            }
        }
        else {
            _ths.find(".k-element-box").each(function () {
                $(this).css({ "z-index": "0" });
            });
        }
        // Show 1st question by default
        if (_ths.is(':nth-child(2)')) {
            _ths.show();
        }
    });

    obj.find(".column").each(function () {
        var _ths = $(this);
        if (!_ths.closest(".band").is(':first-child')) {
            _ths.css({ "height": "" });
            if (pageToLoad.Assessment === true) {
                _ths.append('<input type="button" class="btnAssessSubmit" onClick="saveAssessmentLocal(this)" value="Submit" />');
            }
        }
    });
    obj.find(".k-element-box").each(function () {
        if (!$(this).closest(".band").is(':first-child')) {
            $(this).css({ "height": "", "position": "" });
        }
    });
    obj.find(".k-element-box-clone").each(function () {
        if ($(this).closest(".qtextdata").length <= 0) {
            if ($(this).attr("temptype") == "Text") {
                //$(this).css({ "height": "", "position": "" });
                $(this).css({}); // Rahul 11Feb-2015 to solve poll question component issue
            }
        }
    });

    obj.find(".opttext").each(function () {
        // $(this).css({ "height": "" }); // Rahul 11Feb-2015 to solve poll question component issue
    });
    obj.find(".qtext").each(function () {
        $(this).css({ "width": "" });

    });

    obj.find(".k-element-strip").remove();
    obj.find(".k-element-text").attr("contenteditable", "false");
    obj.find(".k-element-textentry").attr("contenteditable", "true");
    obj.find("span.colNum").remove();
    obj.find("span.colWdt").remove();
    obj.find("span.colHght").remove();
    obj.find(".k-asset-Resize").remove();
    obj.find(".block-controls").remove(); //will remove k-element-handle,k-element-delete,k-element-edit,k-element-copy

    obj.find(".ui-resizable-handle").remove();

    contentArea.empty();
    contentArea.append(obj);
    CEPShowHotspots(pageToLoad);
    //Initialize videojs player
    contentArea.find(".k-element-video").each(function (index) {
        var wt = $(this).closest(".k-element-box").width();
        var ht = $(this).closest(".k-element-box").height();
        var fsrc = $(this).attr("fsrc");
        var ftype = $(this).attr("ftype");
        fLoadVideoJsPlayer($(this), undefined, { "src": fsrc, "vidtype": ftype, "wt": wt, "ht": ht });
    });

    contentArea.find(".k-element-video-clone").each(function (index) {
        var wt = $(this).closest(".k-element-box-clone").width();
        var ht = $(this).height();
        var fsrc = $(this).attr("fsrc");
        var ftype = $(this).attr("ftype");
        fLoadVideoJsPlayer($(this), undefined, { "src": fsrc, "vidtype": ftype, "wt": wt, "ht": ht });
    });

    //Rahul 12-jan-2015 - Audio Component
    contentArea.find(".k-element-audio").each(function (index) {
        var wt = $(this).closest(".k-element-box").width();
        $(this).empty();
        InitializeAudioJs($(this), wt);
    });

    //Rahul 12-jan-2015 - Audio Component
    contentArea.find(".k-element-audio-clone").each(function (index) {
        var wt = $(this).closest(".k-element-box-clone").width();
        $(this).empty();
        InitializeAudioJsClone($(this), wt);
    });

    //validateInputField(); // Rahul 17-Feb-2015 - Text Entry Component


    if (pageToLoad.ConfirmText != undefined && pageToLoad.ConfirmText != "") {
        $(".btnpollingdone").html(pageToLoad.ConfirmText);
        if (pageToLoad.Assessment === true) {
            $(".btnpollingdone").parent().hide();
        }
    }
    $(".ui-widget-content").removeClass("ui-widget-content");
    //30-oct-2014-Anu-poll-start time
    gPollStartTime = new Date();
    contentArea.find("input:checked").removeAttr("checked");
    contentArea.find("tr.selected").removeClass("selected");

    if (pageToLoad.Assessment === true) {

        //_ths.append('<input type="button" onClick="saveAssessmentLocal(this)" value="Submit" />');
        if (gRMAttemptData.TrackingData != undefined) {
            if (gRMAttemptData.TrackingData.length > 0) {
                for (var i = 0; i < gRMAttemptData.TrackingData.length; i++) {
                    if (gRMAttemptData.TrackingData[i].PageId == pageToLoad.PageId) {
                        $(".band").hide();
                        $(".band:first-child").show()
                        contentArea.find(".TbodyText").append($(gRMAttemptData.TrackingData[i].scorecard));
                        $("#k-element-text2626").closest(".k-element-box").hide();
                        //$("#k-element-text2640").closest(".k-element-box").show();
                    }
                }

            }
        }
    }
}

function LoadCEPPageContent(pageToLoad, contentArea) {
    window.scrollTo(0, 0);

    htmlContent = GetTemplateString(pageToLoad, $("#Template_CEP").html());
    /*DDeva:�v3.1.0:slide in nav menu*/
    //var devicewidth = BreakPoint_HIGH; //contentArea.width();
    var devicewidth = gCaseProperties.StageSize;
    var obj = $(htmlContent);
    var col_org_wd, col_org_ht, col_cal_wd, col_cal_ht;
    //nav-device - column will always 100%
   /* obj.find(".column").each(function () {
        $(this).css({
            "width": "100%"
                , "position": "relative"
        });
    });*/
    //end
    obj.find(".column").each(function () {
        var ths_column = $(this);
        var ieversion = msieversion();
        /*var pixels = wd * (1024 / 100);*/
        if (ieversion == 9 || ieversion == 8) {
            ths_column.find(".k-element-box[temptype='Image']").each(function () {
                $(this).attr("originaltop", $(this).css('top'));
                $(this).attr("originalleft", $(this).css("left"));
            });
            ths_column.find(".k-element-box[temptype='Button']").each(function () {
                $(this).css({
                    "cursor": "pointer"
                   , "box-sizing": "content-box"
                });
            });
            return;
        }
        col_org_wd = ths_column.outerWidth();
        col_org_ht = ths_column.outerHeight();
        col_cal_wd = getPerc(col_org_wd, devicewidth);

        // VinodBonde -- make changes here to increase the height of the row based on the actual text height and the container height
        // button component
        //nav-device 03june2016
        /*ths_column.find(".k-element-box[temptype='Button']").each(function () {
            if (Number($(this).width()) > 0) {
                $(this).css({
                    "position": "absolute",
                    "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
                });
            }
            $(this).css({
                 "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
            });
            $(this).removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
        });

        // checklist
        /*ths_column.find(".k-element-box[temptype='Checklist']").each(function () {

            $(this).css({
                "position": "absolute",
                "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
              , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
            });

            $(this).removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
        });
        // Droppable
ths_column.find(".k-element-box[temptype='Droppable']").each(function () {

    $(this).css({
        "position": "absolute",
        "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
      , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
    });

    $(this).removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
});

        //Text component
        ths_column.find(".k-element-box[temptype='Text']").each(function () {

            $(this).css({
                "position": "absolute",
                "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
              , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
            });

            $(this).removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
        });*/
        //end
        // Rahul 17-Feb-2015 - Text Entry Component
        ths_column.find(".k-element-box[temptype='TextEntry']").each(function () {
            /*$(this).css({
                "position": "absolute",
                "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
              , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
            });*/
            if (msieversion() == 9 || msieversion() == 10 || isIE11version == true || (/Firefox[\/\s](\d+\.\d+)/.test(navigator.userAgent))) {
                $(this).find(".k-element-textentry").css({ "font-size": "12px" });
            }
            $(this).find(".k-element-textentry").attr("contenteditable", "true");
            $(this).removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
        });
        ths_column.find(".k-element-box[temptype='Image']").each(function () {
            //Rahul 10April-2014 - changed as % conversion not working for Safari
            $(this).attr("originalTop", $(this).css('top'));
            var leftperc = getPerc($(this).css("left"), ths_column.outerWidth());
            $(this).attr("originalLeft", leftperc + "%");
        });
        //nav-device 03june2016
        /*
        //Image component
        ths_column.find(".k-element-box[temptype='Image']").each(function () {
            //Rahul 10April-2014 - changed as % conversion not working for Safari
            $(this).attr("originalTop", $(this).css('top'));
            //$(this).attr("originalLeft", $(this).css('left'));
            var leftperc = getPerc($(this).css("left"), ths_column.outerWidth());
            $(this).attr("originalLeft", leftperc + "%");
            var showContainer = $(this).attr("showContainer");
            if (showContainer == "False" || showContainer == undefined) {
                $(this).css({
                    "height": "",//Commented as it is showing big image in safari.
                    "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
                  , "left": leftperc + "%"
                });
            } else {
                $(this).css({
                    "height": $(this).height() + "px",
                    "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
                  , "left": leftperc + "%"
                  , "overflow": "auto"
                });
            }
            addImageOriginalHeightAndWidthToBox($(this));
            if (showContainer == "False" || showContainer == undefined) {
                $(this).find(".k-element-image").css({ "height": "", "width": "" });
                $(this).find("div.divImageDescription").css({ "width": "100%" });
            } else {
                $(this).find("div.divImageDescription").css({ "width": "100%", "float": "left" });
            }

            $(this).removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
        });

        //videocomponent
        ths_column.find(".k-element-box[temptype='Video']").each(function () {
            var boxht = $(this).height();
            var vidht = $(this).find(".k-element-video").height();

            $(this).css({
                "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
                , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
            });

            $(this).find(".k-element-video").css({
                "width": "100%"
                , "height": getPerc(vidht, boxht) + "%"
            });

            $(this).find("div.divVideoDescription").css({ "width": "100%" });
            $(this).removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
        });
        //Rahul 12-jan-2015 - Audio Component
        ths_column.find(".k-element-box[temptype='Audio']").each(function () {
            $(this).css({
                "height": "30px",
                "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
                , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
            });

            $(this).removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
        });*/
        //end
        //textasset component
        ths_column.find(".k-element-box[temptype='TextAsset']").each(function () {
            var ftextAssetw = $(this).outerWidth() - (this.style.padding.slice(0, -2) * 2);
            var ftextAsseth = $(this).outerHeight() - (this.style.padding.slice(0, -2) * 2);
            var fAssettype = $(this).find(".k-element-textasset").attr("fimgorvideo"); //image or video
            var fimgwd, fimgh;

            //nav-device 03june2016
            /*
            $(this).css({
                "position": "absolute",
                "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
               , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
            });

            if (fAssettype == "image") {
                fimgwd = $(this).find("img.TIC-img").attr("width");
                fimgh = $(this).find("img.TIC-img").attr("height");
            }
            else if (fAssettype == "video") {
                fimgwd = $(this).find("div.textVideo").css("width");
                fimgh = $(this).find("div.textVideo").css("height");
            }
            $(this).find("div.TICvidArea.TICImgSec").css({
                "width": getPerc(fimgwd, ftextAssetw) + "%",
                "height": getPerc(fimgh, ftextAsseth) + "%"

            });
            $(this).find("img.TIC-img").removeAttr("width").removeAttr("height").css({
                "width": "100%",
                "height": ""
            });*/
            //end

            $(this).find("div.TICvideoDescription").css({ "width": getPerc($(this).find("div.TICvideoDescription").width(), fimgwd) + "%" });
            $(this).find("div.textVideo").css({ "width": "100%" });
            var descriptionText = getCkeText($(this).find("div.TICvideoDescription").text());
            if (descriptionText == "") {
                $(this).find("div.TICvideoDescription").css("display", "none");
            }
            $(this).removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
        });

        ths_column.attr("ow", col_org_wd);
        ths_column.attr("oh", col_org_ht);
        //nav-device 03june2016
        /*
        if (parseInt(col_org_wd) > parseInt(devicewidth)) {
            col_cal_ht = 100 * col_org_ht / col_org_wd;
            ths_column.css({
                "width": "100%"
                , "position": "relative"
            });

        }
        else {
            col_cal_ht = col_cal_wd * col_org_ht / col_org_wd;
            var margin = "auto";
            if (navigator.userAgent.indexOf("Firefox") != -1) {
                margin = ((100 - col_cal_wd) / 2) + "%";
            }
            ths_column.css({
                "width": col_cal_wd + "%",
                "margin": "auto " + margin ,
                "position": "relative"
            });
        }*/
        //end
        //remove column data as column itself is relative to hold absolute divs.
        ths_column.html(ths_column.find(".column-Data").html());
        ths_column.removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
    });
    obj.find(".band").each(function () {
        $(this).css({ "width": "100%", "height": "auto" });
    });
    obj.find(".k-element-strip").remove();
    obj.find(".k-element-text").attr("contenteditable", "false");
    obj.find(".k-element-textentry").attr("contenteditable", "true");
    obj.find("span.colNum").remove();
    obj.find("span.colWdt").remove();
    obj.find("span.colHght").remove();
    obj.find(".k-asset-Resize").remove();
    obj.find(".block-controls").remove(); //will remove k-element-handle,k-element-delete,k-element-edit,k-element-copy

    obj.find(".ui-resizable-handle").remove();

    contentArea.empty();
    contentArea.append(obj);
    CEPShowHotspots(pageToLoad);
    //Initialize videojs player
    contentArea.find(".k-element-video").each(function (index) {
        var wt = $(this).closest(".k-element-box").width();
        var ht = $(this).closest(".k-element-box").height();
        var fsrc = $(this).attr("fsrc");
        var ftype = $(this).attr("ftype");
        fLoadVideoJsPlayer($(this), undefined, { "src": fsrc, "vidtype": ftype, "wt": wt, "ht": ht });
    });

    contentArea.find(".k-element-textasset[fImgOrVideo='video']").each(function (index) {
        var wt = 120; // $(this).closest(".k-element-box").width();
        var ht = 100; // $(this).closest(".k-element-box").height();
        var fsrc = $(this).attr("fsrc");
        var ftype = $(this).attr("ftype");
        fLoadtextVideoJsPlayer($(this), undefined, { "src": fsrc, "vidtype": ftype, "wt": wt, "ht": ht });
    });

    //Rahul 12-jan-2015 - Audio Component
    contentArea.find(".k-element-box[temptype='Audio']").each(function () {
        var wt = $(this).closest(".k-element-box").width();
        var audWrapper = $(this).find(".k-element-audio");
        InitializeAudioJs(audWrapper, wt);
    });

    //Rahul 16Feb2015 - commnented as per feedback
    contentArea.find(".k-element-box[temptype='Button']").each(function () {
        var defaultBgColor = $(this).css("background-color");
        var hoverColor = $(this).find('.k-element-button').attr("selstatecolor");
        $(this).attr("origBGColor11", defaultBgColor);
        if (hoverColor != undefined) {
            var bg = "0 0 24px -5px " + hoverColor;
        } else {
            var bg = "0 0 24px -5px " + defaultBgColor;
        }
        $(this).css({ "opacity": "" });
    });




    //validateInputField(); // Rahul 17-Feb-2015 - Text Entry Component
    //ApplyAutoAdjustment();

    //Set Height of container to maxheight. traverse throught container. In custom page it is column.
    contentArea.find(".column").each(function () {
        //setMaxHeightToContainer($(this));
    });
    //nav-device 03june16
    removeUIClasses();
    removeUIObjects();
    //end
}
$(".k-element-box[temptype='Button']").die('mouseover').live('mouseover',
             function () {
                var defaultBgColor = $(this).css("background-color");
                var hoverColor = $(this).find('.k-element-button').attr("selstatecolor");
                var bg = "";
                //$(this).attr("origBGColor11", defaultBgColor);
                if (hoverColor != undefined) {
                    bg = "0 0 24px -5px " + hoverColor;
                } else {
                     bg = "0 0 24px -5px " + defaultBgColor;
                }
                 if (!$(this).hasClass("selstatecolor")) {
                     $(this).css({ "-webkit-box-shadow": bg });
                     $(this).css({ "-moz-box-shadow": bg });
                     $(this).css({ "box-shadow": bg });
                     $(this).css({ "background-color": bg });
                 }
                 if (!$(this).hasClass("rollovereffect")) {
                     //Anu 12-may-2016 btn text rollover color & img
                     var _ths = $(this).find('.k-element-button');
                     var rollOverClr = _ths.attr("txtrollovercolor");
                     var rollOverImg = _ths.attr("RollOverImgSrc");
                     var isImgAvail = _ths.attr("image-avail");
                     if (isImgAvail == "true") {
                         if (rollOverImg != undefined && rollOverImg != "" && rollOverImg != _ths.find(".lblImg").attr("src")) {
                             var _fsrc = _ths.find(".lblImg").attr("src");
                             _ths.find(".lblImg").attr("src", rollOverImg);
                             _ths.attr("orignalSrc", _fsrc);
                             console.log("original src set mouse over")
                         }
                     }
                     if (rollOverClr != undefined && rollOverClr != "None" && rollOverClr != _ths.attr("lblforecolor") ) {
                         var _lblInnmostSpan = _ths.find(".lbl").find('span:only-child:last');
                         _ths.attr("lblforecolor", _lblInnmostSpan.css("color"));
                         _lblInnmostSpan.css("color", rollOverClr + " !important;");
                     }
                 }
             });
             $(".k-element-box[temptype='Button']").die('mouseout').live('mouseout',
             function () {
                var defaultBgColor = $(this).css("background-color");
                var hoverColor = $(this).find('.k-element-button').attr("selstatecolor");
                var bg = "";
                //$(this).attr("origBGColor11", defaultBgColor);
                if (hoverColor != undefined) {
                    bg = "0 0 24px -5px " + hoverColor;
                } else {
                     bg = "0 0 24px -5px " + defaultBgColor;
                }
                 if (!$(this).hasClass("selstatecolor")) {
                     $(this).css({ "-webkit-box-shadow": "" });
                     $(this).css({ "-moz-box-shadow": "" });
                     $(this).css({ "box-shadow": "" });
                     $(this).css({ "background-color": defaultBgColor });
                 }
                 //Anu 12-may-2016 btn text rollover color & img
                 if (!$(this).hasClass("rollovereffect")) {
                     var _ths = $(this).find('.k-element-button');
                     var rollOverClr = _ths.attr("txtrollovercolor");
                     var rollOverImg = _ths.attr("RollOverImgSrc");
                     var imgAvail = _ths.attr("orignalSrc");
                     if (imgAvail != undefined && imgAvail != "") {
                         var _fsrc = _ths.find(".lblImg").attr("src");
                         _ths.find(".lblImg").attr("src", imgAvail);
                         _ths.attr("orignalSrc", "");
                         console.log("reseting original src mouse out")
                     }
                     if (rollOverClr != undefined && rollOverClr != "None") {
                         var _lblInnmostSpan = _ths.find(".lbl").find('span:only-child:last');
                         _lblInnmostSpan.css("color", _ths.attr("lblforecolor"));
                     }
                 }
             }
         );
function LoadTIPPageContent(pageToLoad, contentArea) {
    var TvidArea = $(".TvidArea");
    TvidArea.css({ "width": "" });
    var tipTemplate = $("#Template_TIP");
    var htmlPlaceholder = tipTemplate.html();
    if (pageToLoad.PageContent.HAlign == "bottom") {
        //var sChiled = $("#Template_TIP").find(".TbodyText div:eq(2)").remove()
        var sChiled = tipTemplate.find(".TbodyText div.bttext").remove()
        sChiled.css({ "margin-bottom": "10px" });
        tipTemplate.find(".TbodyText").prepend(sChiled);
    }

    var defaultImageWidth = 0;
    htmlContent = GetTemplateString(pageToLoad, tipTemplate.html());
    tipTemplate.html(htmlPlaceholder);

    contentArea.html(htmlContent);
    /*DDeva:�v3.1.0:slide in nav menu*/
    var devicewidth = BreakPoint_HIGH; //contentArea.width();
    if (pageToLoad.PageContent.HAlign != undefined) {
        TvidArea.attr("class", "TvidArea");
        var alignment = pageToLoad.PageContent.HAlign;
        if (alignment == "center" || alignment == "bottom") {
            TvidArea.addClass("fl_n");
            //defaultImageWidth = parseInt($(".ContentArea").outerWidth()) - 40;
        } else if (alignment == "left") {
            TvidArea.addClass("ImgSec-left");
            if (devicewidth < Number(pageToLoad.PageContent.ImageWidth)) {
                TvidArea.css({
                    "width": "100%"
                , "position": "relative"
                });
                $(".TvideoDescription").css({
                    "width": "100%"
                });
            } else {
                TvidArea.css({
                    "width": getPerc(pageToLoad.PageContent.ImageWidth, devicewidth) + "%"
                , "position": "relative"
                });
            }
        } else if (alignment == "right") {
            TvidArea.addClass("ImgSec");
            if (devicewidth < Number(pageToLoad.PageContent.ImageWidth)) {
                TvidArea.css({
                    "width": "100%"
                , "position": "relative"
                });
                $(".TvideoDescription").css({
                    "width": "100%"
                });
            } else {
                TvidArea.css({
                    "width": getPerc(pageToLoad.PageContent.ImageWidth, devicewidth) + "%"
                , "position": "relative"
                });
            }
        }

        if (pageToLoad.PageContent.ImageReference != undefined) {
            /*DDeva:v1.1.2*/
            var tipImage = $("#TIP-img");
            tipImage.attr("src", pageToLoad.PageContent.ImageReference).load(function () {
                var imgWidth = (pageToLoad.PageContent.ImageWidth != undefined && pageToLoad.PageContent.ImageWidth != "" && pageToLoad.PageContent.ImageWidth != null) ? pageToLoad.PageContent.ImageWidth : this.width;
                this.width = imgWidth;
                /*dated 26-mar-2014 display hotspots on image if exist*/
                ShowHotspots(pageToLoad);
            });
        }
        var iwidth = parseInt(pageToLoad.PageContent.ImageWidth);
        var iheight = Math.round(iwidth / parseFloat(pageToLoad.PageContent.ImageAspectRatio));
        tipImage.parent().attr("original-height", iheight);
        tipImage.parent().attr("original-width", iwidth);
        $("#TIP-img").parent().css({ "height": iheight, "width": iwidth });

    }
}
function LoadSMPPageContent(pageToLoad, contentArea) {
    //var TvidArea = $(".TvidArea");
    var smpTemplate = $("#Template_SMP");
    var htmlPlaceholder = smpTemplate.html();
    if (pageToLoad.PageContent.HAlign == "bottom") {
        var sChiled = smpTemplate.find(".TbodyText div.bttext").remove()
        sChiled.css({ "margin-bottom": "10px" });
        smpTemplate.find(".TbodyText").prepend(sChiled);
    }

    htmlContent = GetTemplateString(pageToLoad, $("#Template_SMP").html());
    smpTemplate.html(htmlPlaceholder);

    contentArea.html(htmlContent);

    if (pageToLoad.PageContent.HAlign != undefined) {
        $(".TvidArea").attr("class", "TvidArea");
        var alignment = pageToLoad.PageContent.HAlign;
        if (alignment == "center" || alignment == "bottom") {
            $(".TvidArea").addClass("fl_n");
        } else if (alignment == "left") {
            $(".TvidArea").addClass("ImgSec-left");
        } else if (alignment == "right") {
            $(".TvidArea").addClass("ImgSec");
        }
        if (pageToLoad.PageContent.ImageReference != undefined) {
            $("#SMP-img").attr("src", pageToLoad.PageContent.ImageReference).load(function () {
                var imgWidth = (pageToLoad.PageContent.ImageWidth != "" || pageToLoad.PageContent.ImageWidth != null) ? pageToLoad.PageContent.ImageWidth : this.width;
                this.width = imgWidth;
                $(".TvideoDescription").css("width", imgWidth);
            });
        }

    }
    removeUIClasses();
    removeUIObjects();
}
function LoadTVPPageContent(pageToLoad, contentArea) {
    var TvidArea = $(".TvidArea");
    var tvpTemplate = $("#Template_TVP");
    TvidArea.css({ "width": "" });
    var htmlPlaceholder = tvpTemplate.html();
    if (pageToLoad.PageContent.HAlign == "bottom") {
        //var sChiled = $("#Template_TVP").find(".TbodyText div:eq(4)").remove()
        var sChiled = tvpTemplate.find(".TbodyText div.bttext").remove()
        sChiled.css({ "margin-bottom": "10px" });
        tvpTemplate.find(".TbodyText").prepend(sChiled);
    }
    htmlContent = GetTemplateString(pageToLoad, $("#Template_TVP").html());
    //Update to original html
    tvpTemplate.html(htmlPlaceholder);
    contentArea.html(htmlContent);
    fLoadVideoJsPlayer($(".ContentArea .TvidArea .jsvideo_tvp"), pageToLoad);
    var defaultImageWidth = 0;
    /*DDeva:�v3.1.0:slide in nav menu*/
    var devicewidth = BreakPoint_HIGH; //contentArea.width();
    if (pageToLoad.PageContent.HAlign != undefined) {
        TvidArea.attr("class", "TvidArea");
        var alignment = pageToLoad.PageContent.HAlign;
        if (alignment == "center" || alignment == "bottom") {
            TvidArea.addClass("fl_n");
            TvidArea.find(".jsvideo_tvp").addClass("fl_n");
            //defaultImageWidth = parseInt($(".ContentArea").outerWidth() - 40);
        } else if (alignment == "left") {
            TvidArea.addClass("ImgSec-left");
            TvidArea.find(".jsvideo_tvp").addClass("ImgSec-left");
            if (devicewidth < pageToLoad.PageContent.VideoWidth) {
                TvidArea.css({
                    "width": "100%"
                , "position": "relative"
                });
                $(".TvideoDescription").css({
                    "width": "100%"
                });
            } else {
                TvidArea.css({
                    "width": getPerc(pageToLoad.PageContent.VideoWidth, devicewidth) + "%"
                , "position": "relative"
                });
            }
            //defaultImageWidth = parseInt($(".ContentArea").outerWidth() / 2) - 20;
        } else if (alignment == "right") {
            TvidArea.addClass("ImgSec");
            TvidArea.find(".jsvideo_tvp").addClass("ImgSec");
            if (devicewidth < Number(pageToLoad.PageContent.ImageWidth)) {
                TvidArea.css({
                    "width": "100%"
                , "position": "relative"
                });
                $(".TvideoDescription").css({
                    "width": "100%"
                });
            } else {
                TvidArea.css({
                    "width": getPerc(pageToLoad.PageContent.VideoWidth, devicewidth) + "%"
                , "position": "relative"
                });
            }
            //defaultImageWidth = parseInt($(".ContentArea").outerWidth() / 2) - 20;
        }

        $(".TvideoTitle").css("width", pageToLoad.PageContent.VideoWidth);
        ////videojs

        TvidArea.find(".jsvideo_tvp").css("width", pageToLoad.PageContent.VideoWidth);
        TvidArea.find(".jsvideo_tvp").css("height", pageToLoad.PageContent.VideoWidth / pageToLoad.PageContent.VideoAspectRatio);
        //$(".TvideoDescription").css("width", pageToLoad.PageContent.VideoWidth);

        var vidWidth = (pageToLoad.PageContent.VideoWidth != undefined && pageToLoad.PageContent.VideoWidth != "" && pageToLoad.PageContent.VideoWidth != null) ? pageToLoad.PageContent.VideoWidth : $(".TvidArea").width();
        if (vidWidth > contentArea.outerWidth()) {
            defaultImageWidth = contentArea.width() - 20;
            TvidArea.css({ "width": defaultImageWidth + "px" });
            var defaultImageHeight = (defaultImageWidth / pageToLoad.PageContent.VideoAspectRatio);
            TvidArea.find(".jsvideo_tvp").css("height", defaultImageHeight);
            $TvidArea.find(".jsvideo_tvp").css("width", 100 + "%");
            TvidArea.find(".jsvideo_tvp").find(".video-js").css("width", 100 + "%");
            TvidArea.find(".jsvideo_tvp").find(".vjs-tech").css("width", 100 + "%");
            TvidArea.find(".jsvideo_tvp").find(".video-js").css("height", 100 + "%");
            TvidArea.find(".jsvideo_tvp").find(".vjs-tech").css("height", 100 + "%");
        }
    }
}

function LoadDTPPageContent(pageToLoad, contentArea) {
    window.scrollTo(0, 0);

    htmlContent = GetTemplateString(pageToLoad, $("#Template_DTP").html());
    /*DDeva:�v3.1.0:slide in nav menu*/
    var devicewidth = BreakPoint_HIGH; //contentArea.width();
    contentArea.html(htmlContent);
    SetSelectedOption(pageToLoad);
    var displayFormat = pageToLoad.PageContent.IsSideBySide;

    if (displayFormat == true) {
        $(".TquestDTP").addClass("sidebyside");
        $(".ToptDTP").addClass("sidebyside");
    }
    else {
        $(".TquestDTP").removeClass("sidebyside");
        $(".ToptDTP").removeClass("sidebyside");
    }
    if (pageToLoad.PageContent.OptionListStyle == "bullet") {
        $(".TquestionImg").addClass("ImageBullet");
    }

    $(".ui-resizable-handle").remove() //Class("ui-resizable-handle ui-resizable-se ui-icon ui-icon-gripsmall-diagonal-se");
    $(".ui-resizable-e").remove() //.removeClass("ui-resizable-handle ui-resizable-e");
    $(".ui-resizable-s").remove() //.removeClass("ui-resizable-handle ui-resizable-s");

    var col_org_wd, col_org_ht, col_cal_wd, col_cal_ht;
    $(".qtext ").each(function () {
        var ths_column = $(this);
        col_org_wd = ths_column.outerWidth();
        col_org_ht = ths_column.outerHeight();
        col_cal_wd = getPerc(col_org_wd, devicewidth);

        // VinodBonde -- make changes here to increase the height of the row based on the actual text height and the container height
        //Text component
        ths_column.find(".k-element-box[temptype='Text']").each(function () {

            $(this).attr("contenteditable", "false");
            $(this).css({
                "position": "relative", //"position": "absolute",
                //nav - dtp new changes
                //"width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
                "width": (100 - getPerc($(this).css("left"), ths_column.outerWidth()) ) + "%",
                "top": ""
                , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
            });
        });
        // Rahul 17-Feb-2015 - Text Entry Component
        ths_column.find(".k-element-box[temptype='TextEntry']").each(function () {
            $(this).attr("contenteditable", "true");
            $(this).css({
                "position": "absolute",
                "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
               , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
            });
        });
        //Image component
        ths_column.find(".k-element-box[temptype='Image']").each(function () {
            $(this).css({
                "height": "",
                "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
                , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
            });
            addImageOriginalHeightAndWidthToBox($(this));
            $(this).find(".k-element-image").css({ "height": "", "width": "" });
            $(this).find("div.divImageDescription").css({ "width": "100%" });

        });
        //videocomponent
        ths_column.find(".k-element-box[temptype='Video']").each(function () {
            var boxht = $(this).height();
            var vidht = $(this).find(".k-element-video").height();
            $(this).css({
                "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
                , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
            });

            $(this).find(".k-element-video").css({
                "width": "100%"
                , "height": getPerc(vidht, boxht) + "%"
            });
            $(this).find("div.divVideoDescription").css({ "width": "100%" });

        });
        //Rahul 12-jan-2015 - Audio Component
        ths_column.find(".k-element-box[temptype='Audio']").each(function () {
            $(this).css({
                "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
               , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
            });

        });
        //textasset component
        ths_column.find(".k-element-box[temptype='TextAsset']").each(function () {
            var ftextAssetw = $(this).outerWidth() - (this.style.padding.slice(0, -2) * 2);
            var ftextAsseth = $(this).outerHeight() - (this.style.padding.slice(0, -2) * 2);
            var fAssettype = $(this).find(".k-element-textasset").attr("fimgorvideo"); //image or video
            var fimgwd, fimgh;

            $(this).css({
                //nav - dtp new changes
                //"position": "absolute",
                //"width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
                "position": "relative",
                "width":(100 - getPerc($(this).css("left"), ths_column.outerWidth()) ) + "%",
                "top": ""
                , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
            });
            if (fAssettype == "image") {
                fimgwd = $(this).find("img.TIC-img").attr("width");
                fimgh = $(this).find("img.TIC-img").attr("height");
            }
            else if (fAssettype == "video") {
                fimgwd = $(this).find("div.textVideo").css("width");
                fimgh = $(this).find("div.textVideo").css("height");
            }
            $(this).find("div.TICvidArea.TICImgSec").css({
                "width": getPerc(fimgwd, ftextAssetw) + "%"

            });
            $(this).find("img.TIC-img").removeAttr("width").removeAttr("height").css({
                "width": "100%"
            });


            $(this).find("div.TICvideoDescription").css({ "width": "100%" });
            $(this).find("div.textVideo").css({ "width": "100%" });

            $(this).removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
        });

        ths_column.attr("ow", col_org_wd);
        ths_column.attr("oh", col_org_ht);

        //nav-dtp new changes
        ths_column.removeAttr("style");

        /*
        if (parseInt(col_org_wd) > parseInt(devicewidth)) {
            col_cal_ht = 100 * col_org_ht / col_org_wd;
            ths_column.css({
                "width": "100%"
                , "position": "relative"
            });
        }
        else {
            col_cal_ht = col_cal_wd * col_org_ht / col_org_wd;
            ths_column.css({
                "width": col_cal_wd + "%"
               , "position": "relative"

            });
        }*/
    });

    //nav - DTP new changes
    /*
    if ($(".TquestDTP").css("padding-left") != undefined) {
        if ((parseInt($(".TquestDTP").css("padding-left").slice(0, -2)) + $(".TquestDTP").outerWidth()) > devicewidth) {
            $(".TquestDTP").css("padding", "");

            $(".ToptDTP").css({ "padding-left": "", "padding-right": "" });
            if ($(".TquestDTP").hasClass("sidebyside")) {
                $(".TquestDTP").removeClass("sidebyside");
                $(".ToptDTP").removeClass("sidebyside");
            }
        }
    }*/
    /*Rahul 12Feb2015 - DTP Option margin update*/
    /*
    if (pageToLoad.PageContent.dtpoptionMargin == undefined || pageToLoad.PageContent.dtpoptionMargin == "" || pageToLoad.PageContent.isOptCntrAln == true) {
        $(".ToptDTP").css({ "padding-left": "0px" });
    } else {
        var perPadding = getPerc(Number(pageToLoad.PageContent.dtpoptionMargin), ContainerPixelWidth);
        $(".ToptDTP").css({ "padding-left": perPadding + "%" });
    }
    */
    //end
    $(".ToptDTP").removeAttr("style");


    $(".opttext").each(function () {
        if (pageToLoad.PageContent.OptionListStyle != "none") {
            $(this).css("margin-left", "60px");
        }
        //nav - removed style attr
        $(this).removeAttr("style");

        var ths_column = $(this);
        col_org_wd = ths_column.outerWidth();
        col_org_ht = ths_column.outerHeight();
        col_cal_wd = getPerc(col_org_wd, devicewidth);

        // VinodBonde -- make changes here to increase the height of the row based on the actual text height and the container height
        //Text component
        ths_column.find(".k-element-box[temptype='Text']").each(function () {
            //nav - dtp new changes
            /*
            $(this).attr("contenteditable", "false");
            $(this).css({
                "position": "absolute",
                "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
                , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
            });
            $(this).removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
            */
            $(this).replaceWith($(this).find(".k-element-text"))
            //end
        });
        // Rahul 17-Feb-2015 - Text Entry Component
        ths_column.find(".k-element-box[temptype='TextEntry']").each(function () {
            $(this).css({
                "position": "absolute",
                "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
               , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
            });
            $(this).removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
        });
        //Image component
        ths_column.find(".k-element-box[temptype='Image']").each(function () {
            $(this).css({
                "height": "",
                "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
                , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
            });
            addImageOriginalHeightAndWidthToBox($(this))
            $(this).find(".k-element-image").css({ "height": "", "width": "" });
            $(this).find("div.divImageDescription").css({ "width": "100%" });
            $(this).removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
        });
        //videocomponent
        ths_column.find(".k-element-box[temptype='Video']").each(function () {
            var boxht = $(this).height();
            var vidht = $(this).find(".k-element-video").height();

            $(this).css({
                "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
                , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
            });

            $(this).find(".k-element-video").css({
                "width": "100%"
               , "height": getPerc(vidht, boxht) + "%"
            });
            $(this).find("div.divVideoDescription").css({ "width": "100%" });
            $(this).removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
        });
        //Rahul 12-jan-2015 - Audio Component
        ths_column.find(".k-element-box[temptype='Audio']").each(function () {
            $(this).css({
                "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
                , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
            });
            $(this).removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
        });


        ths_column.find(".k-element-box[temptype='TextAsset']").each(function () {
            var ftextAssetw = $(this).outerWidth() - (this.style.padding.slice(0, -2) * 2);
            var ftextAsseth = $(this).outerHeight() - (this.style.padding.slice(0, -2) * 2);
            var fAssettype = $(this).find(".k-element-textasset").attr("fimgorvideo"); //image or video
            var fimgwd, fimgh;

            $(this).css({
                "position": "absolute",
                "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
                , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
            });
            if (fAssettype == "image") {
                fimgwd = $(this).find("img.TIC-img").attr("width");
                fimgh = $(this).find("img.TIC-img").attr("height");
            }
            else if (fAssettype == "video") {
                fimgwd = $(this).find("div.textVideo").css("width");
                fimgh = $(this).find("div.textVideo").css("height");
            }
            $(this).find("div.TICvidArea.TICImgSec").css({
                "width": getPerc(fimgwd, ftextAssetw) + "%"

            });
            $(this).find("img.TIC-img").removeAttr("width").removeAttr("height").css({
                "width": "100%"
            });


            $(this).find("div.TICvideoDescription").css({ "width": "100%" });
            $(this).find("div.textVideo").css({ "width": "100%" });

            $(this).removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
        });

        //nav - dtp new changes
        /*
        ths_column.attr("ow", col_org_wd);
        ths_column.attr("oh", col_org_ht);

        col_cal_ht = 100 * col_org_ht / col_org_wd;

        var liwidth;
        if (pageToLoad.PageContent.dtpoptionMargin == undefined || pageToLoad.PageContent.dtpoptionMargin == "") {
            //+10 is left and right padding
            liwidth = getPerc(col_org_wd + 10, ContainerPixelWidth);
        } else {
            //+10 is left and right padding
            liwidth = getPerc(col_org_wd + 10, ContainerPixelWidth - Number(pageToLoad.PageContent.dtpoptionMargin));
        }
        if (pageToLoad.PageContent.isOptCntrAln != undefined && pageToLoad.PageContent.isOptCntrAln == true) {
            //ths_column.closest(".ToptDTP").css({ "width": liwidth + "%" });
            ths_column.closest(".ToptDTP").css({ "width":  "100%" });
            liwidth = 100;
        }
        if (parseInt(liwidth) > 100) {
            ths_column.closest("li").css({
                "width": "93%"
                //,"height": col_org_ht,
            , "position": "relative"
                //, "padding-top": col_cal_ht + "%"
            });
        }
        else {
            ths_column.closest("li").css({
                "width": liwidth + "%"
                //,"height": col_org_ht,
            , "position": "relative"
                //, "padding-top": col_cal_ht + "%"
            });
        }

        ths_column.css({
            "width": "100%"
            //,"height": col_org_ht
            , "position": "relative"
            //, "padding-top": col_cal_ht + "%"
        });*/

        //end

    }); //opttext end here

    contentArea.find(".k-element-video").each(function (index) {
        var wt = $(this).closest(".k-element-box").width();
        var ht = $(this).closest(".k-element-box").height();
        var fsrc = $(this).attr("fsrc");
        var ftype = $(this).attr("ftype");
        fLoadVideoJsPlayer($(this), undefined, { "src": fsrc, "vidtype": ftype, "wt": wt, "ht": ht });
    });

    //Rahul 12-jan-2015 - Audio Component
    contentArea.find(".k-element-audio").each(function (index) {
        var wt = $(this).closest(".k-element-box").width();
        $(this).empty();
        InitializeAudioJs($(this), wt);
    });
    CEPShowHotspots(pageToLoad);
    removeUIClasses();
    removeUIObjects()
    contentArea.find(".k-element-textasset[fImgOrVideo='video']").each(function (index) {
        var wt = 120; // $(this).closest(".k-element-box").width();
        var ht = 100; // $(this).closest(".k-element-box").height();
        var fsrc = $(this).attr("fsrc");
        var ftype = $(this).attr("ftype");
        fLoadtextVideoJsPlayer($(this), undefined, { "src": fsrc, "vidtype": ftype, "wt": wt, "ht": ht });
    });
    //validateInputField(); // Rahul 17-Feb-2015 - Text Entry Component



    //ApplyAutoAdjustment();

    //Set Height of container to maxheight. traverse throught container. In DTP page it is qtext and opttext.
    contentArea.find(".qtext").each(function () {
        //setMaxHeightToContainer($(this));
        $(this).css("height", "auto");
    });
    contentArea.find(".opttext").each(function () {
        //setMaxHeightToContainer($(this));
        $(this).css("height", "auto");
    });

}
function LoadRNPPageContent(pageToLoad, contentArea) {
    htmlContent = GetTemplateString(pageToLoad, $("#Template_RNP").html());
    contentArea.html(htmlContent);
    gRanTempArray = [];
    $("li.RTPDrags").draggable({
        //handle: '.opHandle',    /*DDeva:v1.1.2*/

        drag: function (event, ui) {
            ui.helper.css({ "top": event.pageY + "px", "left": event.pageX + "px" });
        },
        start: function (event, ui) {
            $(ui.helper).css("zIndex", "2");        // DDeva:v1.1.2
            ui.helper.data('rejected', false);
            ui.helper.data('original-position', ui.helper.offset());
        },
        stop: function (event, ui) {
            if (ui.helper.data('rejected') === true) {
                ui.helper.offset(ui.helper.data('original-position'));
            }
        },
        revert: function (event, ui) {
            // on older version of jQuery use "draggable"
            $(this).data("draggable")

            return !event;

        }

    });

    $("li.RTPDrops").droppable({
        tolerance: 'pointer',
        over: function (event, ui) {        /*DDeva:v1.1.2*/
            if ($(this).attr("isDrop") != "true") {
                $(this).css('backgroundColor', '#ccc');
            }
        },
        out: function (event, ui) {        /*DDeva:v1.1.2*/
            $(this).css('backgroundColor', 'inherit');
        },
        drop: function (event, ui) {
            if ($(this).attr("isDrop") == "false") {
                var off = $(this).offset();
                ui.draggable.offset(off);
                $(this).attr("isDrop", "true");
                this.style.zIndex = 2;  /*BUG:visiblity of dragable items*/
                //this.style.visibility = "hidden";
                $(this).css('backgroundColor', 'inherit');   /*DDeva:v1.1.2*/
                ui.draggable.removeData("uiDraggable").unbind(".draggable");
                $(this).find("span.TquestionText").html($(ui.helper.context).find('span.TquestionText').html());
                ui.helper.context.style.visibility = "hidden";

                gRanTempArray[$(this).children('a').attr("id")] = ui.draggable.children('a').attr("id");

                // setting first rank
                if ($(this).children('a').attr("id") == "0") {
                    RankingSelect(ui.draggable.children('a').attr("NextPageId"));
                }
                //Set Ranked Option Array //Here array length is predefined in GetTemplateString()
                gRankedOptionIdArray[parseInt($(this).children('a').attr("id"))] = { "Text": ui.draggable.children('a').find(".TquestionText").html(), "Id": ui.draggable.children('a').attr("OptionId") };
            } else {
                ui.draggable.data('rejected', true);
            }
        }
    });
}
//gp changed on 20 feb 2015 added hotspot as a div
function addImageOriginalHeightAndWidthToBox(_ths) {
    var imageOriginalHeight = _ths.find(".k-element-image").height();
    var imageOriginalWidth = _ths.find(".k-element-image").width()
    _ths.attr("original-height", imageOriginalHeight);
    _ths.attr("original-width", imageOriginalWidth);
}

//Rahul 12-jan-2015 - Audio Component
function InitializeAudioJs(audWrapper, width) {
    var fpath = audWrapper.attr("fsrc");
    var ftype = audWrapper.attr("ftype");
    var fid = audWrapper.attr("id");
    if (fpath == undefined || fpath == null) {
        fpath = "";
    }
    if (ftype == undefined || ftype == null) {
        ftype = "mp3";
    }
    if (fpath != "") {
        audWrapper.closest(".k-element-box").removeClass("k-audio");
        audWrapper.append($("<div class='divAudioPlayer1 ' style='width:" + width + "px" + ";display:inline-block;font-size:12px;'><audio preload='auto'  id='" + fid + "' type='audio/mp3' controls='controls'  src ='" + fpath + "'></audio></div>"));

        //AR 2 April 2015 - Added to overide the controls to the page audio controller
        // audWrapper.find("audio").mediaelementplayer({ defaultAudioWidth: width });
        audWrapper.find("audio").mediaelementplayer({
            defaultAudioWidth: 30, features: ['volume'], success: function (player, node) {
                player.addEventListener('playing', function (e) {
                }, false);
                $(".mejs-horizontal-volume-slider").text('').css({ 'height': 0, 'width': 0 });
            }
        });

        $(".divAudioPlayer1").find(".mejs-button").click(function () {
            assignAudioToPlayer($(this).closest('.k-element-audio').attr('fsrc'));
        })
    }
    else {
        //audWrapper.append($("<div class='divAudioPlayer1' style='width:" + width + "px" + ";display:inline-block;font-size:12px;'><audio preload='auto'  id='" + fid + "' type='audio/mp3' controls='controls'  src ='" + fpath + "'></audio></div>"));
        //audWrapper.find(".divAudioPlayer1 audio").mediaelementplayer({ defaultAudioWidth: width });
    }
}

//AR 2 April 2015 - Added to overide the controls to the page audio controller
//Rahul 10April2015 - function updated to play next audio on finish
function assignAudioToPlayer(audioSrc, nextaudioId) {
    $(".audioplayer").find(".audioplayer-playpause[title='Play']").click();
    $("audio").removeAttr("src");
    var audiocontento = $(".audiocontent");
    audiocontento.remove("audio");
    audiocontento.html("");
    htmlContent = "<div class='divAudioPlayer'> <audio preload='auto'  id='' type='audio/mp3' controls='controls'  src ='" + audioSrc + "'></audio></div>";
    audiocontento.html(htmlContent);
    $("audio").mediaelementplayer({
        defaultAudioWidth: 30, features: ['volume'], success: function (player, node) {
            player.play();
            player.addEventListener('ended', function (e) {
                if (nextaudioId != '' && nextaudioId != undefined) {
                    nextaudioId.find(".mejs-button").click();
                }
            }, false);
            $(".mejs-horizontal-volume-slider").text('').css({ 'height': 0, 'width': 0 });
        }
    });
    audiocontento.show();
    htmlContent = "";

    var playerElement = MediaElementPlayer($(".divAudioPlayer1").find("audio"));
    playerElement.pause();

    var player = MediaElementPlayer($(".divAudioPlayer").find("audio"));
    player.play();
}

//Rahul 12-jan-2015 - Audio Component
function InitializeAudioJsClone(audWrapper, width) {
    var fpath = audWrapper.attr("fsrc");
    var ftype = audWrapper.attr("ftype");
    var fid = audWrapper.attr("id");
    if (fpath == undefined || fpath == null) {
        fpath = "";
    }
    if (ftype == undefined || ftype == null) {
        ftype = "mp3";
    }
    var wt = audWrapper.closest(".k-element-box-clone").width();
    var ht = audWrapper.closest(".k-element-box-clone").height();
    if (fpath != "") {
        audWrapper.closest(".k-element-box-clone").removeClass("k-audio");
        audWrapper.append($("<div class='divAudioPlayer1' style='width:" + width + "px" + ";display:inline-block;font-size:12px;'><audio preload='auto'  id='" + fid + "' type='audio/mp3' controls='controls'  src ='" + fpath + "'></audio></div>"));
        audWrapper.find("audio").mediaelementplayer({ defaultAudioWidth: width });

        $(".divAudioPlayer1").find(".mejs-play").click(function () {
            assignAudioToPlayer($(this).closest('.k-element-audio').attr('fsrc'));
        })
    }
    else {
        //audWrapper.append($("<div class='divAudioPlayer1' style='width:" + width + "px" + ";display:inline-block;font-size:12px;'><audio preload='auto'  id='" + fid + "' type='audio/mp3' controls='controls'  src ='" + fpath + "'></audio></div>"));
        //audWrapper.find(".divAudioPlayer1 audio").mediaelementplayer({ defaultAudioWidth: width });
    }
}

/* <!--Chapter-->*/
$("#ChapterMenu").live("click", function () {
    if (MenuData == undefined || MenuData.length == 0) return;
    var cpPanel = $(".ChapterPanelPlayer");
    cpPanel.css("z-index", "200");
    if (cpPanel.hasClass("closed")) {
        cpPanel.show();
        $(this).children("span").text(".");
        var chapterList = "<ul>";
        $(".ChapterContainer").html('');
        for (clength = 0; clength < MenuData.length; clength++) {
            var currChapterObj = MenuData[clength];
            var tempStr = "";
            if (currChapterObj.PageId == "" || currChapterObj.PageId == undefined) {
                tempStr = "<li id='liCh-" + clength + "' pageId='" + currChapterObj.PageId + "' class='disabled'>" + currChapterObj.MenuTitle + "</li>";
            }
            else {
                tempStr = "<li id='liCh-" + clength + "' pageId='" + currChapterObj.PageId + "'>" + currChapterObj.MenuTitle + "</li>";
            }
            chapterList = chapterList + tempStr;
        }
        chapterList += "</ul>";

        $(".ChapterContainer").html(chapterList);

        cpPanel.removeClass("closed");
        cpPanel.addClass("opened");
        cpPanel.animate({ top: '30px' }, "fast");
    }
    else {
        $(this).children("span").text(".");
        cpPanel.removeClass("opened");
        cpPanel.addClass("closed");
        cpPanel.animate({ top: '0px' }, "fast", function () {
            $(".ChapterContainer").html('');
            cpPanel.hide();
        });
    }
});
/* <!--Chapter-->*/

$(".ChapterContainer li").live('click', function (e) {
    var cpPanel = $(".ChapterPanelPlayer");
    if ($(this).hasClass("disabled")) return;
    e.preventDefault;
    //gPrevPageIdArray.push(gCurrPageObj.PageId);
    SelectPageFromMap($(this).attr('pageId'));
    //$(".ChapterSliderLink a").children("span").text(".");
    cpPanel.removeClass("opened");
    cpPanel.addClass("closed");
    cpPanel.animate({ top: '0px' }, "fast", function () {
        $(".ChapterContainer").html('');
        cpPanel.hide();
    });
});

function ActionOnFileExtension(fileHref, lId, title, srctype) {
    var iFCls = 'iframeCls';
    if (lId == 'ExtLinkDialog')
        iFCls = 'iframeClsMin';

    lId = '#' + lId;
    var fileExtension = fileHref.substr((fileHref.lastIndexOf('.') + 1));
    if (title != undefined) {
        $(lId).append("<p class='rmtitle'>" + title + "</p>")
    }
    if (srctype != undefined && srctype != null && srctype != "") {
        fileExtension = srctype;
    }
    if (iPadClickStatus == "true") {
        window.open(fileHref);
        return;
    }
    switch (fileExtension) {
        case 'zip':
        case 'rar':
            alert('was zip rar');
            break;
            /*case 'doc': //TODO: Need player to show docx content
            case 'docx':
            alert('not supported in this version');
            break;*/
        case 'wav':
        case 'mp3':
        case 'mp4':
            fLoadVideoJsPlayer($(lId), undefined, { "src": fileHref, "vidtype": fileExtension });
            if (iPadClickStatus == "true") {
                $('.HomeIconWrap, .AlgoMapWrap, .InfoIconWrap, .closePlayerWrap, .AlgoVideoLibraryWrap, .MenuIconWrap, .PrevPageWrap, .NextPageWrap, .templateRMPanelPlayer').addClass("indexBasic");
            }

            break;
        case 'youtube':
            fLoadVideoJsPlayer($(lId), undefined, { "src": fileHref, "vidtype": fileExtension });
            if (iPadClickStatus == "true") {
                $('.HomeIconWrap, .AlgoMapWrap, .InfoIconWrap, .closePlayerWrap, .AlgoVideoLibraryWrap, .MenuIconWrap, .PrevPageWrap, .NextPageWrap, .templateRMPanelPlayer').addClass("indexBasic");
            }
            break;
        case 'pdf':
            if (iPadClickStatus == "true") {
                $(".TvidArea video source").attr('src', '');
                $(".NavigationBar").css('display', 'none');
                $(".ContentArea").css('display', 'none');
                $(lId).append("<div id='scrollInst'>Note: Use two fingers to scroll. Use pinch or double-tap to zoom.</div>");
                $(lId).append("<iframe class='" + iFCls + "' frameborder='0'></iframe>");
                $(lId + " iframe").attr("src", fileHref);
                $('.HomeIconWrap, .AlgoMapWrap, .InfoIconWrap, .closePlayerWrap, .AlgoVideoLibraryWrap, .MenuIconWrap, .PrevPageWrap, .NextPageWrap, .templateRMPanelPlayer').addClass("indexBasic");
            }
            else {
                $(lId).append("<iframe class='" + iFCls + "' frameborder='0'></iframe>");
                $(lId + " iframe").attr("src", fileHref);
            }
            break;
        case 'jpg':
        case 'gif':
        case 'bmp':
        case 'png':
            if (iFCls.indexOf("Min") != -1) {
                $(lId).append("<div style='overflow:auto; min-height: 550px;'><img src='" + fileHref + "' /></div>");
            }
            else {
                $(lId).append("<div style='overflow:auto; min-height: 570px;'><img src='" + fileHref + "' /></div>");
            }

            //$(lId + ">div img").load(function () {
            //$(lId + ">div").enscroll({
            //    horizontalScrolling: true,
            //    verticalTrackClass: 'vertical-track2',
            //    verticalHandleClass: 'vertical-handle2',
            //    horizontalTrackClass: 'horizontal-track2',
            //    horizontalHandleClass: 'horizontal-handle2',
            //    cornerClass: 'corner2'
            //});
            //});
            if (iPadClickStatus == "true") {
                $('.HomeIconWrap, .AlgoMapWrap, .InfoIconWrap, .closePlayerWrap, .AlgoVideoLibraryWrap, .MenuIconWrap, .PrevPageWrap, .NextPageWrap, .templateRMPanelPlayer').addClass("indexBasic");
            }
            break;
        default:
            if (fileHref.indexOf("youtube.com") != -1) {
                fLoadVideoJsPlayer($(lId), undefined, { "src": fileHref, "vidtype": "youtube" });
            }
            else {
                if (iPadClickStatus == "true") {
                    $(lId).append("<div id='scrollInst'>Note: Use two fingers to scroll. Use pinch or double-tap to zoom.</div>");
                    $(lId).append("<iframe class='" + iFCls + "' frameborder='0'></iframe>");
                    $(lId + " iframe").attr("src", fileHref);
                    $('.HomeIconWrap, .AlgoMapWrap, .InfoIconWrap, .closePlayerWrap, .AlgoVideoLibraryWrap, .MenuIconWrap, .PrevPageWrap, .NextPageWrap, .templateRMPanelPlayer').addClass("indexBasic");
                }
                else {
                    $(lId).append("<iframe class='" + iFCls + "' frameborder='0'></iframe>");
                    $(lId + " iframe").attr("src", fileHref);
                }
            }

    }
}



function GetTemplateString(pageToLoad, tempString) {
    switch (pageToLoad.PageType) {
        case "RNP":
            if (pageToLoad.PageContent.Heading != undefined) {
                tempString = tempString.replace("###PageTitle###", pageToLoad.PageContent.Heading);
            }
            else {
                tempString = tempString.replace("###PageTitle###", "");
            }

            tempString = tempString.replace("###QuestionText###", pageToLoad.PageContent.QuestionText);

            var optionStr = "<li class='RTPDrags'><a href='#' id='###id###' NextPageId='###NextPageId###' OptionId='###OptionId###'><span class='TquestionImg'><img src='content/images/bullet.png' /></span><span class='TquestionText'>###OptionText###</span></a></li>";     /*DDeva:v1.1.2*/
            var singleOptionStr = "";
            var allOptionStr = ""
            for (var i = 0; i < pageToLoad.PageContent.Options.length; i++) {
                //singleOptionStr = optionStr.replace("###OptionSequence###", gOptLables[i]);
                singleOptionStr = optionStr.replace("###OptionId###", pageToLoad.PageContent.Options[i].OptionId);
                singleOptionStr = singleOptionStr.replace("###OptionText###", pageToLoad.PageContent.Options[i].Text);
                singleOptionStr = singleOptionStr.replace("###NextPageId###", pageToLoad.PageContent.Options[i].TargetPageId);
                singleOptionStr = singleOptionStr.replace("###id###", i);
                gRanTempArray[i] = -1;
                allOptionStr = allOptionStr + singleOptionStr;
            }

            tempString = tempString.replace("<!--###Options###-->", allOptionStr);

            optionStr = "<li class='RTPDrops' isDrop='false'><a href='#' id='###id###' NextPageId='###NextPageId###'><span class='TquestionImg'><img src='content/images/bullet.png' /></span><span class='TquestionText'>###TargetsText###</span></a></li>";
            var singleOptionStr = "";
            var allOptionStr = ""
            gRankedOptionIdArray = new Array(pageToLoad.PageContent.DropZones.length);
            for (var i = 0; i < pageToLoad.PageContent.DropZones.length; i++) {
                singleOptionStr = optionStr.replace("###TargetsText###", pageToLoad.PageContent.DropZones[i].Text);
                singleOptionStr = singleOptionStr.replace("###id###", i);
                gRanTempArray[i] = -1;
                allOptionStr = allOptionStr + singleOptionStr;
            }
            tempString = tempString.replace("<!--###Targets###-->", allOptionStr);
            break;

        case "DTP":
            if (pageToLoad.PageContent.Heading != undefined) {
                tempString = tempString.replace("###PageTitle###", pageToLoad.PageContent.Heading);
            }
            else {
                tempString = tempString.replace("###PageTitle###", "");
            }
            if ($("<div>" + pageToLoad.PageContent.QuestionText + "</div>").find(".k-element-box").length > 0) {
                tempString = tempString.replace("###QuestionText###", pageToLoad.PageContent.QuestionText);
            }
            else {
                tempString = tempString.replace("###QuestionText###", '<span class="TquestionImg1"><img src="###QuestionImagePath###" /></span> <span class="TquestionText">###QuestionText###</span>');
                if (pageToLoad.PageContent.QuestionImagePath != undefined) {
                    tempString = tempString.replace("###QuestionImagePath###", pageToLoad.PageContent.QuestionImagePath);
                }
                else {
                    tempString = tempString.replace("###QuestionImagePath###", "content/images/kno-def-question.png");
                }
                tempString = tempString.replace("###QuestionText###", pageToLoad.PageContent.QuestionText);
            }


            var oListStyle = pageToLoad.PageContent.OptionListStyle;
            var disBullet = oListStyle == "I" ? "<img src='###OptionImageURL###' />" : "###BulletText###";
            //var disBullet = "###BulletText###";

            //var optionStr = "<li><a href='#' class='DTPOption clearfix' NextPageId='###NextPageId###' OptionId='###OptionId###'><span class='TquestionImg'>" + disBullet + "</span><span class='TquestionText'>###OptionText###</span></a></li>";
            var optionStr = "<li><a href='javascript:void(0);' class='DTPOption clearfix' NextPageId='###NextPageId###' OptionId='###OptionId###'><div class='optionIcon' ><span class='TquestionImg'>" + disBullet + "</span></div><div class='optionText'>###OptionText###</div></a></li>";

            var singleOptionStr = "";
            var allOptionStr = ""
            for (var i = 0; i < pageToLoad.PageContent.Options.length; i++) {
                singleOptionStr = "";
                var optNumberLabel = "";
                if (oListStyle == "I") {
                    if (pageToLoad.PageContent.Options[i].IconPath != undefined && pageToLoad.PageContent.Options[i].IconPath != "") {
                        singleOptionStr = optionStr.replace("###OptionImageURL###", pageToLoad.PageContent.Options[i].IconPath);
                    }
                    else {
                        singleOptionStr = optionStr.replace("###OptionImageURL###", 'content/images/bullet.png');
                    }
                }
                else if (oListStyle == "bullet") {
                    optNumberLabel = gOptLables[i];
                    singleOptionStr = optionStr.replace("###OptionImageURL###", "");
                }
                else {
                    switch (oListStyle) {

                        case "lower-alpha":
                            optNumberLabel = gOptLables[i].toLowerCase() + ")";
                            break;
                        case "cap-alpha":
                            optNumberLabel = gOptLables[i] + ")";
                            break;
                        case "roman":
                            optNumberLabel = gRomanLabels[i].toLowerCase() + ")";
                            break;
                        case "number":
                            optNumberLabel = (i + 1) + ")";
                            break;
                        case "decimal":
                            optNumberLabel = (i + 1) + ")";
                            break;

                    }
                    //var bText = oListStyle == 'lower-alpha' ? gOptLables[i].toLowerCase() + ")" : oListStyle == 'decimal' ? (i + 1) + ")" : '';
                }
                if (singleOptionStr == "") {
                    singleOptionStr = optionStr.replace("###BulletText###", optNumberLabel);
                }
                else {
                    singleOptionStr = singleOptionStr.replace("###BulletText###", optNumberLabel);
                }
                singleOptionStr = singleOptionStr.replace("###OptionText###", pageToLoad.PageContent.Options[i].Text);
                singleOptionStr = singleOptionStr.replace("###NextPageId###", pageToLoad.PageContent.Options[i].TargetPageId);
                singleOptionStr = singleOptionStr.replace("###OptionId###", pageToLoad.PageContent.Options[i].OptionId);

                allOptionStr = allOptionStr + singleOptionStr;
            }
            tempString = tempString.replace("<!--###Options###-->", allOptionStr);
            break;
        case "SMP":
            //Aditi:SMP
            if (pageToLoad.PageContent.Heading != undefined) {
                tempString = tempString.replace("###PageTitle###", pageToLoad.PageContent.Heading);
            }
            else {
                tempString = tempString.replace("###PageTitle###", "");
            }
            // Vinod C
            if (pageToLoad.PageContent.Text != undefined && pageToLoad.PageContent.Text != "") {
                tempString = tempString.replace("###SummaryIntro###", pageToLoad.PageContent.Text);
            }
            else {
                // get the data from pageIdText.js synchronously
                pageToLoad.PageContent.Text = getDataFromJsFile(pageToLoad.PageId + "Text.js");
                tempString = tempString.replace("###SummaryIntro###", pageToLoad.PageContent.Text);
            }

            if (pageToLoad.PageContent.SummaryText != undefined) {
                tempString = tempString.replace("###Summary###", pageToLoad.PageContent.SummaryText);
            }

            if (pageToLoad.PageContent.ImageReference != undefined) {
                tempString = tempString.replace("###ImageSrc###", pageToLoad.PageContent.ImageReference);
                tempString = tempString.replace("@@@ImageSrc@@@", pageToLoad.PageContent.ImageReference);
            }
            if (pageToLoad.PageContent.ImageHeading != undefined) {
                tempString = tempString.replace("###ImageTitle###", pageToLoad.PageContent.ImageHeading);
            }
            if (pageToLoad.PageContent.ImageDescription != undefined) {
                tempString = tempString.replace("###ImageDescription###", pageToLoad.PageContent.ImageDescription);
            }

            var qString = "";
            var oString = "";
            var QResult = pageToLoad.PageContent.QResult;

            if (QResult != undefined && QResult != null) {
                for (resultCount = 0; resultCount < QResult.length; resultCount++) {
                    for (index = 0; index < responsesArr.length; index++) {
                        if (QResult[resultCount].knowdId == responsesArr[index].question) {
                            if (pageToLoad.ShowFeedbackOrResults == 'Results') {
                                qString = qString + "<div class='q'>" + "" + QResult[resultCount].QText + "</div>"
                                qString = qString + "<div class='note'>" + QResult[resultCount].Note + "</div>";
                            }
                            oString = "";
                            //24-nov-2014-Anu-SMP
                            for (var ac = 0; ac < responsesArr[index].answer.length; ac++) {
                                if (responsesArr[index].answer[ac] != undefined &&
                                    responsesArr[index].answer[ac].Text != undefined &&
                                    responsesArr[index].answer[ac].Text != "") {
                                    if (pageToLoad.ShowFeedbackOrResults == 'Results') {
                                        //RA-11Sep15- Changed to display only option text in SMP Page
                                        var _tempString = responsesArr[index].answer[ac].Text;
                                        $(_tempString).find(".k-element-box").each(function () {
                                            if ($(this).attr("temptype") == "Text") {
                                                oString = oString + "<div class='o'>" + $(this).find(".k-element-text").html() + "</div>"
                                            }
                                        });
                                        //oString = oString + "<div class='o'>" + responsesArr[index].answer[ac].Text + "</div>"
                                    }
                                    if (pageToLoad.ShowFeedbackOrResults == 'Feedback') {
                                        //oString = oString + "<div class='fnote'>" + QResult[resultCount].FNote + "</div>";
                                        var optFeedbk = FindObjectInArray(QResult[resultCount].FArr, "optid", responsesArr[index].answer[ac].Id);
                                        if (optFeedbk != undefined && optFeedbk.feedbackTitle != 'Enter feedback title here...')
                                            oString = oString + "<div class='ofd'>" + optFeedbk.feedbackTitle + "</div>";

                                        if (optFeedbk != undefined && optFeedbk.feedback != 'Enter feedback here...')
                                            oString = oString + "<div class='ofd'>" + optFeedbk.feedback + "</div>";


                                    }
                                }
                            }
                            qString = qString + oString;
                        }
                    }
                }
            }

            tempString = tempString.replace("###QResults###", qString);
            break;
        case "Excel":
            break;

        default:
            if (pageToLoad.PageContent.Heading != undefined) {
                tempString = tempString.replace("###PageTitle###", pageToLoad.PageContent.Heading);
            }
            else {
                tempString = tempString.replace("###PageTitle###", "");
            }
            //Vinod C
            if (pageToLoad.PageContent.Text != undefined && pageToLoad.PageContent.Text != "") {
                //"$&" is a special character for reference, It inserts the matched substring.
                //so updated the  replace() with split and join. this change is required to update for all possible placeholders.
                //tempString = tempString.replace("###BodyText###", pageToLoad.PageContent.Text);
                tempString = tempString.split("###BodyText###").join(pageToLoad.PageContent.Text)
            }
            else {
                // get the data from pageIdText.js synchronously
                pageToLoad.PageContent.Text = getDataFromJsFile(pageToLoad.PageId + "Text.js");
                //"$&" is a special character for reference, It inserts the matched substring.
                //so updated the  replace() with split and join.
                //tempString = tempString.replace("###BodyText###", pageToLoad.PageContent.Text);
                tempString = tempString.split("###BodyText###").join(pageToLoad.PageContent.Text)
            }

            if (pageToLoad.PageContent.ImageReference != undefined) {
                tempString = tempString.replace("###ImageSrc###", pageToLoad.PageContent.ImageReference);
                tempString = tempString.replace("@@@ImageSrc@@@", pageToLoad.PageContent.ImageReference);
            }
            if (pageToLoad.PageContent.ImageHeading != undefined) {
                tempString = tempString.replace("###ImageTitle###", pageToLoad.PageContent.ImageHeading);
            }
            if (pageToLoad.PageContent.ImageDescription != undefined) {
                tempString = tempString.replace("###ImageDescription###", pageToLoad.PageContent.ImageDescription);
            }
            if (pageToLoad.PageContent.VideoHeading != undefined) {
                tempString = tempString.replace("###VideoTitle###", pageToLoad.PageContent.VideoHeading);
            }
            if (pageToLoad.PageContent.VideoDescription != undefined) {
                tempString = tempString.replace("###VideoDescription###", pageToLoad.PageContent.VideoDescription);
            }

    }
    //Related Media
    $(".RMContainer").html('');
    $(".RMContentArea").hide();
    if (pageToLoad.PageContent.AdditionalResources != undefined && pageToLoad.PageContent.AdditionalResources != null) {
        var rmStr = $("#templateRMArea").html();
        var singleRMStr = "";
        var allRMStr = "";
        var i = 0;
        for (; i < pageToLoad.PageContent.AdditionalResources.length; i++) {

            singleRMStr = rmStr.replace("@@@ResourceThumbnail@@@", pageToLoad.PageContent.AdditionalResources[i].ThumbnailPath);
            singleRMStr = singleRMStr.replace("###ResourceTitle###", pageToLoad.PageContent.AdditionalResources[i].Title);
            singleRMStr = singleRMStr.replace(/###ResourceDescription###/g, pageToLoad.PageContent.AdditionalResources[i].Description);
            singleRMStr = singleRMStr.replace("###ResourceName###", pageToLoad.PageContent.AdditionalResources[i].ResourceName);
            singleRMStr = singleRMStr.replace("###ResourceLink###", pageToLoad.PageContent.AdditionalResources[i].ResourcePath);

            if (pageToLoad.PageContent.AdditionalResources[i].SourceType != undefined) {
                singleRMStr = singleRMStr.replace("###ResourceType###", pageToLoad.PageContent.AdditionalResources[i].SourceType);
            }
            else {
                singleRMStr = singleRMStr.replace("###ResourceType###", "");
            }

            allRMStr = allRMStr + singleRMStr;
        }
        if (i > 0) {
            //$(".RMContentArea").show();
            if (i == 1) {
                //$(".RMSliderLink a span").text("(" + i + ") Additional Resource");
            }
            else {
                //$(".RMSliderLink a span").text("(" + i + ") Additional Resources");
            }
        }
        $(".RMContainer").html(allRMStr);
        //tempString = tempString.replace("###RMPanel###", allRMStr);
    }

    return tempString;
}

function ResizeRMThumb(thisImg) {
    var theWidth = $(thisImg).width();
    var theHeight = $(thisImg).height();
    if ((theWidth / theHeight) > (200 / 200)) {
        var varTop = -(Math.round(200 * theHeight / theWidth) - 200) / 2;
        varTop = 0
        $(thisImg).css({
            left: "0",
            top: varTop
        });
    }
    else {
        var varLeft = -(Math.round(200 * theWidth / theHeight) - 200) / 2;
        varLeft = 0;
        $(thisImg).css({
            left: varLeft,
            top: 0
        });

    }
}

function getImageWidth(url) {
    var icon = new Image();
    icon.src = url;
    return icon.width;
}
$(".TbodyText a, .TquestionText a, .TpageTitle a ,.k-element-text a").live("click", function (e) {
    //Aditi - 8 April 2014 Condition commented to display web pages in iFrame
    if (($(this).attr('href').indexOf("javascript:void(0)") >= 0 || $(this).attr('href') == "#") && $(this).attr('onClick') == undefined) {
        return;
    }
    if ($(this).attr('href').indexOf("fShowReference") == -1) {
        if (($(this).attr('href').indexOf("http://") == -1 && $(this).attr('href').indexOf("https://") == -1) || ($(this).attr('target') == undefined && $(this).attr('onClick') == undefined)) {
            e.preventDefault();
            //$("#dialog").dialog({maxWidth: 960, maxHeight: 440});
            var url = this.href;
            var fileNameIndex = url.lastIndexOf("/") + 1;
            var dotIndex = url.lastIndexOf('.');
            var resDialogTitle = url.substr(fileNameIndex, dotIndex < fileNameIndex ? url.length : dotIndex - fileNameIndex);

            if (iPadClickStatus == "true") {
                window.open(url);
                return;
            }
            $("#ExtLinkDialog").dialog({
                dialogClass: 'LinkDialogStyle',
                draggable: false,
                modal: false,
                open: function (event, ui) {
                    ActionOnFileExtension(url, 'ExtLinkDialog');
                },
                close: function (e) {
                    $(this).empty();
                    $(this).dialog('destroy');
                },
                width: 970,
                height: 560,
                title: resDialogTitle
            });
            //$("#ShowExtLink").append("<iframe style='width: 940px; height: 440px' frameborder='0'></iframe>");
            //$("#ShowExtLink iframe").attr("src", this.href);
            return false;
        }
    }
    else {
        eval($(this).attr('href'))
    }

});

//Aditi - 8 April 2014 for close click
$(".RMSliderLink a").live("click", function () {
    var rel = gCurrPageObj.PageType;
    rmpanelOpen = "true";
    //Rahul 16April2015 - changed to display full page overlay
    var windowHeight = $("#contentContainer").height();
    $(".templateRMPanelPlayerOverlay").css({ "display": "block", "height": (windowHeight + 139) + "px" });
    $(".ContentArea").find("div.video-js").each(function () {
        var videoID = $(this).attr("id");
        if (videoID != undefined && videoID != null && videoID != "") {
            var myPlayer = videojs(videoID);
            myPlayer.pause();
        }
    });

    if ($(".audiocontent").html() != "") {
        var player = MediaElementPlayer($(".audiocontent").find("audio"));
        player.pause();
    }

    $(".ContentArea").find(".k-element-audio").each(function () {
        var audSrc = $(this).attr("fsrc");
        if (audSrc != undefined && audSrc != null && audSrc != "") {
            var player = MediaElementPlayer($(this).find("audio"));
            player.pause();
        }
    });

    $(".RMContentArea").css({ "display": "block" });
    $(".templateRMPanelPlayer").css({ "display": "block" });
    //$(".RMSeperator").hide();
    var rmPanel = $(".templateRMPanelPlayer");
    if (AdditionalResOpenType == "SideScreen") {
        //$(this).css('left', '0');
        rmPanel.css('width', '100%');
        $(".RMSeperator").hide();
        $(".RMContainer").css("float", "right");
        $(".RMDisplay").css({ "display": "none" });
        //RMDisplay
    }
    else {
        //$(this).css('top', '82px');
        //$(this).css('left', '94%');
        rmPanel.css('right', '0');
    }

    //$(".RMSliderLink").customSlider({ toggle: true });

});

$("#closeOverlay").live("click", function () {
    $(".templateRMPanelPlayerOverlay").css({ "display": "none" });
    //RA-11Sep15- close audio and video when AR panel closed
    $(".RMContentArea .RMDisplay").find("div.video-js").each(function () {
        var videoID = $(this).attr("id");
        if (videoID != undefined && videoID != null && videoID != "") {
            var myPlayer = videojs(videoID);
            myPlayer.pause();
        }
    });
    $(".RMContentArea").css({ "display": "none" });
    rmpanelOpen = "false";
});

function IsPreview() {
    return getParameterByName("isPreview") == null ? false : getParameterByName("isPreview") == "true" ? true : false;
}

$("#VideoLibIcon").live("click", function () {
    var rel = gCurrPageObj.PageType;
    $(".ContentArea").find("div.video-js").each(function () {
        var videoID = $(this).attr("id");
        if (videoID != undefined && videoID != null && videoID != "") {
            var myPlayer = videojs(videoID);
            myPlayer.pause();
        }
    });

    if ($(".audiocontent").html() != "") {
        var player = MediaElementPlayer($(".audiocontent").find("audio"));
        player.pause();
    }

    $(".ContentArea").find(".k-element-audio").each(function () {
        var audSrc = $(this).attr("fsrc");
        if (audSrc != undefined && audSrc != null && audSrc != "") {
            var player = MediaElementPlayer($(this).find("audio"));
            player.pause();
        }
    });

    if ($(this).hasClass("disabled")) return;
    if (IsPreview() && (gVideoLibraryEntries == undefined || gVideoLibraryEntries.length == 0)) {//gp added to fetch video data
        FetchVideoLibraryData();
    }
    SetLibraryItems(gVideoLibraryEntries);
    $("#VideoLibrary").fadeIn();
});

$("#btnVidLibSearch").live("click", function () {
    var serTerm = $("#txtSearchTerm").val();
    SetLibraryItems(SearchOnVidLibrary("FileName", serTerm));
});

$("#btnVidLibReset").live("click", function () {
    $("#txtSearchTerm").val("");
    SetLibraryItems(gVideoLibraryEntries);
});

$("#VideoLibInfo .close").live("click", function () {
    $("#VideoLibrary").fadeOut();

});

$("#VideoLibPlayer .close").live("click", function () {
    $("#VideoLibInfo").fadeIn();
    $("#VideoLibPlayer").fadeOut();
    $("#VideoLibPlayer .videoPlayer").html("");
});

function SearchOnVidLibrary(key, value) {
    var resultArray = [];
    if (value != "" & value != undefined) {
        var regx = new RegExp(value, "i");
        if (key === "FileName") {
            $.each(gVideoLibraryEntries, function (i, elem) {
                if (regx.test(elem.FileName) || regx.test(elem.DispName) || regx.test(elem.FileDuration)) {
                    resultArray.push(elem);
                }
            });
        }
        else if (key === "FileDuration") {
            $.each(gVideoLibraryEntries, function (i, elem) {
                if (regx.test(elem.FileDuration)) {
                    resultArray.push(elem);
                }
            });
        }
    }
    else {
        resultArray = gVideoLibraryEntries;
    }

    return resultArray;
}

function SetLibraryItems(libEntries) {
    var windowHeight = $("#contentContainer").height();
    $("#VideoLibrary").css({"height": (windowHeight + 139) + "px" });
    if (libEntries != undefined && libEntries.length > 0) {
        $("#VidLibContainer .boxgridRows").empty();
        var vidHtml = $("#templateVidLibThumb").html();
        var indx = 0;
        $.each(libEntries, function (i, elem) {
            indx++;
            var vidTEle = $(vidHtml);
            vidTEle.find("img.vidThumb").attr("fPath", elem.FilePath);
            vidTEle.find("img.vidThumb").attr("src", elem.ThumbPath);

            vidTEle.find("div.vidTitle").attr("fPath", elem.FilePath);
            vidTEle.find("div.vidTitle").attr("title", elem.DispName);
            vidTEle.find("div.vidTitle").html(elem.DispName);

            if (elem.FileDuration != "") {
                vidTEle.find("div.vidLength span.length").html("(" + elem.FileDuration + ")");
            }
            //Set Video Info Properties.
            if (elem.Details != undefined && elem.Details.length > 0) {
                var infoStr = "<div style='max-width:300px'><p style='padding:0px 0px 5px 0px'>Knowds where this video has been used:</p>";
                $.each(elem.Details, function (j, info) {
                    var nInfo;
                    //RA-01Oct15 - updated to replace string.
                    if (info.KnowdTitle != null && info.KnowdTitle != "") {
                        var jdata = info.KnowdTitle.toString();
                        jdata = jdata.replace("<Assessment Title: Enter the title here...>", "Assessment Title: Enter the title here...");
                        jdata = jdata.replace("<Enter page title here...>", "Enter page title here...");
                        info.KnowdTitle = jdata;
                    }
                    //RM, Image, Video, IA-Title, IA-Desc, IA-Body, Ques, Opt, IA-Opt
                    if (info.KnowdArea == "RM") {
                        if (IsPreview()) {//gp 27-aug-2015 preview changes
                            var ifrm = parent.GetActiveTabiFrame();
                            var rmDisplayName = ifrm.contentWindow.RMDisplayName;
                            nInfo = "<p style='padding:5px 0px 5px 15px'>-&nbsp;&nbsp;(" + info.KnowdLabel + rmDisplayName + ") " + $("<div>" +( (info.KnowdTitle != null && info.KnowdTitle != undefined) ? info.KnowdTitle : "") + "</div>").text() + "</p>";
                        }
                        else {
                            nInfo = "<p style='padding:5px 0px 5px 15px'>-&nbsp;&nbsp;(" + info.KnowdLabel + " ###RMDisplayName###) " + $("<div>" +( (info.KnowdTitle != null && info.KnowdTitle != undefined) ? info.KnowdTitle : "") + "</div>").text() + "</p>";
                        }
                    }
                    else if (info.KnowdArea == "IA-Title" || info.KnowdArea == "IA-Desc" || info.KnowdArea == "IA-Body") {
                        nInfo = "<p style='padding:5px 0px 5px 15px'>-&nbsp;&nbsp;(" + info.KnowdLabel + " Inline link) " + $("<div>" +( (info.KnowdTitle != null && info.KnowdTitle != undefined) ? info.KnowdTitle : "") + "</div>").text() + "</p>";
                    }
                    else {
                        nInfo = "<p style='padding:5px 0px 5px 15px'>-&nbsp;&nbsp;(" + info.KnowdLabel + ") " + $("<div>" +( (info.KnowdTitle != null && info.KnowdTitle != undefined) ? info.KnowdTitle : "") + "</div>").text() + "</p>";
                    }
                    infoStr += nInfo;
                });
                infoStr += "</div>";
            }
            vidTEle.find("div.vidLength span.vidInfoIcon").attr("title", infoStr);

            $("#VidLibContainer .boxgridRows").append(vidTEle);
        });

        $("#VidLibContainer").CUSTOM_THUMB({ /*constW: 220*/isCustomTooltip: false, coverBottom: -20 });

        $(".vidInfoIcon").qtip({
            content: {
                text: $(this).attr("title")
            },
            position: {
                my: 'topMiddle',
                at: 'topMiddle',
                viewport: $(window),
                adjust: { x: 0, y: 25 }
            },
            events: {

                show: function (event, api) {
                    $(".videoW").not($(api.elements.target).closest("div.videoW")).fadeTo("fast", 1);
                },
                hide: function (event, api) {
                    $(".videoW").fadeTo("fast", 1);
                }
            },
            style: 'qtip-tipsy'
        });

        $(".vidTitle").qtip({
            content: {
                text: $(this).attr("title")
            },
            position: {
                at: 'top left',
                my: 'bottom left',
                viewport: $(window)
            },
            events: {
                show: function (event, api) {
                    $(".videoW").not($(api.elements.target).closest("div.videoW")).fadeTo("fast", 1);
                },
                hide: function (event, api) {
                    $(".videoW").fadeTo("fast", 1);
                }
            },
            style: 'qtip-tipsy'
        });
    }
    else {
        $("#VidLibContainer .boxgridRows").empty();
    }
}

$(".videoW .vidThumb, .videoW .vidTitle").live("click", function () {
    var vidRef = $(this).attr("fPath");
    SetAndShowVidLibraryPlayer(vidRef);
});

function SetAndShowVidLibraryPlayer(vidReference) {
    $("#VideoLibPlayer .videoPlayer").empty();
    $("#VideoLibInfo").fadeOut("fast");
    var vtype = "mp4";
    if (vidReference.indexOf("youtube.com") != -1) {
        vtype = "youtube";
    }
    $("#VideoLibPlayer").fadeIn("fast", function () {
        fLoadVideoJsPlayer($("#VideoLibPlayer .videoPlayer"), undefined, { "src": vidReference, "vidtype": vtype });
    });
}
//gp added to feth video library data
function FetchVideoLibraryData() {
    var liblist = parent.GetAssetListForPublish(gCaseId, gPages);
    var isVidExist = false;
    if (liblist != undefined && liblist.Resources != undefined && liblist.Resources.length > 0) {
        for (var i = 0 ; i < liblist.Resources.length; i++)
        {
            if (liblist.Resources[i].Path != undefined) { //RA-25Sep15 - checked undefined for liblist array.
                if (liblist.Resources[i].Path.indexOf(".mp4") >= 0 || liblist.Resources[i].Path.indexOf("youtube") >= 0) {
                    isVidExist = true;
                }
            }
        }
        if (isVidExist) {
            var liblistJson = JSON.stringify(liblist);
            $.ajax({
                async: false,
                type: 'POST',
                url: "/CBACase/GetVideoLibraryData",
                data: liblistJson,
                contentType: 'application/json',
                success: function (data) {
                    gVideoLibraryEntries = data;
                },
                error: function (xhr, data, message) {
                },
                dataType: "json"
            });
        }
    }
}

/*dated 26-mar-2014 display hotspots on image if exist*/
//gp changed on 20 feb 2015 added hotspot as a div
function ShowHotspots(pageObj) {
    if (pageObj.PageContent.ImageReference == undefined || pageObj.PageContent.ImageReference == "blank" || pageObj.PageContent.ImageReference == "")
        return;
    var htmlForDivHotspotImage = "";
    if (pageObj.Hotspots != undefined && pageObj.Hotspots.length != 0) {

        for (var i = 0; i <= pageObj.Hotspots.length - 1; i++) {
            var hsId = pageObj.Hotspots[i].HotspotId;

            var urlFields = "";

            if (pageObj.Hotspots[i].URLType == "blank" || pageObj.Hotspots[i].URLType == "")
                urlFields = "data-URLType = 'none'";
            else if (pageObj.Hotspots[i].URLType == "URL")

                urlFields = "data-URLType = 'URL'  data-href='" + pageObj.Hotspots[i].URL + "'";

            else if (pageObj.Hotspots[i].URLType == "Reference Text") {
                urlFields = "data-URLType = 'Reference Text'  data-refId='" + pageObj.Hotspots[i].RefId + "'  data-hotspotId = '" + pageObj.Hotspots[i].HotspotId + "'";

            }
            else {
                urlFields = "data-URLType = 'Knowd'  data-knowdId = '" + pageObj.Hotspots[i].URL + "'";
            }

            //Rahul 27March2015 - Hotspot div positioning code taken from author.knowdl.com
            var imgobj = $("#divImage");
            var orw = imgobj.attr("original-width")
            var orh = imgobj.attr("original-height")
            //naveen/deva 26-may
            var pwdth, phight, pleft, ptop;
            pwdth = pageObj.Hotspots[i].width;
            phight = pageObj.Hotspots[i].height;
            pleft = pageObj.Hotspots[i].left;
            ptop = pageObj.Hotspots[i].top;
            if ((pageObj.Hotspots[i].left + "").indexOf("px") != -1) {
                pleft = getPerc(Number(pageObj.Hotspots[i].left.replace("px", "").replace("%", "")), orw) + "%";
                ptop = getPerc(Number(pageObj.Hotspots[i].top.replace("px", "").replace("%", "")), orh) + "%";
            }
            if (msieversion() == 9 || msieversion() == 8) {
                if (pageObj.Hotspots[i].leftPX != undefined) {
                    pwdth = pageObj.Hotspots[i].widthPX;
                    phight = pageObj.Hotspots[i].heightPX;
                    pleft = pageObj.Hotspots[i].leftPX;
                    ptop = pageObj.Hotspots[i].topPX;
                }
            }
            htmlForDivHotspotImage += "<div id='divHotspot_" + hsId + "' class='divHotSpot' style=' width:" + pwdth + ";height:" + phight +
                ";left:" + pleft + ";top:" + ptop + ";' " + urlFields + "/>";
        }
        $("#TIP-img").parent().append(htmlForDivHotspotImage);
        // adjust hot spot height
        //$(".divHotSpot").each(function () {
        //    $(this).css({
        //        "height": getPerc($(this).height(), $(this).parent().attr("original-height")) + "%",
        //        "width": getPerc($(this).width(), $(this).parent().attr("original-width")) + "%",
        //        "top": getPerc($(this).css("top"), $(this).parent().attr("original-height")) + "%",
        //        "left": getPerc($(this).css("left"), $(this).parent().attr("original-width")) + "%"
        //    });
        //});
    }
}
//gp changed on 20 feb 2015 added
$(".divHotSpot").live("click", function () {
    if ($(this).closest('.k-element-box').hasClass("disabled")) return;
    //Anu 29-apr-2015 score for scorecard parameter
    var _ths = $(this);
    var urlType = _ths.attr("data-URLType");
    var isclicked = _ths.attr("isclicked");
    if (gActionScoreTracking && isclicked == undefined) {
        _ths.attr("isclicked", "true");
        var imgId = _ths.attr("imageid");
        var hsId = _ths.attr("hsid");
        var imgHs = FindObjectInArray(gCurrPageObj.ImageHotspots, "ImageId", imgId);
        if (imgHs != undefined) {
            for (var i = 0; i < imgHs.Hotspots.length; i++) {
                if (imgHs.Hotspots[i].HotspotId == hsId) {
                    SetCumulativeAndPageScore(imgHs.Hotspots[i], "Hotspot");
                    break;
                }
            }
        }
        showSimScore(true);
    }

    switch (urlType) {
        case "Reference Text":
            var refId = _ths.attr("data-refId");
            var hpid = _ths.attr("data-hotspotId");
            fshowRefQtipPopup(refId, hpid);
            break;
        case "URL":
            var href = _ths.attr("data-href");
            window.open(href);
            break;
        case "Knowd":
            var knowdId = _ths.attr("data-knowdId");
            SelectPageFromMap(knowdId);
        default:
            break;
    }
});
//gp changed on 20 feb 2015 added hotspot as a div
/*DDeva:�v3.1.2 - responsive issue fixes*/
function CEPShowHotspots(pageObj) {
    if ((pageObj.PageContent.ImgC == undefined || pageObj.PageContent.ImgC == "blank" || pageObj.PageContent.ImgC == "")
        && (pageObj.PageContent.TxtAstC == undefined || pageObj.PageContent.TxtAstC == 'blank' || pageObj.PageContent.TxtAstC == "")) {
        return;
    }
    var htmlForDivHotspotImage = "";
    var containerhtmlForDivHotspotImage = "";
    // DDeva:21/04/16
    // Older version have div-edit-properties1 div though hotspots absent, need to remove
    // Preview/ package page height issue
    $(".ContentArea").find(".k-element-box").each(function () {
        var _kElement = $(this);
        var hotspDiv = _kElement.find(".div-edit-properties1");
        if(hotspDiv != undefined == hotspDiv.html() == '') {
            hotspDiv.remove();
        }
    });
    //gp 22 july 2015 added condition for text asset
    var isTextAsset = false,_compType;
    if (pageObj.ImageHotspots != undefined && pageObj.ImageHotspots.length != 0) {
        for (var j = 0; j <= pageObj.ImageHotspots.length - 1; j++) {
            var currImg = $("#" + pageObj.ImageHotspots[j].ImageId);
            if (pageObj.ImageHotspots[j].Hotspots != undefined && pageObj.ImageHotspots[j].Hotspots.length != 0) {
                htmlForDivHotspotImage = "";
                containerhtmlForDivHotspotImage = "";
                for (var i = 0; i <= pageObj.ImageHotspots[j].Hotspots.length - 1; i++) {
                    if (pageObj.ImageHotspots[j].ImageId.indexOf("k-element-textasset") >= 0) {
                        isTextAsset = true;
                        _compType = "textasset";
                    }
                    else {
                        isTextAsset = false;
                        _compType = "image";
                    }
                    var hsId = pageObj.ImageHotspots[j].Hotspots[i].HotspotId;
                    var imgId = pageObj.ImageHotspots[j].ImageId.substring(pageObj.ImageHotspots[j].ImageId.indexOf(_compType));
                    var urlFields = "";
                    currImg.closest(".k-element-box").find(".div-edit-properties1").remove();
                    if (pageObj.ImageHotspots[j].Hotspots[i].URLType == "blank" || pageObj.ImageHotspots[j].Hotspots[i].URLType == "") {
                        urlFields = "data-URLType = 'none'";
                    }
                    else if (pageObj.ImageHotspots[j].Hotspots[i].URLType == "URL") {
                        urlFields = "data-URLType = 'URL'  data-href='" + pageObj.ImageHotspots[j].Hotspots[i].URL + "'";
                    }
                    else if (pageObj.ImageHotspots[j].Hotspots[i].URLType == "Reference Text") {

                        // url = "href=javascript:fshowRefQtipPopup('" + pageObj.ImageHotspots[j].Hotspots[i].RefId + "','" + pageObj.ImageHotspots[j].Hotspots[i].HotspotId + "','" + ('mapHotspots' + j) + "')";
                        urlFields = "data-URLType = 'Reference Text'  data-refId='" + pageObj.ImageHotspots[j].Hotspots[i].RefId + "'  data-hotspotId = '" + pageObj.ImageHotspots[j].Hotspots[i].HotspotId + "'";
                    }
                    else if (pageObj.ImageHotspots[j].Hotspots[i].URLType == "Tooltip") {//gp 28april 2015 added for assessment
                        urlFields = "data-URLType = 'Tooltip'  data-refId='" + pageObj.ImageHotspots[j].Hotspots[i].RefId + "'  data-hotspotId = '" + pageObj.ImageHotspots[j].Hotspots[i].HotspotId + "'";
                    }
                    else if(pageObj.ImageHotspots[j].Hotspots[i].URLType == "Script")//gp 24 sept 2015 load hotspot script
                    {
                        urlFields = "data-URLType = 'Script' data-hotspotId = '" + pageObj.ImageHotspots[j].Hotspots[i].HotspotId + "'";
                        scriptext = "$('.divHotspots" + j + "_" + imgId + "_" + hsId + "').live('click',function(){" +
                            pageObj.ImageHotspots[j].Hotspots[i].URL + "})";
                        var scriptArray = [];
                        scriptArray.push(scriptext)
                        loadScripts(scriptArray);
                    }
                    else {
                        urlFields = "data-URLType = 'Knowd'  data-knowdId = '" + pageObj.ImageHotspots[j].Hotspots[i].URL + "'";
                    }
                    var scoreFields = "";
                    scoreFields = GetScoreFieldsForHotspot(pageObj.ImageHotspots[j].Hotspots[i]);
                    if (scoreFields == undefined || scoreFields == null) {
                        scoreFields = "";
                    }
                    var imgobj = currImg.closest(".k-element-box");
                    var orw = imgobj.attr("original-width")
                    var orh = imgobj.attr("original-height")

                    //naveen 26-may
                    var pwdth, phight, pleft, ptop;
                    pwdth = pageObj.ImageHotspots[j].Hotspots[i].width;
                    phight = pageObj.ImageHotspots[j].Hotspots[i].height;
                    pleft = pageObj.ImageHotspots[j].Hotspots[i].left;
                    ptop = pageObj.ImageHotspots[j].Hotspots[i].top;
                    if ((pageObj.ImageHotspots[j].Hotspots[i].left + "").indexOf("px") != -1) {
                        pleft = getPerc(Number(pageObj.ImageHotspots[j].Hotspots[i].left.replace("px", "").replace("%", "")), orw) + "%";
                        ptop = getPerc(Number(pageObj.ImageHotspots[j].Hotspots[i].top.replace("px", "").replace("%", "")), orh) + "%";
                    }
                    else if(imgobj.attr("showcontainer") == "True"){
                                ptop = parseInt(currImg.css('height'), 10) * parseFloat(ptop,10)/100 + 'px';
                                pleft = parseInt(currImg.css('width'), 10) * parseFloat(pleft,10)/100 + 'px';
                              }


                    if (msieversion() == 9 || msieversion() == 8) {
                        if (pageObj.ImageHotspots[j].Hotspots[i].leftPX != undefined) {
                            pwdth = pageObj.ImageHotspots[j].Hotspots[i].widthPX;
                            phight = pageObj.ImageHotspots[j].Hotspots[i].heightPX;
                            pleft = pageObj.ImageHotspots[j].Hotspots[i].leftPX;
                            ptop = pageObj.ImageHotspots[j].Hotspots[i].topPX;
                        }
                    }

                    htmlForDivHotspotImage += "<div hsId='" + hsId + "' imageid='" + pageObj.ImageHotspots[j].ImageId + "' id='divHotspots" + j + "_" + hsId + "' class='divHotspots" + j + "_" + imgId + "_" + hsId + " divHotSpot'" +
                        " style=' width:" + pwdth + ";height:" + phight + ";left:" + pleft + ";top:" + ptop + ";'" + urlFields + scoreFields + "/>";
                }
                //Rahul 13April-2015 - commnented for Show Container Change
                if (!isTextAsset) {
                    orw = currImg.width();
                    orh = currImg.height();
                    if (currImg.closest(".k-element-box").attr("showContainer") == "True") {
                        containerhtmlForDivHotspotImage += "<div class='div-edit-properties1 clearfix' style='position: relative; width:" + $("#" + pageObj.ImageHotspots[j].ImageId).width() + "px" + ";height:" + $("#" + pageObj.ImageHotspots[j].ImageId).height() + "px" +
                    ";'>" + htmlForDivHotspotImage + "</div>";
                        currImg.parent().append(containerhtmlForDivHotspotImage);
                    }
                        //gp 17 april 2015 modified condtion
                    else {
                        containerhtmlForDivHotspotImage += "<div class='div-edit-properties1 clearfix'></div>";
                        currImg.parent().find(".k-element-image").wrap(containerhtmlForDivHotspotImage);
                        currImg.parent().append(htmlForDivHotspotImage);
                    }
                }
                else // for text asset
                {	//RA-02Nov15 - updated to resolve hotspot responsive issue
                    if (getCkeText(currImg.closest(".k-element-box").find(".TICvideoDescription").text()) == "" || getCkeText(currImg.closest(".k-element-box").find(".TICvideoDescription").text()) == null) {
                        containerhtmlForDivHotspotImage += "<div class='div-edit-properties1 clearfix' style='position:absolute;top:0px;left:0px'>" + htmlForDivHotspotImage + "</div>";
                        currImg.find(".TIC-img").parent().append(containerhtmlForDivHotspotImage);
                    } else {
                        var totalHeight = $(".TICvidArea.TICImgSec").height();
                        var exactHeight = (currImg.find(".TIC-img").height() / totalHeight) * 100;
                        containerhtmlForDivHotspotImage += "<div class='div-edit-properties1 clearfix' style='position: absolute;top:0;left:0;height:" + exactHeight + "%" +
                   ";'>" + htmlForDivHotspotImage + "</div>";
                    currImg.find(".TIC-img").parent().append(containerhtmlForDivHotspotImage);
                    }
                }
            }
        }
    }
    //gp 28april 2015 added for assessment -set tooltip
    $(".ContentArea").find(".divHotSpot").each(function () {
        var urlType = $(this).attr("data-URLType");
        if (urlType != undefined && urlType == 'Tooltip') {
            var refId = $(this).attr("data-refId");
            var hpid = $(this).attr("data-hotspotId");
            var refT = GetRefTooltipText(refId, hpid);
                if (currImg.hasClass("latestQTIP")) {
                    $(this).qtip(
                    {
                        content: '<div>' + refT + '</div>', // Give it some content
                        position: { my: 'leftMiddle', at: 'rightMiddle', viewport: $(window), adjust: { x: 0, y: 25 } },
                        hide: {
                            fixed: true // Make it fixed so it can be hovered over
                        },
                        style: 'qtip-tipsy'
                    });
                }
                else {
            $(this).qtip(
            {
                content: '<div>' + refT + '</div>', // Give it some content
                position: {
                    my: 'leftBottom',
                    at: 'rightTop',
                    viewport: $(window),
                    adjust: { x: -40, y: 15 }// Set its position
                },
                hide: {
                    fixed: true // Make it fixed so it can be hovered over
                },
                style: 'qtip-tipped'
            });
        }
            }

    });


}
function GetScoreFieldsForHotspot(hsObj) {
    var scoreFields = "";
    if (gScoringToolFormat != undefined && gScoringToolFormat != null) {
        if (gScoringToolFormat.ActionTracking != undefined && gScoringToolFormat.ActionTracking == true && gScoringToolFormat.ScoringToolDetails != undefined && gScoringToolFormat.ScoringToolDetails != null && gScoringToolFormat.ScoringToolDetails.length > 0) {
            for (var i = 0; i < gScoringToolFormat.ScoringToolDetails.length; i++) {
                var prscore = gScoringToolFormat.ScoringToolDetails[i];
                var scoreVal = "";
                var scoreName = prscore.Name;
                if (hsObj[scoreName] != undefined && hsObj[scoreName] != null) {
                    scoreFields = " data-scorevalue=" + hsObj[scoreName] + " ";
                }
            }
        }
    }
    return scoreFields;
}

function additionalResoursesClosedFromXcode() {
    $(".RMDisplay2").hide();
    $(".RMDisplay3").hide();
    //Naveen - need to confirm
    //$(".RMDisplay2 video").remove();
    //$(".RMDisplay2 iframe").remove();
    //$(".RMDisplay2 object").remove();
    $(".RMDisplay2").empty();
    //Naveen - need to confirm
    //$(".RMDisplay3 video").remove();
    //$(".RMDisplay3 iframe").remove();
    //$(".RMDisplay3 object").remove();
    $(".RMDisplay3").empty();
    $(".RMArea").removeClass("selected");
    $('.HomeIconWrap, .AlgoMapWrap, .InfoIconWrap, .closePlayerWrap, .AlgoVideoLibraryWrap, .MenuIconWrap, .PrevPageWrap, .NextPageWrap, .templateRMPanelPlayer').removeClass("indexBasic");
    $(".NavigationBar").css('display', 'block');
    $(".ContentArea").css('display', 'block');

}
/*2-apr-2014 additioanl res side srcn*/
$("#linkCloseRes").live("click", function (e) {
    $(".RMDisplay2").hide();
    $(".RMDisplay3").hide();

    $(".RMDisplay2").empty();

    $(".RMDisplay3").empty();
    $(".RMArea").removeClass("selected");
    $('.HomeIconWrap, .AlgoMapWrap, .InfoIconWrap, .closePlayerWrap, .AlgoVideoLibraryWrap, .MenuIconWrap, .PrevPageWrap, .NextPageWrap, .templateRMPanelPlayer').removeClass("indexBasic");
    $(".NavigationBar").css('display', 'block');
    $(".ContentArea").css('display', 'block');
});
//END//END
//Anu 28-july-2015 Ref pop up issue sol
function fshowRefQtipPopup(refid, id, mapHSId, navtoNext) {
    var refText, popupWidth = 100, devicewidth = BreakPoint_HIGH;
    $(".ContentArea").find("div.video-js").each(function () {
        var videoID = $(this).attr("id");
        if (videoID != undefined && videoID != null && videoID != "") {
            var myPlayer = videojs(videoID);
            myPlayer.pause();
        }
    });

    $(".ContentArea").find(".k-element-audio").each(function () {
        var audSrc = $(this).attr("fsrc");
        if (audSrc != undefined && audSrc != null && audSrc != "") {
            var player = MediaElementPlayer($(this).find("audio"));
            player.pause();
        }
    });
    if (gCurrPageObj.References == "[]") {
        // get the data from pageIdReferences.js synchronously
        gCurrPageObj.References = getDataFromJsFile(gCurrPageObj.PageId + "References.js");
    }
    if (gCurrPageObj.References != undefined && gCurrPageObj.References.length != 0) {
        for (var i = 0; i <= gCurrPageObj.References.length - 1; i++) {
            if (refid == gCurrPageObj.References[i].RefId) {
                var _obj = gCurrPageObj.References[i];
                //sync data with template if attahced
                if (_obj.TemplateId != undefined && _obj.TemplateId != "") {
                    //sync with template after html set.
                    var templateobj = GetTemplateData(_obj.TemplateId);
                    if (templateobj != undefined) {
                       if (IsPreview && templateobj.TemplateData != undefined)///gp 31-12-15 changed for published cases
                       {
                       var jsonTempData = JSON.parse(templateobj.TemplateData);
                       SyncDataWithTemplate(jsonTempData, _obj, true);
                       if (jsonTempData.PageContent.PopupProperties != undefined) {
                           SetRefPopupProps(_obj, jsonTempData.PageContent.PopupProperties);
                        }
                       }
                       else
                       {
                           SyncDataWithTemplate(templateobj, _obj, true);
                           if (templateobj.PageContent.PopupProperties != undefined) {
                               SetRefPopupProps(_obj, templateobj.PageContent.PopupProperties);
                           }
                       }
                    }
                }
                if (_obj.ProgressToNextPage != undefined && _obj.ProgressToNextPage == true) {
                    navtoNext = true;
                }
                if (navtoNext != undefined && (navtoNext == "true" || navtoNext == true)) {
                    $("#fancyreferencePopup").attr("navtoNext", true);
                } else {
                    $("#fancyreferencePopup").attr("navtoNext", "");
                }

                refText = _obj.PopupText;
                var obj = $(refText);
                var popW = $(obj).width() == 0 ? $(obj).find('.band').width() : $(obj).width();
                devicewidth = popW > devicewidth ? devicewidth : popW;
                //nav-device 03june2016
                //MakeontentResponsive(devicewidth, obj);
                //end
                var refContent = $("#fancyreferencePopup .refContent");
                //nav-temporary fix for popup width, need to check this fix in details.
                $("#fancyreferencePopup .refContent").css("width",devicewidth + "px");
                //
                //Anu 21-apr-2015 ref pop up box padding
                var boxPad = _obj.BoxPadding;
                if (boxPad != undefined && boxPad != '') {
                    refContent.css("padding", boxPad + "px");
                }
                refContent.html(obj[0].outerHTML);
                //nav-device - 01june16
                k_DeviceManager.RenderContentForMode("#fancyreferencePopup .refContent");
                //k_DeviceManager.TempInitiateElements("#fancyreferencePopup .refContent");
                //end
                $(".k-element-box[defaultVisibility='Hidden']").hide();
                //Anu 19-may-2016 Rollover image,text and sel state func in Popup
                refContent.find(".k-element-box[temptype='Button']").each(function () {
                    var eleBtn = $(this).find(".k-element-button");
                    if (eleBtn.attr("rollovertext") != undefined) {
                        $(this).qtip({
                            content: {
                                text: $("<span style='font-family:arial narrow;color:#FFFFFF;font-size:15px;'>" + $(eleBtn.attr("rollovertext")).text() + "</span>")
                            },
                            position: {
                                at: 'bottom center',
                                my: 'top center',
                                viewport: $(window)
                            },
                            style: {
                                classes: 'qtip-tipsy',
                                width: 250,
                                maxWidth: 300
                            }
                        });
                    }
                    var defaultBgColor = $(this).css("background-color");
                    var hoverColor = $(this).find('.k-element-button').attr("selstatecolor");
                    $(this).attr("origBGColor11", defaultBgColor);
                    if (hoverColor != undefined) {
                        var bg = "0 0 24px -5px " + hoverColor;
                    } else {
                        var bg = "0 0 24px -5px " + defaultBgColor;
                    }
                    $(this).css({ "opacity": "" });
                    $(this).hover(
                         function () {
                             if (!$(this).hasClass("selstatecolor")) {
                                 $(this).css({ "-webkit-box-shadow": bg });
                                 $(this).css({ "-moz-box-shadow": bg });
                                 $(this).css({ "box-shadow": bg });
                                 $(this).css({ "background-color": bg });
                             }
                             if (!$(this).hasClass("rollovereffect")) {
                                 //Anu 12-may-2016 btn text rollover color & img
                                 var _ths = $(this).find('.k-element-button');
                                 var rollOverClr = _ths.attr("txtrollovercolor");
                                 var rollOverImg = _ths.attr("RollOverImgSrc");
                                 var isImgAvail = _ths.attr("image-avail");
                                 if (isImgAvail == "true") {
                                     if (rollOverImg != undefined && rollOverImg != "") {
                                         var _fsrc = _ths.find(".lblImg").attr("src");
                                         _ths.find(".lblImg").attr("src", rollOverImg);
                                         _ths.attr("orignalSrc", _fsrc);
                                     }
                                 }
                                 if (rollOverClr != undefined && rollOverClr != "None") {
                                     var _lblInnmostSpan = _ths.find(".lbl").find('span:only-child:last');
                                     _ths.attr("lblforecolor", _lblInnmostSpan.css("color"));
                                     _lblInnmostSpan.css("color", rollOverClr + " !important;");
                                 }
                             }
                         },
                         function () {
                             if (!$(this).hasClass("selstatecolor")) {
                                 $(this).css({ "-webkit-box-shadow": "" });
                                 $(this).css({ "-moz-box-shadow": "" });
                                 $(this).css({ "box-shadow": "" });
                                 $(this).css({ "background-color": defaultBgColor });
                             }
                             //Anu 12-may-2016 btn text rollover color & img
                             if (!$(this).hasClass("rollovereffect")) {
                                 var _ths = $(this).find('.k-element-button');
                                 var rollOverClr = _ths.attr("txtrollovercolor");
                                 var rollOverImg = _ths.attr("RollOverImgSrc");
                                 var imgAvail = _ths.attr("orignalSrc");
                                 if (imgAvail != undefined && imgAvail != "") {
                                     var _fsrc = _ths.find(".lblImg").attr("src");
                                     _ths.find(".lblImg").attr("src", imgAvail);
                                     _ths.attr("orignalSrc", "");
                                 }
                                 if (rollOverClr != undefined && rollOverClr != "None") {
                                     var _lblInnmostSpan = _ths.find(".lbl").find('span:only-child:last');
                                     _lblInnmostSpan.css("color", _ths.attr("lblforecolor"));
                                 }
                             }
                         }
                     );
                });
                //end
                //clear reference
                $("#fancyreferencePopup .refHeader p").html("");
                //AR 5 Aug 2015 Hide/Show Close
                if (( _obj.HideHeader == true) && (_obj.HideClose == undefined || _obj.HideClose == true)) {
                        $("#fancyreferencePopup .refHeader").hide();
                        $("#fancybox-content").css({"padding":"0px"});
                    }
                else if (( _obj.HideHeader == true) && _obj.HideClose == false) {
                        $("#fancyreferencePopup .refHeader").show();
                    $("#fancyreferencePopup .refHeader").css({ "border-bottom": "none" });
                    $("#fancyreferencePopup .refHeader a").css({ "margin": "-4px 12px 0px 0px", "float": "right" });
                    $("#fancyreferencePopup .refHeader p").html("");
                    $("#fancybox-content").css({"padding":"0px"});
                }
                else if (_obj.HideHeader == false && (_obj.HideClose == true)) {
                    $("#fancyreferencePopup .refHeader").show();
                        $("#fancyreferencePopup .refHeader").css({ "border-bottom": "1px solid" });
                        $("#fancyreferencePopup .refHeader p").html(_obj.RefLinkText);
                    $("#fancyreferencePopup .refHeader a").hide();
                }
                else {
                    $("#fancyreferencePopup .refHeader").show();
                    $("#fancyreferencePopup .refHeader").css({ "border-bottom": "1px solid" });
                    $("#fancyreferencePopup .refHeader p").html(_obj.RefLinkText);
                    $("#fancyreferencePopup .refHeader a").css({ "margin": "-25px 10px 0px 0px", "float": "right" });
                }
                popupWidth = $(refContent.find(".band").get(0)).width();
                refContent.find(".band").each(function () {
                    $(this).css({ "width": "100%", "height": "auto" });
                    //RA-24Dec15-TabIndex
                    $(this).find(".k-element-box").each(function () {
                        var _kElement = $(this);
                        setAccessibilityData(_kElement);
                    });
                });
                removeUnwantedDivs(refContent);
                break;
            }
        }
    }
    $.fancybox({
        'href': "#fancyreferencePopup",
        'padding': 0,
        'showCloseButton': false,
        'hideOnOverlayClick': false,
        'hideOnContentClick': false,
        'onComplete': function () {
            $("#fancyreferencePopup").parent().css({ "overflow": "hidden" });
            $("#fancybox-overlay").show();
            $("#fancybox-content").css({"padding":"0px"});
            //var perc = getPerc(popupWidth, devicewidth); //, $(window).width());
            //$("#fancybox-wrap").css({ 'width': perc + "%", "max-width": devicewidth });
            //$("#fancybox-content").css('width', "100%");
            InitializeComponents($('#fancybox-content'));
            if(typeof k_Cust_RefPopupComplete == 'function')
            {
                k_Cust_RefPopupComplete();
            }
            removeUIObjects();
        },
        'onClosed': function () {
            if (gotoNextPageFlag || $("#fancyreferencePopup").attr("navtoNext") == "true") {
                gotoNextPageFlag = false;
                // Dont need transition effect
                //$("#NextPage").click();
                var tmpNxtPg = GetPage(gCurrPageObj.NextPageId);
                if (tmpNxtPg != undefined && tmpNxtPg != null) {
                    setTimeout(function () { SelectPageFromMap(gCurrPageObj.NextPageId); }, 0);
                }
            }
            if ($('.audiocontent').html() != '') {
                var player = MediaElementPlayer($('.audiocontent').find('audio'));
                player.pause();
            }
        }
    });
    //});
}
function MakeontentResponsive(devicewidth, obj) {
                var col_org_wd, col_org_ht, col_cal_wd, col_cal_ht;
                obj.find(".column").each(function () {
                    var ths_column = $(this);
                    var ieversion = msieversion();
                    /*var pixels = wd * (1024 / 100);*/
                    if (ieversion == 9 || ieversion == 8) {
                        ths_column.find(".k-element-box[temptype='Image']").each(function () {
                            $(this).attr("originaltop", $(this).css('top'));
                            $(this).attr("originalleft", $(this).css("left"));
                        });
                        ths_column.find(".k-element-box[temptype='Button']").each(function () {
                            $(this).css({
                                "cursor": "pointer"
                               , "box-sizing": "content-box"
                            });
                        });
                        return;
                    }
                    col_org_wd = ths_column.outerWidth();
                    col_org_ht = ths_column.outerHeight();
                    col_cal_wd = getPerc(col_org_wd, devicewidth);
                    // VinodBonde -- make changes here to increase the height of the row based on the actual text height and the container height
                    //Text component
                    ths_column.find(".k-element-box[temptype='Text']").each(function () {
                        $(this).css({
                            "position": "absolute",
                            "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
                          , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
                        });
                        $(this).removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
                    });
                    // Rahul 17-Feb-2015 - Text Entry Component
                    ths_column.find(".k-element-box[temptype='TextEntry']").each(function () {
                        $(this).css({
                            "position": "absolute",
                            "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
                          , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
                        });
                        if (msieversion() == 9 || msieversion() == 10 || isIE11version == true || (/Firefox[\/\s](\d+\.\d+)/.test(navigator.userAgent))) {
                            $(this).find(".k-element-textentry").css({ "font-size": "12px" });
                        }
                        $(this).removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
                    });
                    //Image component
                    ths_column.find(".k-element-box[temptype='Image']").each(function () {
                        //Rahul 10April-2014 - changed as % conversion not working for Safari
                        $(this).attr("originalTop", $(this).css('top'));
                        //$(this).attr("originalLeft", $(this).css('left'));
                        var leftperc = getPerc($(this).css("left"), ths_column.outerWidth());
                        $(this).attr("originalLeft", leftperc + "%");
                        var showContainer = $(this).attr("showContainer");
                        if (showContainer == "False" || showContainer == undefined) {
                            $(this).css({
                                "height": "",//Commented as it is showing big image in safari.
                                "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
                              , "left": leftperc + "%"
                            });
                        } else {
                            $(this).css({
                                "height": $(this).height() + "px",
                                "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
                              , "left": leftperc + "%"
                              , "overflow": "auto"
                            });
                        }
                        addImageOriginalHeightAndWidthToBox($(this));
                        if (showContainer == "False" || showContainer == undefined) {
                            $(this).find(".k-element-image").css({ "height": "", "width": "" });
                            $(this).find("div.divImageDescription").css({ "width": "100%" });
                        } else {
                            $(this).find("div.divImageDescription").css({ "width": "100%", "float": "left" });
                        }
                        $(this).removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
                    });
                    //videocomponent
                    ths_column.find(".k-element-box[temptype='Video']").each(function () {
                        var boxht = $(this).height();
                        var vidht = $(this).find(".k-element-video").height();
                        $(this).css({
                            "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
                            , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
                        });
                        $(this).find(".k-element-video").css({
                            "width": "100%"
                            , "height": getPerc(vidht, boxht) + "%"
                        });
                        $(this).find("div.divVideoDescription").css({ "width": "100%" });
                        $(this).removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
                    });
                    //Rahul 12-jan-2015 - Audio Component
                    ths_column.find(".k-element-box[temptype='Audio']").each(function () {
                        $(this).css({
                            "height": "30px",
                            "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
                            , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
                        });
                        $(this).removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
                    });
                    //textasset component
                    ths_column.find(".k-element-box[temptype='TextAsset']").each(function () {
                        var ftextAssetw = $(this).outerWidth() - (this.style.padding.slice(0, -2) * 2);
                        var ftextAsseth = $(this).outerHeight() - (this.style.padding.slice(0, -2) * 2);
                        var fAssettype = $(this).find(".k-element-textasset").attr("fimgorvideo"); //image or video
                        var fimgwd, fimgh;
                        $(this).css({
                            "position": "absolute",
                            "width": getPerc($(this).width(), ths_column.outerWidth()) + "%"
                           , "left": getPerc($(this).css("left"), ths_column.outerWidth()) + "%"
                        });
                        if (fAssettype == "image") {
                            fimgwd = $(this).find("img.TIC-img").attr("width");
                            fimgh = $(this).find("img.TIC-img").attr("height");
                        }
                        else if (fAssettype == "video") {
                            fimgwd = $(this).find("div.textVideo").css("width");
                            fimgh = $(this).find("div.textVideo").css("height");
                        }
                        $(this).find("div.TICvidArea.TICImgSec").css({
                            "width": getPerc(fimgwd, ftextAssetw) + "%"
                        });
                        $(this).find("img.TIC-img").removeAttr("width").removeAttr("height").css({
                            "width": "100%"
                            //"height": "",
                        });
                        $(this).find("div.TICvideoDescription").css({ "width": getPerc($(this).find("div.TICvideoDescription").width(), fimgwd) + "%" });
                        $(this).find("div.textVideo").css({ "width": "100%" });
                        $(this).removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
                    });
                    ths_column.attr("ow", col_org_wd);
                    ths_column.attr("oh", col_org_ht);
                    if (parseInt(col_org_wd) > parseInt(devicewidth)) {
                        col_cal_ht = 100 * col_org_ht / col_org_wd;
                        ths_column.css({
                            "width": "100%"
                            , "position": "relative"
                        });
                    }
                    else {
                        col_cal_ht = col_cal_wd * col_org_ht / col_org_wd;
                        var margin = "auto";
                        if (navigator.userAgent.indexOf("Firefox") != -1) {
                            margin = ((100 - col_cal_wd) / 2) + "%";
                        }
                        ths_column.css({
                            "width": col_cal_wd + "%",
                            "margin": "auto " + margin,
                            "position": "relative"
                        });
                    }
                    //remove column data as column itself is relative to hold absolute divs.
                    ths_column.html(ths_column.find(".column-Data").html());
                    ths_column.removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
                });
                //obj.find(".band").each(function () {
                //    $(this).css({ "width": "100%", "height": "auto" });




    //});
}

//naveen - added for poup preview.
function fShowPopupPreview()
{
    _obj = {}
    _obj.PopupText = parent.$("#CEPContainer").html();
    _obj.RefLinkText = parent.$("#divPageTitle").find(".k-element-text").html();
    _obj.BoxPadding = parent.$("#refpropsDiv").find('.refBoxPadding').val();
    _obj.HideHeader = parent.$("#refpropsDiv").find(".refHideHeader").prop("checked");
    _obj.HideClose = parent.$("#refpropsDiv").find(".refHideClose").prop("checked");
    $(".ContentArea").find("div.video-js").each(function () {
        var videoID = $(this).attr("id");
        if (videoID != undefined && videoID != null && videoID != "") {
            var myPlayer = videojs(videoID);
            myPlayer.pause();
        }
    });
    $(".ContentArea").find(".k-element-audio").each(function () {
        var audSrc = $(this).attr("fsrc");
        if (audSrc != undefined && audSrc != null && audSrc != "") {
            var player = MediaElementPlayer($(this).find("audio"));
            player.pause();
        }
    });
    var refContent = $("#fancyreferencePopup .refContent");
    //Anu 21-apr-2015 ref pop up box padding
    var boxPad = _obj.BoxPadding;
    if (boxPad != undefined && boxPad != '') {
        refContent.css("padding", boxPad + "px");
    }
    refContent.html(_obj.PopupText);
    //var showfancyclose = false;
    //clear reference
    $("#fancyreferencePopup .refHeader p").html("");
    //AR 5 Aug 2015 Hide/Show Close
    if ((_obj.HideHeader == true) && (_obj.HideClose == undefined || _obj.HideClose == true)) {
        $("#fancyreferencePopup .refHeader").hide();
        //showfancyclose = true;
    }
    else if ((_obj.HideHeader == true) && _obj.HideClose == false) {
        $("#fancyreferencePopup .refHeader").show();
        $("#fancyreferencePopup .refHeader").css({ "border-bottom": "none" });
        $("#fancyreferencePopup .refHeader a").css({ "margin": "-4px 12px 0px 0px", "float": "right" });
        $("#fancyreferencePopup .refHeader p").html("");
    }
    else if (_obj.HideHeader == false && (_obj.HideClose == true)) {
        $("#fancyreferencePopup .refHeader").show();
        $("#fancyreferencePopup .refHeader").css({ "border-bottom": "1px solid" });
        $("#fancyreferencePopup .refHeader p").html(_obj.RefLinkText);
        $("#fancyreferencePopup .refHeader a").hide();
        //showfancyclose = true;
    }
    else {
        $("#fancyreferencePopup .refHeader").show();
        $("#fancyreferencePopup .refHeader").css({ "border-bottom": "1px solid" });
        $("#fancyreferencePopup .refHeader p").html(_obj.RefLinkText);
        $("#fancyreferencePopup .refHeader a").css({ "margin": "-25px 10px 0px 0px", "float": "right" });
    }
    refContent.find(".band").each(function () {
        $(this).css({ "width": "100%", "height": "auto" });
    });
    //Anu 29-july-2015 Ref pop up updates
    removeUnwantedDivs(refContent);
    $.fancybox({
        'href': "#fancyreferencePopup",
        'padding': 0,
        'showCloseButton': false,
        'hideOnOverlayClick': false,
        'hideOnContentClick': false,
        'onComplete': function () {
            $("#fancyreferencePopup").parent().css({ "overflow": "hidden" });
            $("#fancybox-overlay").show();
            InitializeComponents($('#fancybox-content'));
            removeUIObjects();
        },
        'onClosed': function () {
            if (gotoNextPageFlag || $("#fancyreferencePopup").attr("navtoNext") == "true") {
                gotoNextPageFlag = false;
                // Dont need transition effect
                //$("#NextPage").click();
                var tmpNxtPg = GetPage(gCurrPageObj.NextPageId);
                if (tmpNxtPg != undefined && tmpNxtPg != null) {
                    setTimeout(function () { SelectPageFromMap(gCurrPageObj.NextPageId); }, 0);
                }
            }
            if ($('.audiocontent').html() != '') {
                var player = MediaElementPlayer($('.audiocontent').find('audio'));
                player.pause();
            }
        }
    });
}
//28 april 2015gp added for assessmnet
//Anu 29-july-2015 Ref pop up updates
function GetRefTooltipText(refid, id, mapHSId, navtoNext) {
    var refText = "";
    if (gCurrPageObj.References == "[]") {
        // get the data from pageIdReferences.js synchronously
        gCurrPageObj.References = getDataFromJsFile(gCurrPageObj.PageId + "References.js");
    }

    //get text of  html in first k-element-text
    if (gCurrPageObj.References != undefined && gCurrPageObj.References.length != 0) {
        for (var i = 0; i <= gCurrPageObj.References.length - 1; i++) {
            if (refid == gCurrPageObj.References[i].RefId) {
                if (gCurrPageObj.References[i].PopupText != undefined) {
                    var _obj = gCurrPageObj.References[i];
                    //if ($(refText).find('.k-element-text').length > 0) {
                    //    refText = $(refText).find('.k-element-text:first').html();
                    //}
                    if (_obj.TemplateId != undefined && _obj.TemplateId != "") {
                        //sync with template after html set.
                        var templateobj = GetTemplateData(_obj.TemplateId);
                        if (templateobj != undefined) {
                            if (IsPreview && templateobj.TemplateData != undefined) {//gp 31-12-15 added for published cases
                            var jsonTempData = JSON.parse(templateobj.TemplateData);
                            SyncDataWithTemplate(jsonTempData, _obj, true);
                            }
                            else
                            {
                                SyncDataWithTemplate(templateobj, _obj, true);
                            }
                        }
                    }
                    refText = "<div>" + _obj.PopupText + "</div>";
                    var refContent = $(refText);
                    removeUnwantedDivs(refContent);
                    refText = refContent[0].outerHTML;
                    break;
                }
            }
        }
    }
    return refText;
}

//AR 8 April 2015 - Function to display message from user defined script
//Derived from fshowRefQtipPopup - Check any updates to this function for consistent display of popup
function fshowMessagePopup(message, title, showClose) {
    var refText;

    if (showClose == undefined)
        showClose = false;
    refText = message;
    var refContent = $("#fancyreferencePopup .refContent");
    refContent.html(refText);
    if (title == undefined || title == "") {
        title = "<p></p>";
    }

    $("#fancyreferencePopup .refHeader p").html(title);

    $("#fancyreferencePopup .refHeader").hide();
    showClose = true;

    $.fancybox({
        'href': "#fancyreferencePopup",
        'padding': 0,
        'showCloseButton': showClose,
        'hideOnOverlayClick': false,
        'hideOnContentClick': false,
        'onComplete': function () {
            $("#fancyreferencePopup").parent().css({ "overflow": "hidden" });
        },
        'onClosed': function () {
        }
    });
}

/*9-May-2014 ref popup position*/
function fShowReference(lReference, lObj) {
    var _parentDivWidth = $(lObj).parents(".ContentArea")[0].offsetWidth;
    var _parentDivHeight = $(lObj).parents(".ContentArea")[0].offsetHeight;

    $("#RefNotes").empty();
    $("#RefNotes").append('' + unescape(lReference).replace(/\n/g, "<br/>") + '')

    var refTextDiv = $("#RefTextDiv");
    var _popupHeight = refTextDiv.height();
    var _popupWidth = refTextDiv.width();

    var _objleft = $(lObj).offset().left;
    var _objtop = $(lObj).offset().top;

    refTextDiv.css("left", _objleft);
    if (_objleft + _popupWidth > _parentDivWidth) {
        refTextDiv.css("left", Math.abs(_parentDivWidth - _popupWidth) + "px");
    }
    else {
        refTextDiv.css("left", (_objleft - 10) + "px");
    }

    if (_objtop + _popupHeight > _parentDivHeight) {
        refTextDiv.css("top", Math.abs(_objtop - _popupHeight) + "px");
    }
    else {
        refTextDiv.css("top", (_objtop + 20) + "px");
    }

    refTextDiv.show("slow");

    //alert(unescape(lReference))
}

$("#RefClose").live("click", function () {
    $("#RefTextDiv").hide("slow");
});

function AspectRatioWiseImg(_this, src, _width, _height) {
    var img = new Image();
    img.onload = function () {
        var theWidth = img.width;
        var theHeight = img.height;
        if (theWidth > _width || theHeight > _height) {
            if ((theWidth / theHeight) > (_width / _height)) {
                var varTop = -(Math.round(_width * theHeight / theWidth) - _height) / 2;
                $(_this).css({
                    left: "0",
                    top: varTop,
                    width: _width + "px",
                    height: "auto",
                    position: "absolute"
                });
            }
            else {
                var varLeft = -(Math.round(_height * theWidth / theHeight) - _width) / 2;
                $(_this).css({
                    left: varLeft,
                    top: "0",
                    width: "auto",
                    height: _height + "px",
                    position: "absolute"
                });
            }
        } else {
            var varLeft = (_width / 2) - (theWidth / 2);
            var varTop = (_height / 2) - (theHeight / 2);
            $(_this).css({
                left: varLeft,
                top: varTop,
                width: theWidth + "px",
                height: theHeight + "px",
                position: "absolute"
            });
        }
    }
    img.src = src;
}

//Anu 28-july-2015 Ref pop up issue sol
$(".CKEditorRT").live("click", function () {
    fshowRefQtipPopup($(this).attr("refid"))

});

$("#fancyreferencePopup .refHeader a").live("click", function () {
    $.fancybox.close();
    //Anu 28-july-2015 Ref pop up issue sol
    $("#fancyreferencePopup .refContent").css("padding", "");
});


function fLoadVideoJsPlayer(_container, pageToLoad, obj) {
    var _vidId = "video_" + Math.random() + "-" + Math.random();
    var _wt = 640;
    var _ht = 480;
    var _poster = "";
    var _src = "";
    var str = "";
    var vidtype = "mp4";

    if (obj != undefined && obj != null) {
        if (obj.wt != undefined)
            _wt = obj.wt;

        if (obj.ht != undefined)
            _ht = obj.ht;

        if (obj.vidtype != undefined)
            vidtype = obj.vidtype;

        if (obj.poster != undefined && obj.poster != null)
            _poster = obj.poster;

        if (obj.src != undefined && obj.src != null)
            _src = obj.src;
    }

    //Page Level Video.
    if (pageToLoad != undefined && pageToLoad != null && pageToLoad != "") {
        if (pageToLoad.PageContent.VideoReference != undefined && pageToLoad.PageContent.VideoReference != null) {
            _src = pageToLoad.PageContent.VideoReference;
            if (pageToLoad.PageContent.VideoWidth != undefined && pageToLoad.PageContent.VideoWidth != "") {
                _wt = pageToLoad.PageContent.VideoWidth;
                _ht = (Math.round(pageToLoad.PageContent.VideoWidth / pageToLoad.PageContent.VideoAspectRatio));
            }
            if (pageToLoad.PageContent.VideoType != undefined && pageToLoad.PageContent.VideoType == "youtube") {
                vidtype = "youtube";
            }
            else {
                vidtype = "mp4";
            }
        }
    }

    if (vidtype == "youtube") {
        str = "<video id='" + _vidId + "' class='video-js vjs-default-skin vjs-big-play-centered'  controls preload='auto' width='" + _wt + "' height='" + _ht + "'  src=''></video>";
    }
    else {

        if (_poster == "" && _src != "") {
            _poster = _src.replace(".mp4", "thumb1.jpg");
        }

        if (iPadClickStatus != "true") {
            str = "<video id='" + _vidId + "' class='video-js vjs-default-skin vjs-big-play-centered'  controls preload='auto' width='" + _wt + "' height='" + _ht + "'><source src='" + _src + "' type='video/mp4' /></video>";
        }
        else {
            str = "<video id='" + _vidId + "' poster='" + _poster + "'  controls preload='auto' autoplay='autoplay' width='" + _wt + "' height='" + _ht + "'><source src='" + _src + "' type='video/mp4' /></video>";

        }
    }
    //Append videostr to container.
    _container.find(".video-js").remove();
    _container.append($(str));
    var isAnimation = false;
    if (_container.hasClass("k-element-video") && _container.attr("Animation") != undefined && _container.attr("Animation") == "true") {
        isAnimation = true;
    }
    if (vidtype == "youtube") {
        videojs(_vidId, {
            'techOrder': ['youtube'],
            'poster': _poster,
            'src': _src
        })
    }
    else {
        if (iPadClickStatus != "true") {
            if (isAnimation) {
                videojs(_vidId, {
                    'poster': _poster,
                    autoplay: true,
                    controls: false,
                },
                        function () {
                            videojs_player = this;
                            videojs_player.off('click');
                            videojs_player.on("click", function (event) {
                                event.preventDefault();
                            });
                        });
            }
            else {
                videojs(_vidId, {
                    'poster': _poster
                });
            }
        }
    }

    if (_container.hasClass("k-element-video")) {
        _container.find(".video-js").css({
            "height": "100%"
            , "width": "100%"
        });
    }
}
//Anu 3-nov-2014 - TextAsset Component
function fLoadtextVideoJsPlayer(_container, pageToLoad, obj) {
    var _vidId = "video_" + Math.random() + "-" + Math.random();
    var _wt = 640;
    var _ht = 480;
    var _poster = "";
    var _src = "";
    var str = "";
    var vidtype = "mp4";

    if (obj != undefined && obj != null) {
        if (obj.wt != undefined)
            _wt = obj.wt;

        if (obj.ht != undefined)
            _ht = obj.ht;

        if (obj.vidtype != undefined)
            vidtype = obj.vidtype;

        if (obj.poster != undefined && obj.poster != null)
            _poster = obj.poster;

        if (obj.src != undefined && obj.src != null)
            _src = obj.src;
    }

    //Page Level Video.
    if (pageToLoad != undefined && pageToLoad != null && pageToLoad != "") {
        if (pageToLoad.PageContent.VideoReference != undefined && pageToLoad.PageContent.VideoReference != null) {
            _src = pageToLoad.PageContent.VideoReference;
            if (pageToLoad.PageContent.VideoWidth != undefined && pageToLoad.PageContent.VideoWidth != "") {
                _wt = pageToLoad.PageContent.VideoWidth;
                _ht = (Math.round(pageToLoad.PageContent.VideoWidth / pageToLoad.PageContent.VideoAspectRatio));
            }
            if (pageToLoad.PageContent.VideoType != undefined && pageToLoad.PageContent.VideoType == "youtube") {
                vidtype = "youtube";
            }
            else {
                vidtype = "mp4";
            }
        }
    }

    if (vidtype == "youtube") {
        str = "<video id='" + _vidId + "' class='video-js vjs-default-skin vjs-big-play-centered'  controls preload='auto' width='" + _wt + "' height='" + _ht + "'  src=''></video>";
    }
    else {
        str = "<video id='" + _vidId + "' class='video-js vjs-default-skin vjs-big-play-centered'  controls preload='auto' width='" + _wt + "' height='" + _ht + "'><source src='" + _src + "' type='video/mp4' /></video>";
        if (_poster == "" && _src != "") {
            _poster = _src.replace(".mp4", "thumb1.jpg");
        }
    }
    //Append videostr to container.
    _container.find(".video-js").remove();
    _container.find(".textVideo").append($(str));
    if (vidtype == "youtube") {
        videojs(_vidId, {
            'techOrder': ['youtube'],
            'poster': _poster,
            'src': _src
        })
    }
    else {
        videojs(_vidId, {
            'poster': _poster
        })
    }

    //21-nov-2014-Anu-textasset-WebRe
    if (_container.hasClass("k-element-textasset")) {
        _container.find(".video-js").css({
            "height": "100%"
            , "width": "100%"
        });
    }
}

// Rahul 17-Feb-2015 - Text Entry Component
var validationCheck, ValidationText, popupcheck, watermarkText, action_type, action_value, refId;
$(".k-element-textentry").live("focus", function () {
    validationCheck = $(this).closest(".k-element-box").attr("validationCheck");
    ValidationText = getCkeText($(this).closest(".k-element-box").attr("ValidationText"));
    //
    if (ValidationText != undefined && ValidationText != "")
        ValidationText = ValidationText.split("~~~");

    if ($(this).attr("popupCheck") == undefined) {
        popupcheck = $(this).closest(".k-element-box").attr("popupCheck");
    }
    else {
        popupcheck = $(this).attr("popupCheck");
    }
    watermarkText = $(this).closest(".k-element-box").attr("wt");
    if (watermarkText == undefined) {
        watermarkText = $.trim($(this).text());
        $(this).closest(".k-element-box").attr("wt", watermarkText);
    }
    if ($.trim($(this).text()) == watermarkText) {
        var txtToPlace = $(this).html().replace(watermarkText, "&nbsp;")
        // Anu 3-march-2015 - Text Entry Component cursor and space issue sol
        //txtToPlace = txtToPlace.trim()

        //txtToPlace = txtToPlace.replace("&nbsp;", "").replace(" ","");
        $(this).html(txtToPlace);
    }
    placeCaretAtEnd(document.getElementById($(this).attr("id")));
});

//place cursor in contenteditable at end or make it visible when set focus
function placeCaretAtEnd(el) {
    //el.focus();
    if (typeof window.getSelection != "undefined"
            && typeof document.createRange != "undefined") {
        var range = document.createRange();
        range.selectNodeContents(el);
        range.collapse(false);
        var sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
    } else if (typeof document.body.createTextRange != "undefined") {
        var textRange = document.body.createTextRange();
        textRange.moveToElementText(el);
        textRange.collapse(false);
        textRange.select();
    }
}

$(".k-element-textentry").live("blur", function () {
    watermarkText = $(this).closest(".k-element-box").attr("wt");
    if (isCkeEmpty($.trim($(this).text()))) {
        $(this).find("span:last").text(watermarkText);
    }
});

//Anu 25-may-2015 text entry validation is case sensitive
function ExistInValidationTextList(_fvalue, isCaseSensitive) {
    var flag = false;
    if (isCaseSensitive == undefined || isCaseSensitive == false || isCaseSensitive == "false") {
        _fvalue = _fvalue.toLowerCase();
        for (var i = 0; i < ValidationText.length; i++) {
            if (_fvalue == getCkeText(ValidationText[i]).toLowerCase()) {
                flag = true;
                break;
            }
        }
    }
    else {
        for (var i = 0; i < ValidationText.length; i++) {
            if (_fvalue == getCkeText(ValidationText[i])) {
                flag = true;
                break;
            }
        }
    }
    return flag;
}

$(".k-element-textentry").live("keydown", function (e) {
    if (e.which == 8) {
        if (getCkeText($.trim($(this).text())) == "") {
            e.preventDefault();
            return;
        }
    }
    if (e.which == 13) {
        var str = $(this).text();
        //Anu 25-may-2015 text entry validation is case sensitive
        if (ExistInValidationTextList(getCkeText(str.trim()), $(this).attr("isCaseSensitive"))) {
            var k_box = $(this).closest(".k-element-box");
            //Anu 29-apr-2015 score for scorecard parameter
            var isclicked = k_box.attr("isclicked");
            if (gActionScoreTracking && isclicked == undefined) {
                k_box.attr("isclicked", "true");
                SetCumulativeAndPageScore(k_box);
                showSimScore(true);
            }
            if (popupcheck != undefined && (popupcheck == "true" || popupcheck == true)) {
                action_type = $(this).attr('action-type');
                action_value = $(this).attr('action-value');
                refId = $(this).attr('action-refid');
                if (action_value == refId) {
                    if (validationCheck != undefined && (validationCheck == "true" || validationCheck == true)) {
                        fshowRefQtipPopup(refId, undefined, undefined, true);
                    } else {
                        fshowRefQtipPopup(refId, undefined, undefined, false);
                    }
                }
            } else {
                if (validationCheck != undefined && (validationCheck == "true" || validationCheck == true)) {
                    if (gNextPageId != "" && !isSPP) { //RA-2Oct15
                        $.fancybox.showActivity();
                        var nextPage = GetPage(gNextPageId)
                        gPrevPageIdArray.push(gCurrPageObj.PageId);
                        gCurrPageObj = nextPage;
                        gNextPageId = nextPage.NextPageId;
                        //Always last statement as inside function next and prev button active is desided.
                        LoadPageContent(nextPage);
                        //Enable Prev button
                        $("#PrevPage").removeClass("disabled");
                        //check if Disable Next button
                        if (gNextPageId == "") {
                            $("#NextPage").addClass("disabled");
                        }
                        else if (gCurrPageObj.PageType == "Poll") {
                            var disablenext = IsDisableNextForSurvey();
                            if (disablenext) {
                                $("#NextPage").addClass("disabled");
                            }
                            else {
                                $("#NextPage").removeClass("disabled");
                            }
                        }
                        else if ($("#NextPage").hasClass("disabled")) {
                            $("#NextPage").removeClass("disabled");
                        }
                        $.fancybox.hideActivity();
                        $.fancybox.close(); //RA-25Sep15 - to hide popup on next page
                    }
                }
            }
            e.preventDefault();
            return;
        } else {
            //Anu 21-may-2015 text entry incorrect feedbk
            var incorrect_fdbk = $(this).attr('incorrect-fdbk');
            var refId = $(this).attr('incorrect-fdbk-refid');
            if (incorrect_fdbk != undefined && refId != undefined && refId != "") {
                fshowRefQtipPopup(refId, undefined, undefined, false);
            }
            e.preventDefault();
            return;
        }
    }
});




// Rahul 17-Feb-2015 - Text Entry Component
function isCkeEmpty(data) {
    var cktext = "";
    if (data != undefined) {
        var cktext = $.trim($("<div>" + data + "</div>").text()).replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
    }
    if (cktext == "") {
        return true;
    }
    else {
        return false;
    }
}

function getCkeText(data) {
    var cktext = "";
    if (data != undefined) {
        //Rahul 16April2015 - changed as accepting single quote as correct answer
        var cktext = $.trim($("<div>" + data + "</div>").text()).replace(/[^A-Za-z 0-9 \.,\?""'!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
    }
    return cktext;
}


//Anu 26-sep-2014 - Button Components
//Aditi - added touch start
$(".k-element-box[temptype='Button']").live("click touchstart", function () {
    if (typeof window.imageLoaded !== "undefined") {
        window.imageLoaded = false;
    }
    var k_box = $(this).closest('.k-element-box');
    if (k_box.hasClass("disabled")) return;
    if ($(this).hasClass("disabled")) return;
    var eleBtn = $(this).find('.k-element-button');
    var action_type = eleBtn.attr('action-type');
    var action_value = eleBtn.attr('action-value');
    var refId = eleBtn.attr('action-refid');
    //Anu 29-apr-2015 score for scorecard parameter
    var isclicked = $(this).attr("isclicked");
    //Anu 17-aug-2015 button show selected state color
    var ssclr = eleBtn.attr('selstatecolor');
    if (gActionScoreTracking && isclicked == undefined) {
        $(this).attr("isclicked", "true");
        if (ssclr == undefined || ssclr == "none") {
            SetCumulativeAndPageScore($(this));
            showSimScore(true);
        }
    }

    if (ssclr != undefined && ssclr != "none") {

        $(".k-element-box.selstatecolor").each(function () {
            $(this).css({ "background-color": $(this).attr("origBGColor11") });
            $(this).css({ "-webkit-box-shadow": "" });
            $(this).css({ "-moz-box-shadow": "" });
            $(this).css({ "box-shadow": "" });
            //DDeva:17/05/16 - apply original image and text color to other btn elements
            var _ths = $(this).find('.k-element-button');
            var rollOverClr = _ths.attr("txtrollovercolor");
            var rollOverImg = _ths.attr("RollOverImgSrc");
            var imgAvail = _ths.attr("orignalSrc");
            if (imgAvail != undefined && imgAvail != "") {
                var _fsrc = _ths.find(".lblImg").attr("src");
                _ths.find(".lblImg").attr("src", imgAvail);
                //_ths.attr("orignalSrc", "");
            }
            if (rollOverClr != undefined && rollOverClr != "None") {
                var _lblInnmostSpan = _ths.find(".lbl").find('span:only-child:last');
                _lblInnmostSpan.css("color", _ths.attr("lblforecolor"));
            }
            $(this).removeClass("selstatecolor");
            $(this).closest('.k-element-box').removeClass("rollovereffect");
        });

        //k_box.attr("origBGColor", k_box.css("background-color"));
        if (eleBtn.attr("orignalSrc") == undefined || eleBtn.attr("orignalSrc") == "") {
            var _fsrc = eleBtn.find(".lblImg").attr("src");//gp 28-07-16 added code to save orignal image source if user is navigating using tab
            eleBtn.attr("orignalSrc", _fsrc);
        }
        if (eleBtn.attr("lblforecolor") == undefined || eleBtn.attr("lblforecolor") == "") {
            var _lblInnmostSpan = eleBtn.find(".lbl").find('span:only-child:last');
            eleBtn.attr("lblforecolor", _lblInnmostSpan.css("color"));
        }
        k_box.css({ "background-color": ssclr });
        eleBtn.find(".lblImg").attr("src", eleBtn.attr("RollOverImgSrc"));
        eleBtn.find(".lbl").find('span:only-child:last').css("color", eleBtn.attr("txtrollovercolor"));
        defaultBgColor = ssclr;
        k_box.addClass("selstatecolor");


    }
    //Anu 12-may-2016 btn text rollover color & img
    k_box.addClass("rollovereffect");
    switch (action_type) {
        case 'URL':
            window.open(action_value);
            break;
        case 'PAGE'://RA-13June2016 - Next page load animation effect.
            $(".ContentArea").animate({
                opacity: 0
            }, gPageTransitionDuration, "linear", function () {
                SelectPageFromMap(action_value, function () {
                    $(".ContentArea").animate({
                        opacity: 1
                    }, gPageTransitionDuration, "linear");
                });
            });
            break;
        case 'POPUP':
            if (action_value == refId)
                fshowRefQtipPopup(refId);
            break;
            //Anu 19-aug-2015 btn comp new feature tab popup
        case 'TABPOPUP':
            var tabPopupStr = eleBtn.attr("tabPopupStr");
            var gTabPopupJs;
            if (tabPopupStr != undefined) {
                gTabPopupJs = JSON.parse(tabPopupStr);
            }
            else {
                gTabPopupJs = {};
            }
            //Anu 20-aug-2015 pass btn comp
            GeneratePopup(gTabPopupJs, eleBtn);
            break;
    }
});







//Function to convert hex format to a rgb color
function rgb2hex(rgb) {
    rgb = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
    if (rgb != null) {
        function hex(x) {
            return ("0" + parseInt(x).toString(16)).slice(-2);
        }
        return "#" + hex(rgb[1]) + hex(rgb[2]) + hex(rgb[3]);
    }
    else {
        return "transparent";
    }
}

//end


$(".k-element-question table tr.optionrow").live("click", function () {
    //IsDisableNextForSurvey();
    var allowmultiselect = $(this).closest(".k-element-question").attr("mltselect");
    var optformat = $(this).closest(".k-element-question").attr("optformat");
    if (allowmultiselect == "true" || allowmultiselect == true) {
        if ($(this).hasClass("selected")) {
            $(this).removeClass("selected");
            $(this).find("td.optno input").removeAttr("checked");
        }
        else {
            $(this).addClass("selected");
            $(this).find("td.optno input").attr("checked", "checked");
        }
    }
    else {
        $(this).closest(".k-element-question").find("td.optno input").removeAttr("checked", "checked");
        $(this).closest(".k-element-question").find("tr.optionrow").removeClass("selected");
        $(this).addClass("selected");
        $(this).find("td.optno input").attr("checked", "checked");
    }
});

function GetNoOfQuestions() {
    return $(".k-element-question").length;
}

function GetAttemptedQuestionCount() {
    var attcount = 0;
    $(".k-element-question").each(function () {
        if ($(this).find("tr.optionrow.selected").length > 0) {
            attcount++;
        }
    });

    return attcount;
}

$(".btnpollingdone").live("click", function () {
    if (gCurrPageObj != undefined) {
        if (gCurrPageObj.AllQuesCompulsory == true || gCurrPageObj.AllQuesCompulsory == "true") {
            if (GetNoOfQuestions() == GetAttemptedQuestionCount()) {
                SetPollingResult();
            }
            else {
                alert("All questions are compulsory.");
                return;
            }
        }
        else {
            SetPollingResult();
        }

        //Show polling result on when done polling.
        if (gCurrPageObj.ShowPollResult == true || gCurrPageObj.ShowPollResult == "true") {
            ShowPollingResult();
        }
        else {
            //display next btn.
            $(".btnpollingdone").parent().hide();
            var spp = getParameterByName("SPP");
            if (!(spp != undefined && (spp == true || spp == "true"))) {
                gNextPageId = gCurrPageObj.NextPageId;
                if (gNextPageId != "") {
                    $("#NextPage").removeClass("disabled");
                }
            }
        }
    }
    else {
        alert("current page object is null");
        return;
    }
});


function SetPollingResult() {
    gPollResult = [];

    $(".k-element-question").each(function () {
        var pollQuestion = {};
        pollQuestion.QNo = $(this).find("td.qno").text();
        if ($(this).find("td.qtextdata").find(".k-element-box-clone[temptype='Video']").length > 0) {
            $(this).find("td.qtextdata").find(".k-element-box-clone[temptype='Video']").remove();
        }
        if ($(this).find("td.qtextdata").find(".k-element-box-clone[temptype='Image']").length > 0) {
            $(this).find("td.qtextdata").find(".k-element-box-clone[temptype='Image']").remove();
        }
        pollQuestion.QText = $(this).find("td.qtextdata").text();
        pollQuestion.Options = [];
        pollQuestion.SelectedOptions = "";
        var optcounter = 0;
        $(this).find("tr.optionrow").each(function () {
            optcounter++;
            var pollOption = {};
            // VinodBonde -- option id should be unique and not the counter. This will be required when we need randomization of options in output
            pollOption.OptNo = optcounter;
            if ($(this).find("td.qoptdata").find(".k-element-box-clone[temptype='Video']").length > 0) {
                $(this).find("td.qoptdata").find(".k-element-box-clone[temptype='Video']").remove();
            }
            if ($(this).find("td.qoptdata").find(".k-element-box-clone[temptype='Image']").length > 0) {
                $(this).find("td.qoptdata").find(".k-element-box-clone[temptype='Image']").remove();
            }
            pollOption.OptText = $.trim($(this).find("td.qoptdata").text());
            ////console.log("pollOption.OptText====" + pollOption.OptText);
            pollQuestion.Options.push(pollOption);
            if ($(this).hasClass("selected")) {
                pollQuestion.SelectedOptions += "," + optcounter;
            }
        });
        if (pollQuestion.SelectedOptions != "") {
            pollQuestion.SelectedOptions += ",";
        }
        pollQuestion.SelectedOptions = pollQuestion.SelectedOptions.replace(/\,,/g, "");

        gPollResult.push(pollQuestion);

    });

}

function ShowPollingResult() {

    $(".optionrow").hide();
    $(".btnpollingdone").parent().hide();
    var ShowResponseResult = gCurrPageObj.ShowResponseResult;
    $("#divPollChartContainer").empty();
    $("#divPollChartContainer").append($("<div style='    float: right;    padding: 5px;'><a href=# onclick=\"$('#divPollChartContainer').hide();$('#restOftheContent').show()\">Close Report</a></div>"))
    if (gPreviewOrPublish == "Publish") {

        var relModAttId = '';
        if (gRMAttemptData != undefined)
            relModAttId = gRMAttemptData.AttemptId;

        $.ajax({
            type: 'POST',
            url: knowdlBaseUrl + "/Poll/SavePollResponse",
            data: "caseId=" + Number(gCaseId) + "&pCaseId=" + Number(gPulishedVersionId) + "&relModId=" + gRMID + "&relModAttId=" + relModAttId + "&pageId=" + gCurrPageObj.PageId + "&userId=" + gLoggedInUserId + "&startDate="
	            + gPollStartTime.toUTCString() + "&endDate=" + new Date().toUTCString() + "&jsonPollResult=" + encodeURIComponent(JSON.stringify(gPollResult)),
            success: function (data) {

                // Plot poll chart using all users data
                var ArrQuestionChars = data.split("@@@@")
                for (var l = 0; l < ArrQuestionChars.length; l++) {
                    var oneQData = ArrQuestionChars[l].split("##")
                    //Added, as @@@@ attached last to the string
                    if (oneQData[2] != undefined) {
                        var divid = "QuestionChart" + oneQData[2].replace(")", "")
                        var questionDiv = $("<div id='" + divid + "' style='width:100%'></div>")
                        //$("#divPollChartContainer").append(questionDiv)

                        $(".k-element-question[position='" + oneQData[2].replace(")", "") + "']").append(questionDiv);
                        //// Matches exact string
                        //$("td.qno").filter(function () { return $(this).text() === oneQData[2]; }).closest(".k-element-question").append(questionDiv);
                        var selectedOptions = [];
                        $(".k-element-question[position='" + oneQData[2].replace(")", "") + "']").find("tr.optionrow.selected").each(function () {
                            selectedOptions.push($.trim($(this).find("td.qoptdata").text()));
                        });

                        getHighChartForQuestion(divid, oneQData[0], oneQData[1], ShowResponseResult, selectedOptions)
                    }
                }

            },
            error: function (xhr, data, message) {
                alert(message);
            }
        });

    }
    else {  // preview case -- show current data only
        for (var i = 0; i < gPollResult.length; i++) {
            var pollQuestion = gPollResult[i];
            var optionCountsArr = []
            var numberofVotes = 0
            for (var j = 0; j < pollQuestion.Options.length; j++) {
                optionCountsArr[j] = 0
                // VinodBonde -- option id should be unique and not the counter. This will be required when we need randomization of options in output
                if (pollQuestion.SelectedOptions.indexOf("," + pollQuestion.Options[j].OptNo + ",") != -1) {
                    optionCountsArr[j] = optionCountsArr[j] + 1
                    numberofVotes = numberofVotes + 1
                }
            }

            var pollDatastr = "[ "
            for (var k = 0; k < optionCountsArr.length; k++) {
                var optText = pollQuestion.Options[k].OptText.replace(/'/g, "`")
                // Set font color to green to show current user selection
                if (Number(optionCountsArr[k]) > 0) {
                    optText = "<span style=\"color:green\">" + optText + "</font>"
                }
                var votePercentage = (optionCountsArr[k] / numberofVotes) * 100
                if (pollDatastr == "[ ") {
                    //pollDatastr = pollDatastr + " ['" + optText + "'," + votePercentage + "] "
                    pollDatastr = pollDatastr + " {name :'" + optText + "',y :" + votePercentage + ",count : '" + optionCountsArr[k] + "'} "
                }
                else {
                    //pollDatastr = pollDatastr + ", ['" + optText + "'," + votePercentage + "] "
                    pollDatastr = pollDatastr + ", {name :'" + optText + "',y :" + votePercentage + ",count : '" + optionCountsArr[k] + "'}"
                }
            }
            pollDatastr = pollDatastr + " ]"
            var divid = "QuestionChart" + pollQuestion.QNo.replace(")", "")
            var questionDiv = $("<div id='" + divid + "'></div>")
            //$("#divPollChartContainer").append(questionDiv)
            $(".k-element-question[position='" + pollQuestion.QNo.replace(")", "") + "']").append(questionDiv)
            getHighChartForQuestion(divid, pollDatastr, pollQuestion.QText, ShowResponseResult)
        }
    }

    gNextPageId = gCurrPageObj.NextPageId;
    if (gNextPageId != "" && !isSPP) {//gp 7 sept 2015 added condition for single page preview
        $("#NextPage").removeClass("disabled");
    }
}

function getHighChartForQuestion(containerId, pollData, questionTextasTitle, ShowResponseResult, selectedOptions) {
    var chart = new Highcharts.Chart({
        chart: {
            renderTo: containerId,
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            height: 250,
            style: { fontFamily: ' Arial, sans-serif', fontSize: "12pt" }
        },
        title: {
            text: ''
        },
        tooltip: {
            useHTML: true,
            shared: false,
            formatter: function () {
                //Rahul 13Feb2015 - to solve mozilla undefined issue
                if (navigator.userAgent.indexOf("Firefox") != -1) {
                    return '<div style="max-width:500px;width:500px;white-space: pre-wrap !important;"><p>' + this.point.name + '</p>: ' + this.percentage.toFixed(2) + ' % </div>';
                } else {
                    return '<div style="max-width:500px;white-space: pre;"><p>' + this.point.name + '</p>: ' + this.percentage.toFixed(2) + ' % </div>';
                }
            }
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    color: '#000000',
                    style: { fontFamily: ' Arial, sans-serif', fontSize: "12pt" },
                    connectorColor: '#000000',
                    formatter: function () {
                        //alert(this.point.name);
                        var selabel = $('<b>' + this.point.name + '</b>');
                        if (selectedOptions != undefined && selectedOptions != null) {
                            for (var soctr = 0; soctr < selectedOptions.length; soctr++) {
                                if (selectedOptions[soctr] === selabel.text()) {
                                    selabel = $('<p><span style="color:green">' + this.point.name + '</span></p>');
                                    break;
                                }
                            }
                        }
                        var sertext = selabel.text().trim();
                        if (sertext.length > 25) {
                            sertext = sertext.substring(0, 25) + '...';
                        }
                        if (selabel.find("span:first").length > 0) {
                            selabel.find("span:first").html(sertext);
                        }
                        else {
                            selabel.html(sertext);
                        }
                        //Rahul 13Feb2015 - to solve mozilla undefined issue
                        if (navigator.userAgent.indexOf("Firefox") != -1) {
                            if (ShowResponseResult) {
                                return '<p><span style="color:green !important">' + selabel.get(0).outerHTML + '</span></p>' + ': ' + this.percentage.toFixed(2) + ' %' + " (Responses:" + this.point.count + ")";
                            }
                            else {
                                return '<p><span style="color:green !important">' + selabel.get(0).outerHTML + '</span></p>' + ': ' + this.percentage.toFixed(2) + ' %';
                            }
                        } else {
                            if (ShowResponseResult) {
                                return '<p><span style="color:green">' + selabel.get(0).outerText + '</span></p>' + ': ' + this.percentage.toFixed(2) + ' %' + " (Responses:" + this.point.count + ")";
                            }
                            else {
                                return '<p><span style="color:green">' + selabel.get(0).outerText + '</span></p>' + ': ' + this.percentage.toFixed(2) + ' %';
                            }
                        }
                        //return '<b>' + this.point.name + '</b>: ' + this.percentage + ' %';
                        //return '<b>' + ((this.point.name.length > 20) ? this.point.name.substring(0, 20) + '...' : this.point.name) + '</b>: ' + this.percentage + ' %';
                    }
                }
            }
        },
        series: [{
            type: 'pie',
            name: 'Poll result',
            data: eval(pollData)
        }]
    });

}

function removeUIClasses() {
    $(".ui-resizable").removeClass("ui-resizable")
    $(".ui-draggable").removeClass("ui-draggable")
    $(".ui-draggable-dragging").removeClass("ui-draggable-dragging")
    $(".ui-widget-content").removeClass("ui-widget-content")
    $(".k-element-text").attr("contenteditable", "false");
    $(".k-element-textentry").attr("contenteditable", "true");
    $(".k-element-checklist .itemlabel").attr("contenteditable", "false");
}

function removeUIObjects() {
    $(".ui-resizable-handle").remove()
    $(".ui-resizable-e").remove()
    $(".ui-resizable-s").remove()
    $(".ui-resizable-se").remove()
    $(".ui-icon-gripsmall-diagonal-se").remove()
    $(".k-element-strip").remove();

    $(".span.colNum").remove();
    $(".span.colWdt").remove();
    $(".span.colHght").remove();
    $(".k-asset-Resize").remove();
    $(".block-controls").remove();
}
function FindObjectInArray(arr, property, value) {
    var obj;
    for (var i = arr.length - 1; i >= 0; i--) {
        if (arr[i][property] == value) {
            obj = arr[i];
            break;
        }
    }
    return obj;
}

//24-nov-2014-Anu-ARS
function convertHtmlToText(html) {
    var tmp = document.createElement("DIV");
    tmp.innerHTML = html;
    return tmp.textContent || tmp.innerText || "";
}

$('#OptionViewBarChart').live("click", function () {
    callChartAjax('BarChart');
});
$('#OptionViewPieChart').live("click", function () {
    callChartAjax('PieChart');
});

function showPieChart(dataArr) {

    //var dataArr = eval(data);
    $('#divReport').show();
    $('#divReportContainer').show();
    $('#divReportContainer').highcharts({
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: 1, //null,
            plotShadow: false
        },
        title: {
            text: dataArr[0]
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                    style: {
                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                    }
                }
            }
        },
        series: dataArr[1]
    });
}

function showBarChart(data) {
    var dataArr = eval(data);
    $('#divReport').show();
    $('#divReportContainer').show();
    $('#divReportContainer').highcharts({
        chart: {
            type: 'column'
        },
        title: {
            text: dataArr[0]
        },
        subtitle: {
            text: 'any sub title if needed'
        },
        xAxis: {
            type: 'category',
            labels: {
                rotation: 0,
                style: {
                    fontSize: '13px',
                    fontFamily: 'Verdana, sans-serif'
                }
            }
        },
        yAxis: {
            min: 0, max: 100,
            title: {
                text: 'Anwsers (percentage)'
            }
        },
        legend: {
            enabled: false
        },
        tooltip: {
            pointFormat: 'Anwser given by users: <b>{point.y:.1f} percent</b>'
        },
        series: [{
            name: 'Population',
            data: dataArr[1],
            dataLabels: {
                enabled: true,
                rotation: -90,
                color: '#FFFFFF',
                align: 'right',
                x: 4,
                y: 10,
                style: {
                    fontSize: '13px',
                    fontFamily: 'Verdana, sans-serif',
                    textShadow: '0 0 3px black'
                }
            }
        }]
    });
}

function hideReport() {
    $('#divReport').hide();
    $('#divReportContainer').html('').hide();
}

function getFormatedDate(dateObj, format) {
    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var curr_date = dateObj.getDate();
    var curr_month = dateObj.getMonth();
    var numCurr_month = dateObj.getMonth();
    curr_month = curr_month + 1;
    var curr_year = dateObj.getFullYear();
    var curr_min = dateObj.getMinutes();
    var curr_hr = dateObj.getHours();
    var curr_sc = dateObj.getSeconds();
    if (curr_month.toString().length == 1)
        curr_month = '0' + curr_month;
    if (curr_date.toString().length == 1)
        curr_date = '0' + curr_date;
    if (curr_hr.toString().length == 1)
        curr_hr = '0' + curr_hr;
    if (curr_min.toString().length == 1)
        curr_min = '0' + curr_min;

    if (format == 1)//dd-mm-yyyy
    {
        return curr_date + "-" + curr_month + "-" + curr_year;
    }
    else if (format == 2)//yyyy-mm-dd
    {
        return curr_year + "-" + curr_month + "-" + curr_date;
    }
    else if (format == 3)//dd/mm/yyyy
    {
        return curr_date + "/" + curr_month + "/" + curr_year;
    }
    else if (format == 4)// MM/dd/yyyy HH:mm:ss
    {
        return curr_date + "-" + monthNames[numCurr_month] + "-" + curr_year + " " + curr_hr + ":" + curr_min + ":" + curr_sc;
    }
    else if (format == 5)// MM/dd/yyyy HH:mm:ss
    {
        return curr_month + "/" + curr_date + "/" + curr_year + " " + curr_hr + ":" + curr_min + ":" + curr_sc;
    }
}

function fUpdateAttemptDetails() {
    if ((gPackageType == 'SCORM 1.2' || gPackageType == 'SCORM 2004') && scorm.get('cmi.mode') == "review") {
        return;
    }
    if (gRMID != undefined && gRMID != null && gRMID != "") {

        gRMAttemptData.ReleaseModuleId = gRMID;
        gRMAttemptData.CurrentKnowdId = gCurrPageObj.PageId;

        gRMAttemptData.EndTime = getFormatedDate(GetServerTimeFromLocalTime(), 4);
        if (iPadClickStatus == "true") {
            gRMAttemptData.AccessMode = "iPad";
        }

        if (gCurrPageObj.IsCompletion) {
            gRMAttemptData.Status = "Complete";
        }
        else if (gNextPageId == "") {
            if (gCurrPageObj.PageType != 'DTP' && gCurrPageObj.PageType != 'RNP') {
                //gRMAttemptData.Status = "Complete";
            }
        }

        var isAsync = true;
        if (gRMAttemptData.Async != undefined && gRMAttemptData.Async == "false") {
            isAsync = false;
        }

        if (gPackageType == 'SCORM 1.2' || gPackageType == 'SCORM 2004') {
            GetLMSDataToLocalVariables();
            gRMAttemptData.AccessUserId = lms_studentId + "(" + lms_studentName + ")";
            gRMAttemptData.lms_studentId = lms_studentId;
            gRMAttemptData.lms_studentName = lms_studentName;
            gRMAttemptData.Score = lms_score;
        }

        if ($.trim(gRMAttemptData.AccessUserId) == "") {
            gRMAttemptData.AccessUserId = getDocumentCookie("cookieAccessUserId");
        }

        if (gNavigatedPageIds != undefined) {
            gRMAttemptData.NavigatedPageIds = gNavigatedPageIds;
        }

        /*if (gPackageType != 'SCORM 1.2' && gPackageType != 'SCORM 2004') {
        var servcUrl = knowdlBaseUrl + "/ReleaseInteraction/Process?command=postattemptdata";
        $.ajax({
            type: "POST",
            url: servcUrl,
            async: isAsync,
            data: {jsondata: JSON.stringify(gRMAttemptData)},
            success: function (result) {
                if (result != "") {
                    try{
                        gRMAttemptData.AttemptId = result.split("###")[0];
                        var accessUsrId = result.split("###")[1];
                        if (gRMAttemptData.AccessUserId == "" && accessUsrId != undefined && accessUsrId != "") {
                            gRMAttemptData.AccessUserId = accessUsrId;
                            document.cookie = "cookieAccessUserId=" + result.split("###")[1] + "; path=/";
                        }
                        if (gRMAttemptData.TrackingData == undefined || (gRMAttemptData.TrackingData != undefined && gRMAttemptData.TrackingData.length <= 0)) {
                            gRMAttemptData.TrackingData = JSON.parse(result.split("###")[2]);
                        }
                        gRMAttemptData.Async = "true";
                        gRMAttemptData.KnowdResponses = [];
                        gRMAttemptData.PostStatus = "Success";
                    }
                    catch (err) {
                        console.log(err);
                    }
                }
            },
            error: function (error) {
                gRMAttemptData.PostStatus = "Failed";
            }
        });*/

        //}
    }
}

function getDocumentCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1);
        if (c.indexOf(name) != -1) return c.substring(name.length, c.length);
    }
    return "";
}


function SetReleaseModuleResponces() {
    //return if rmid is undefined
    if (gRMID == undefined || gRMID == null || gRMID == "") return;

    if ((gSelectedOptionId != "" && gSelectedOptionId != undefined && gSelectedOptionId != null)
    || (gRankedOptionIdArray != undefined && gRankedOptionIdArray.length > 0)) {
        var qAnswered = false;
        //Reset if undefined
        if (gRMAttemptData.KnowdResponses == undefined || gRMAttemptData.KnowdResponses == null) gRMAttemptData.KnowdResponses = [];
        for (index = 0; index < gRMAttemptData.KnowdResponses.length; index++) {
            if (gRMAttemptData.KnowdResponses[index].KnowdId == gCurrPageObj.PageId) {
                qAnswered = true;
                gRMAttemptData.KnowdResponses[index].KnowdType = gCurrPageObj.PageType;
                if (gCurrPageObj.PageType == "DTP") {
                    gRMAttemptData.KnowdResponses[index].ResponseId = gSelectedOptionId;
                }
                else {
                    if (gRankedOptionIdArray.slice(0) != undefined) {
                        gRMAttemptData.KnowdResponses[index].ResponseId = gRankedOptionIdArray[0].Id;
                        var resseq = "";
                        for (j = 0; j < gRankedOptionIdArray.length; j++) {
                            if (resseq == "")
                                resseq = gRankedOptionIdArray[j].Id;
                            else
                                resseq = "," + gRankedOptionIdArray[j].Id;
                        }
                        gRMAttemptData.KnowdResponses[index].ResponseSequence = resseq;
                    }
                }
                break;
            }
        }
        if (qAnswered != true) {
            var objResponse = {};
            objResponse.KnowdId = gCurrPageObj.PageId;
            objResponse.KnowdType = gCurrPageObj.PageType;
            objResponse.ResponseSequence = "";
            if (gCurrPageObj.PageType == "DTP") {
                objResponse.ResponseId = gSelectedOptionId;
            }
            else {
                if (gRankedOptionIdArray.slice(0) != undefined) {
                    objResponse.ResponseId = gRankedOptionIdArray[0].Id;
                    var resseq = "";
                    for (j = 0; j < gRankedOptionIdArray.length; j++) {
                        if (resseq == "")
                            resseq = gRankedOptionIdArray[j].Id;
                        else
                            resseq = "," + gRankedOptionIdArray[j].Id;
                    }
                    objResponse.ResponseSequence = resseq;
                }
            }

            gRMAttemptData.KnowdResponses.push(objResponse);
        }
    }
}


function GetServerTimeFromLocalTime() {
    //ET - Estern Time
    offset = -5.0 //Eastern Time is five hours behind UTC time.
    clientDate = new Date();
    utc = clientDate.getTime() + (clientDate.getTimezoneOffset() * 60000);
    serverDate = new Date(utc + (3600000 * offset));
    return serverDate;
}
$('#ipSearchBox').live("keyup", function (e) {
    if (e.which == 27) {  // catch ESC key and clear input
        $(this).val('');
    }
    var filter = $(this).val();
    filter = filter.toLowerCase();
    var divSearchResult = $("#divSearchhResult");
    divSearchResult.empty();
    divSearchResult.hide();
    var searchIcon = $(".searchIcon");
    if (filter != "") {
        if (this.value === this.getAttribute('placeholder')) {
            this.value = '';
        }
        $(this).css("width", "390px");
        $(this).removeClass("ipSearchBoxDefault");
        $(this).addClass("ipSearchTestEntered");
        searchIcon.removeClass("seachIcondisplaynone");
        searchIcon.addClass("seachIcondisplayblock");
        var showSearchDiv = false;
        for (var i = 0; i < gPages.length; i++) {

            if (checkPageContainsSearchValue(gPages[i], filter)) {
                var pageTitle = $('<div>' + gPages[i].PageContent.Heading + '</div>').text();
                if (pageTitle.length > 43) {
                    pageTitle = pageTitle.slice(0, 43);
                }
                var content = "<span class='pageText'> p." + ((gPages[i].ArrayIndex) + 1) + " (" + gPages[i].PageType + ") " + pageTitle +
                               " </span>";
                //Naveen - Changed to pageId as used to redirect page by using page id.
                var selectPage = "<div class='loadSelectedPage' data-pageid='" + gPages[i].PageId + "'>" + content + "<div><br/>";

                divSearchResult.append(selectPage);
                showSearchDiv = true;
            }
        }
        if (showSearchDiv) {
            divSearchResult.show();
        }
        else {
            divSearchResult.hide();
        }
        //Rahul to hide on click outside the search 06-Feb-2015
        $('html').click(function (event) {
            if ($(event.target).closest('#ipSearchBox').length <= 0) {
                if (divSearchResult.is(":visible")) {
                    divSearchResult.hide();
                }
            }
        });
    }
    else {
        $(this).removeClass("ipSearchTestEntered");
        $(this).addClass("ipSearchBoxDefault");
        searchIcon.removeClass("seachIcondisplayblock");
        searchIcon.addClass("seachIcondisplaynone");
    }

});

// search in player need to be checked as data is removed from gPages while packaging --
// get the data from pageIdText.js synchronously
//pageToLoad.PageContent.Text = getDataFromJsFile(pageToLoad.PageId + "Text.js");
function checkPageContainsSearchValue(pageData, filter) {
    filter = $.trim(filter);
    var pageContent = pageData.PageContent;
    if (pageContent.Heading != undefined && pageContent.Heading != null && pageContent.Heading.toLowerCase().indexOf(filter) >= 0) {
        return true;
    }
    switch (pageData.PageType) {
        case "RNP":
            if (pageContent.QuestionText != undefined && pageContent.QuestionText != null && $(pageContent.QuestionText).text().toLowerCase().indexOf(filter) >= 0) {
                return true;
            }
            for (var i = 0; i < pageContent.Options.length; i++) {
                if (pageContent.Options[i].Text != undefined && pageContent.Options[i].Text != null && $(pageContent.Options[i].Text).text().toLowerCase().indexOf(filter) >= 0) {
                    return true;
                }
            }
            break;

        case "DTP":
            if (pageContent.QuestionText != undefined && pageContent.QuestionText != null) {
                if (CheckInKElementBox(pageContent.QuestionText, filter)) {
                    return true;
                }
            }
            for (var i = 0; i < pageContent.Options.length; i++) {
                if (pageContent.Options[i].Text != undefined && pageContent.Options[i].Text != null) {
                    if (CheckInKElementBox(pageContent.Options[i].Text, filter)) {
                        return true;
                    }
                }
            }
            break;
        case "TIP":
            if (pageContent.Text != undefined && pageContent.Text != null && $(pageContent.Text).text().toLowerCase().indexOf(filter) >= 0) {
                return true;
            }
            else if (pageContent.ImageDescription != undefined && pageContent.ImageDescription != null && $(pageContent.ImageDescription).text().toLowerCase().indexOf(filter) >= 0) {
                return true;
            }
            else if (pageContent.ImageDisplayName != undefined && pageContent.ImageDisplayName != null && $(pageContent.ImageDisplayName).text().toLowerCase().indexOf(filter) >= 0) {
                return true;
            }
            break;
        case "TOP":
            if (pageContent.Text != undefined && pageContent.Text != null && $(pageContent.Text).text().toLowerCase().indexOf(filter) >= 0) {
                return true;
            }
            break;
        case "Poll":
            if (pageContent.Text != undefined && pageContent.Text != null) {
                return CheckInKElementBox(pageContent.Text, filter);
            }
            break
        case "Assessment":
            if (pageContent.Text != undefined && pageContent.Text != null) {
                return CheckInKElementBox(pageContent.Text, filter);
            }
            break;
        case "CEP":
            if (pageContent.Text != undefined && pageContent.Text != null) {
                return CheckInKElementBox(pageContent.Text, filter);
            }
            break;
        case "SMP":
            if (pageContent.Text != undefined && pageContent.Text != null && $(pageContent.Text).text().toLowerCase().indexOf(filter) >= 0) {
                return true;
            }
            else if (pageContent.ImageDescription != undefined && pageContent.ImageDescription != null && $(pageContent.ImageDescription).text().toLowerCase().indexOf(filter) >= 0) {
                return true;
            }
            else if (pageContent.ImageDisplayName != undefined && pageContent.ImageDisplayName != null && $(pageContent.ImageDisplayName).text().toLowerCase().indexOf(filter) >= 0) {
                return true;
            }
            else if (pageContent.SummaryText != undefined && pageContent.SummaryText != null && $(pageContent.SummaryText).text().toLowerCase().indexOf(filter) >= 0) {
                return true;
            }
            break;
        case "TVP":
            if (pageContent.Text != undefined && pageContent.Text != null && $(pageContent.Text).text().toLowerCase().indexOf(filter) >= 0) {
                return true;
            }
            else if (pageContent.VideoDescription != undefined && pageContent.VideoDescription != null && $(pageContent.VideoDescription).text().toLowerCase().indexOf(filter) >= 0) {
                return true;
            }
            else if (pageContent.VideoDisplayName != undefined && pageContent.VideoDisplayName != null && $(pageContent.VideoDisplayName).text().toLowerCase().indexOf(filter) >= 0) {
                return true;
            }
            break;
        default:
            break;
    }
    return false;
}


function GetTextInKElementTextBox(pageContent) {
    var bodyText = "";
    $(pageContent).find(".k-element-box").each(function () {
        if ($(this).attr("temptype") == "Text") {
            bodyText = $(this).find(".k-element-text").text() + " ";

        }
    });
    if (bodyText != "" && bodyText.length > 50) {
        bodyText = bodyText.slice(0, 50);
    }
    return bodyText;
}
function CheckInKElementBox(pageContent, filter) {

    var isSeachTextFound = false;
    $(pageContent).find(".k-element-box").each(function () {
        if ($(this).text().toLowerCase().indexOf(filter) >= 0) {
            isSeachTextFound = true;

        }
        if ($(this).attr("temptype") == "Image") {
            if ($(this).find(".k-element-image").attr("src") != null && $(this).find(".k-element-image").attr("src") != "") {
                var filename = GetFileNameFromPath($(this).find(".k-element-image").attr("src"));
                if (filename != null && filename != "" && filename.indexOf(filter) >= 0) {
                    isSeachTextFound = true;
                }
            }
        }
        if ($(this).attr("temptype") == "Video") {
            if ($(this).find(".k-element-video").attr("src") != null && $(this).find(".k-element-video").attr("src") != "") {
                var filename = GetFileNameFromPath($(this).find(".k-element-video").attr("src"));
                if (filename != null && filename != "" && filename.indexOf(filter) >= 0) {
                    isSeachTextFound = true;
                }
            }
        }
        if ($(this).attr("temptype") == "TextAsset") {
            if ($(this).find(".k-element-textasset").attr("fsrc") != null && $(this).find(".k-element-textasset").attr("fsrc") != "") {
                var filename = GetFileNameFromPath($(this).find(".k-element-textasset").attr("fsrc"));
                if (filename != null && filename != "" && filename.indexOf(filter) >= 0) {
                    isSeachTextFound = true;
                }
                var filename = $(this).find(".k-element-textasset").attr("fname");
                if (filename != null && filename != "" && filename.indexOf(filter) >= 0) {
                    isSeachTextFound = true;
                }
            }
        }
        if ($(this).attr("temptype") == "Audio") {
            if ($(this).find(".k-element-audio").attr("fsrc") != null && $(this).find(".k-element-audio").attr("fsrc") != "") {
                var filename = GetFileNameFromPath($(this).find(".k-element-audio").attr("fsrc"));
                if (filename != null && filename != "" && filename.indexOf(filter) >= 0) {
                    isSeachTextFound = true;
                }
                var filename = $(this).find(".k-element-audio").attr("fname");
                if (filename != null && filename != "" && filename.indexOf(filter) >= 0) {
                    isSeachTextFound = true;
                }
            }
        }
    });
    return isSeachTextFound;
}
function GetFileNameFromPath(fname) {
    var res = fname.split("/");
    var fileNameWithoutExtension = "";
    if (res != undefined && res != null && res.length > 0) {
        for (var i = 0; i < fname.length; i++) {
            if (fname.indexOf(".") >= 0) {
                fileNameWithoutExtension = fname.slice(0, -4);
            }
        }
    }
    return fileNameWithoutExtension;
}
$(".loadSelectedPage").live("click", function () {
    var pageid = Number($(this).attr("data-pageid"));
    for (var i = 0; i < gPages.length; i++) {
        if (gPages[i].PageId == pageid) {
            //Hide If map is open - load selected page from map search.
            $("#mapcanvasContainer").hide();

            gPrevPageIdArray.push(gCurrPageObj.PageId);
            gCurrPageObj = GetPage(pageid)
            gNextPageId = gCurrPageObj.NextPageId;
            LoadPageContent(gCurrPageObj);

            //Anu 23-feb-2015 - check if Disable Next button called fun instead of inline code
            HandleNextLink(gCurrPageObj);
            //Anu 23-feb-2015 - Check if Disable prev button called func instead of inline code
            HandlePrevLink(gCurrPageObj);
        }
    }
});

$(".EditPage a").live("click", function () {
    pageid = Number($(this).attr("data-pageid"));
    caseid = gCaseId;
    $(".PreviewClose a").trigger("click");
    top.EditPageDetails(pageid, true, caseid, gPages);
});
$("#ipSearchBox").live("blur", function (e) {
    if (this.value === '') {
        $(this).css("width", "120px");
        $(this).removeClass("ipSearchTestEntered");
        $(this).addClass("ipSearchBoxDefault");
        $(".searchIcon").removeClass("seachIcondisplayblock");
        $(".searchIcon").addClass("seachIcondisplaynone");

    }
});

$("#ipSearchBox").live("focus", function (e) {
    $(this).css("width", "390px");
    $(this).css("border-color", "#00");
});

function ApplyAutoAdjustment() {
    $(".k-element-box[temptype='Text']").each(function () {
        AutoAdjustDownElements($(this))
    })

    $(".k-element-box[temptype='TextAsset']").each(function () {
        AutoAdjustDownElements($(this))
    });

    SetVideoHtUsingAspectRatio();
}

//Call this function when elements are loaded/rendered.
function SetVideoHtUsingAspectRatio() {
    $(".k-element-box[temptype='Video']").each(function () {
        var aspectratio = $(this).attr("aspect-ratio");
        if (aspectratio != undefined && aspectratio != "") {
            var currwdth = $(this).width();
            var currht = currwdth / Number(aspectratio);
            $(this).find(".k-element-video").css({ "height": currht });
        }
    });

    $(".k-element-box[temptype='TextAsset']").each(function () {
        var aspectratio = $(this).find(".textVideo").attr("aspect-ratio");
        if (aspectratio != undefined && aspectratio != "") {
            var currwdth = $(this).find(".textVideo").width();
            var currht = currwdth / Number(aspectratio);
            $(this).find(".textVideo").css({ "height": currht });
        }
    });
}

function AutoAdjustDownElements(_this) {
    /*var newHght = Number(_this.outerHeight() + _this.position().top);
    var hOfTxtEle = Number(Number(_this.attr("orig-ht")) + _this.position().top);
    var increasedHeight = Number(_this.outerHeight() - Number(_this.attr("orig-ht")));

    var newWidth = Number(_this.outerWidth() + _this.position().left);

    var returnHeight = 0;

    var closestContClass = ".column";
    if (_this.closest(".qtext").length > 0) {
        closestContClass = ".qtext";
    }
    _this.closest(closestContClass).find(".k-element-box").not(_this).each(function (i) {
            if ($(this).position().top > hOfTxtEle) {
            if (increasedHeight > 0) {
                var eletomovewidth = $(this).position().left + $(this).outerWidth();
                if ($(this).position().left < newWidth && eletomovewidth > _this.position().left) {
                    var newretht = $(this).position().top + increasedHeight;
                    $(this).css({ "top": newretht })

                    if (returnHeight < newretht) {
                        returnHeight = newretht + $(this).outerHeight();
                    }
                }
            }
        }
    });

    if (returnHeight > 0 && _this.closest(".column").outerHeight() < returnHeight) {
        _this.closest(".column").css({ "height": returnHeight });
    }*/
}


function setMaxHeightToContainer(_container) {
    var oh = _container.outerHeight();
    var cal_Ht = 0;
    _container.find(".k-element-box").each(function () {
        var eleht = $(this).position().top + $(this).outerHeight();
        if (cal_Ht < eleht ) {
            cal_Ht = eleht;
        }
    });

	if(navigator.userAgent.toLowerCase().indexOf('firefox') == -1)
	{
		if (oh < cal_Ht) {
			_container.css({ "height": cal_Ht + "px" })
		}
	}
	else
	{
		if (oh < cal_Ht && cal_Ht < screen.height) {
			_container.css({ "height": cal_Ht + "px" })
		}
		$(".pageWrapper").css("height",$(".column").height()+40)
	}
}

//Anu 12-feb-2015 - Droppable Component
function handleDroppableAndDraggableComp(pageToLoad) {
    if (pageToLoad.PageType == 'CEP') {
        $(".k-element-image[draggable='true']").closest(".k-element-box").each(function (e) {
            var cursrtype = $(this).find(".k-element-image").attr("cursor-type");
            if (cursrtype == undefined)
                cursrtype = 'default';

            $(this).draggable({
                cursor: cursrtype,
                containment: $('#contentContainer'),
                helper: function () {
                    //nav-24-march-2015-Clone draggable
                    var keepCopy = $(this).find(".k-element-image").attr("keepcopy");
                    if (keepCopy != undefined && (keepCopy == true || keepCopy == "true")) {
                        var eleclone = $(this).clone();
                        return eleclone.css("zIndex", parseInt(getMaxElementIndex()));
                    }
                    else {
                        return $(this).css("zIndex", parseInt(getMaxElementIndex()));
                    }
                },
                handle: ".k-element-image",
                start: function (event, ui) {
                    $(ui.helper).css("zIndex", parseInt(getMaxElementIndex()));
                    ui.helper.data('rejected', true);
                    ui.helper.data('original-position', ui.helper.offset());
                },
                revert: function (event, ui) {
                    $(this).data("draggable");
                    return !event;
                },
                stop: function (event, ui) {
                    if (ui.helper.data('rejected') === true) {
                        ui.helper.offset(ui.helper.data('original-position'));
                        $(ui.helper).css("z-Index", 4);
                        if (typeof FireCustomDragFunction == 'function') {
                            FireCustomDragFunction(this, event, ui);
                        }
                    }
                }
            }).css("cursor", cursrtype);
        });

        //Anu 23-feb-2015 - Droppable Component
        $(".k-element-box[temptype='Droppable']").each(function () {
            $(this).find(".k-element-droppable > p").remove();
            var imglst = $(".k-element-image[draggable='true'][droppable-target-id='" + $(this).find(".k-element-droppable").attr('id') + "']");
            var acceptbls = "", draglist = "";
            for (var k = 0; k < imglst.length; k++) {
                //".k-element-box[temptype='Image']:has('#k-element-image23')",
                acceptbls += ".k-element-box[temptype='Image']:has('#" + imglst[k].attributes.id.value + "')";
                draglist += imglst[k].attributes.id.value;
                if (k != (imglst.length - 1)) {
                    acceptbls += ", ";
                    draglist += ",";
                }
            }


            var isadvnce = ($(this).find(".k-element-droppable").attr("answers") == undefined || $(this).find(".k-element-droppable").attr("answers") == "") ? false : true;

            if (acceptbls == "" || isadvnce) {
                acceptbls = "*";
            }

            $(this).find(".k-element-droppable").attr("drag-list", draglist);

            $(this).droppable({
                accept: acceptbls,
                over: function (event, ui) {
                    toggletDroppableBackground(this);
                },
                out: function (event, ui) {
                    toggletDroppableBackground(this);
                    ui.helper.data('rejected', true);
                },
                drop: function (ev, ui) {
                    toggletDroppableBackground(this);
                    var eleDrag = ui.helper;
                    //Anu 3-march-2015 line up drag n drop items one after another on drop
                    var eleDropble = $(this).find(".k-element-droppable");
                    //naveen- change for accept only answers.
                    var isaoanswers = eleDropble.attr("AOAnswers");
                    if (isaoanswers != undefined && isaoanswers != "false" && (isaoanswers || isaoanswers == "true")) {
                        //var answers = eleDropble.attr('answers');
                        var answers = eleDropble.attr('drag-list');
                        //AR 28 April 2015 - Condition Updated to resolve check/uncheck issue
                        if (answers == undefined || answers == "" ) {
                            return typeof event == "undefined" ? !ev : !event;
                        }
                        else {
                            if (!(answers.indexOf(eleDrag.find(".k-element-image").attr('id')) > -1)) {
                                return typeof event == "undefined" ? !ev : !event;
                            }
                        }
                    }

                    var isadvanced = (eleDropble.attr("answers") == undefined || eleDropble.attr("answers") == "") ? false : true;
                    var keepCopy = eleDrag.find(".k-element-image").attr("keepcopy");

                    var isMultipleDropAllow = eleDropble.attr("dragelemtslimit") == "Multiple" ? true : false;
                    if (!isMultipleDropAllow && typeof eleDropble.attr("dropped-list") != "undefined" && eleDropble.attr("dropped-list") != "") {
                        //ui.draggable.animate(ui.draggable.data().origPosition, "fast");
                        return typeof event == "undefined" ? !ev : !event;
                    }
                    else {
                        if (keepCopy != undefined && (keepCopy == true || keepCopy == "true")) {
                            eleDrag = ui.helper.clone();
                            ui.helper.data('rejected', false);
                        }
                        else {
                            ui.draggable.data('rejected', false);
                        }

                        var eleDragId = eleDrag.find(".k-element-image").attr("id");

                        //AR 14 April 2015 - Accept all - Condition no longer required
                        if (isadvanced != undefined && (isadvanced == true || isadvanced == "true")) {
                            if (keepCopy != undefined && (keepCopy == true || keepCopy == "true")) {
                                var drplst = eleDropble.attr("dropped-list");
                                if (drplst != undefined && drplst != "") {
                                    if (drplst.indexOf(eleDragId) >= 0) {
                                        ui.helper.data('rejected', true);
                                        return;
                                    }
                                }
                            }
                        }
                        //Rahul 24March-2015 - added delete button on droppable image component

                        if (keepCopy != undefined && (keepCopy == true || keepCopy == "true")) {
                            eleDrag.addClass("dragclone")
                            eleDrag.find(".k-element-image").attr("droppableid", eleDropble.attr("id"))
                            //var eleDragBox = eleDrag.find(".k-element-image").closest(".k-element-box");
                        } else {
                            eleDrag.addClass("dragOriginal")
                            eleDrag.find(".k-element-image").attr("droppableid", eleDropble.attr("id"))
                            //eleDrag.draggable('disable');
                        }
                        if (eleDrag.find(".imageDelete").length == 0) {
                            eleDrag.append($("<div class='imageDelete'></div>"));
                            if(iPadClickStatus == "true")
                            {
                                eleDrag.find(".imageDelete").css({ "display": "inline" });
                            }
                        }

                        //end
                        if (keepCopy != undefined && (keepCopy == true || keepCopy == "true")) {
                            ui.helper.parent().append(eleDrag);
                        }

                        if (eleDropble.attr("arrange-vertically") == "true" || eleDropble.attr("arrange-vertically") == true) {
                            var nextDrgelemntTop = eleDropble.attr("next-dragelemt-top");
                            if (nextDrgelemntTop == undefined) {
                                eleDropble.attr("next-dragelemt-top", eleDrag.height() + 3);
                                eleDrag.css({ top: (Number($(this).css('top').replace("px", "")) + 3) + "px", left: (Number($(this).css('left').replace("px", "")) + 3) + "px" });
                            }
                            else {
                                var dropHt = $(this).height();
                                nextDrgelemntTop = Number(nextDrgelemntTop)
                                if (dropHt >= (nextDrgelemntTop + eleDrag.height())) {
                                    eleDrag.css({ top: (Number($(this).css('top').replace("px", "")) + nextDrgelemntTop + 3), left: (Number($(this).css('left').replace("px", "")) + 3) + "px" });
                                }
                                else {
                                    //alert("No space left");
                                }
                                eleDropble.attr("next-dragelemt-top", (nextDrgelemntTop + eleDrag.height() + 3));
                            }
                        }
                        //end
                        var temp = eleDropble.attr("drag-list");
                        if(temp != undefined && temp !="")
                        {
                        temp = temp.replace(eleDragId + ",", "").replace(eleDragId, "");
                        eleDropble.attr("drag-list", temp);

                        //AR 14 April 2015 - Accept all - Condition no longer required
                        /* if (isadvanced != undefined && (isadvanced == true || isadvanced == "true")) {
                             var drplst = eleDropble.attr("dropped-list");
                             if (drplst == undefined) drplst = "";
                             drplst = drplst + eleDragId + ",";
                             eleDropble.attr("dropped-list", drplst);
                         }
                         else {
                             if (temp == "") {
                                 //called func to show feedback
                                 droppableActionComplete(this);
                             }
                         } */

                        if (isadvanced == undefined || isadvanced == false || isadvanced == "false") {
                            if (temp == "") {
                                //called func to show feedback
                                droppableActionComplete(this);
                            }
                        }
					    }
						var drplst = eleDropble.attr("dropped-list");
						if (drplst == undefined) drplst = "";
						drplst = drplst + eleDragId + ",";
						eleDropble.attr("dropped-list", drplst);
                        if (typeof FireCustomFunction == 'function') {
                            FireCustomFunction(this, ev, ui);
                        }
                    }
                    var IsHideDragElmts = eleDropble.attr("IsHideDragElmts");
                    //AR 28 April 2015 - Condition Updated to resolve check/uncheck issue
                    if (IsHideDragElmts == true || IsHideDragElmts == "true") {
                        //ui.draggable.hide();
                        eleDrag.hide();
                    }

                }
            });
        });
    }
}

//Rahul-25-03-2015- check for dropped items
function checkDroppable(droppableObj) {
    droppableObj = $(droppableObj);
    var answerList = new Array();
    var droppedList = new Array();
    var answerlist = droppableObj.attr('answers');
    var droppedlist = droppableObj.attr('dropped-list');
    var matched = true;
    if (answerlist != undefined && answerlist != "") {
        if (droppedlist != undefined && droppedlist != "") {
            if (endswith(answerlist, ',')) {
                answerlist = answerlist.substring(0, answerlist.length - 1);
            }
            if (endswith(droppedlist, ',')) {
                droppedlist = droppedlist.substring(0, droppedlist.length - 1);
            }

            answerList = answerlist.split(",");
            droppedList = droppedlist.split(",");

            if (answerList.length == droppedList.length) {
                for (var j = 0; j < droppedList.length; j++) {
                    matched = false;
                    for (var k = 0; k < answerList.length; k++) {
                        if (droppedList[j] == answerList[k]) {
                            matched = true;
                            break;
                        }
                    }
                    if (matched == false) {
                        return matched;
                    }
                }
            }
            else {
                matched = false;
            }
        }
        else {
            matched = false;
        }
    }
    else {
        matched = true;
    }

    return matched;

}

function showInCorrect(idDroppable) {
    var objDroppable = $(idDroppable)
    var incorrectFeedbackRefId = objDroppable.attr('incorrect-fdbk-refid');
    if (objDroppable.attr('goto-nextpage') == "true") {
        gotoNextPageFlag = true;
        $("#NextPage").removeClass("disabled");
    }
    fshowRefQtipPopup(incorrectFeedbackRefId);

}
function showCorrect(idDroppable) {
    var objDroppable = $(idDroppable)
    var correctFeedbackRefId = objDroppable.attr('action-value');
    if (objDroppable.attr('goto-nextpage') == "true") {
        gotoNextPageFlag = true;
        $("#NextPage").removeClass("disabled");
    }
    fshowRefQtipPopup(correctFeedbackRefId)

}

function endswith(str, suffix) {
    return str.length >= suffix.length && str.substr(str.length - suffix.length) == suffix;
}

//Rahul 24March-2015 - delete button functionality of image component
$(".dragclone,.dragOriginal").live("mouseover", function () {
    if (iPadClickStatus != "true") {
        $(this).find(".imageDelete").css({ "display": "inline" });
    }
});
$(".dragclone,.dragOriginal").live("mouseout", function () {
    if (iPadClickStatus != "true") {
        $(this).find(".imageDelete").css({ "display": "none" });
    }
});

$(".imageDelete").live("click", function () {
    checkResetDropObjects($(this));
});
//end dragclone delete


function toggletDroppableBackground(_ths) {
    var objdroppable = $(_ths);
    var clr = objdroppable.find(".k-element-droppable").attr('ONDROP-background-color');
    if (clr != undefined && clr != '') {
        objdroppable.find(".k-element-droppable").attr('ONDROP-background-color', rgb2hex(objdroppable.css('background-color')).replace('#', ''));
        if (clr == 'transparent') {
            objdroppable.css("background-color", clr);
        }
        else
            objdroppable.css("background-color", "#" + clr);
    }
}

function getMaxElementIndex() {
    var greatestIndex = 3;
    $("#contentContainer").find(".column").each(function () {
        $(this).find('.k-element-box').each(function (index, obj) {
            if (index == 0) {
                greatestIndex = $(this).css('z-index');
            } else {
                var zIndex = parseInt($(this).css('z-index'));
                if (zIndex >= greatestIndex) {
                    greatestIndex = zIndex + 1;
                }
            }
        });
    });

    return greatestIndex;
}

//Anu 23-feb-2015 func to show feedback
function droppableActionComplete(_ths) {
    //Update and show score if droppable action complete.
    _ths = $(_ths);
    SetCumulativeAndPageScore(_ths);
    showSimScore(true);
    //
    var eleDrp = $(_ths).find('.k-element-droppable');
    var action_type = eleDrp.attr('action-type') == undefined ? "" : eleDrp.attr('action-type');
    var action_value = eleDrp.attr('action-value');
    var refId = eleDrp.attr('action-refid');
    var gotoNextPage = eleDrp.attr("goto-nextpage") == undefined ? "false" : eleDrp.attr("goto-nextpage");
    var spp = getParameterByName("SPP");
    if (action_type == 'POPUP' && action_value == refId) {
        if ((gotoNextPage == "true" || gotoNextPage == true) && (gNextPageId != undefined && gNextPageId != "") && (spp != undefined && (spp == false || spp == "false"))) {
            gotoNextPageFlag = true;
            $("#NextPage").removeClass("disabled");
        }
        fshowRefQtipPopup(refId);
    }
    else {
        if ((gotoNextPage == "true" || gotoNextPage == true) && (gNextPageId != undefined && gNextPageId != "") && (spp != undefined && (spp == false || spp == "false"))) {
            gotoNextPageFlag = true;
            $("#NextPage").removeClass("disabled").click();
        }
    }
}

function msieversion() {
    var ua = window.navigator.userAgent
    var msie = ua.indexOf("MSIE ")

    if (msie > 0)      // If Internet Explorer, return version number
        return parseInt(ua.substring(msie + 5, ua.indexOf(".", msie)))
    else                 // If another browser, return 0
        return 0

}

//Rahul 26March-2015 - Updated code for Reset and Delete Object
function resetDroppedItems() {
    var cloneObjects = $(".ContentArea").find(".dragclone");
    var originalObjects = $(".ContentArea").find(".dragOriginal");
    for (var k = 0; k < cloneObjects.length; k++) {
        checkResetDropObjects($(cloneObjects[k]));
    }
    for (var j = 0; j < originalObjects.length; j++) {
        checkResetDropObjects($(originalObjects[j]));
    }
}

function checkResetDropObjects(_ths) {
    var boxelm = $(_ths).closest(".k-element-box");
    var eleDragId = boxelm.find(".k-element-image").attr("id");
    var eleDropble = $("#" + boxelm.find(".k-element-image").attr("droppableid"));

    var drplst = eleDropble.attr("dropped-list");
    if (drplst == undefined) drplst = "";
    drplst = drplst.replace(eleDragId + ",", "").replace(eleDragId, "");
    eleDropble.attr("dropped-list", drplst);

    var drglst = eleDropble.attr("drag-list");
    if (drglst == undefined) drglst = "";
    drglst = drglst + eleDragId + ",";
    eleDropble.attr("drag-list", drglst);
    if (boxelm.hasClass("dragclone")) {
        boxelm.remove();
    } else {
        var OTop = boxelm.attr("originaltop");
        var OLeft = boxelm.attr("originalleft");
        boxelm.css({ 'top': OTop, 'left': OLeft });
        boxelm.find(".imageDelete").remove();
        boxelm.draggable('enable')
    }
}
//end

function ShowGlossary(glossaryPageId) {
    var tmphtmlContent = GetTemplateString(gPages[glossaryPageId], $("#Template_CEP").html());
    var find = 'ui-draggable';
    $.fancybox(tmphtmlContent.replace(new RegExp(find, 'g'), ''));
    InitializeComponents($('#fancybox-content'));
    removeUIObjects();
}

function ShowReference(glossaryPageId) {
    var tmphtmlContent = GetTemplateString(gPages[glossaryPageId], $("#Template_CEP").html());
    var find = 'ui-draggable';
    $.fancybox(tmphtmlContent.replace(new RegExp(find, 'g'), ''));

    InitializeComponents($('#fancybox-content'));
    removeUIObjects();
}

function InitializeComponents(contentArea) {
    contentArea.find(".k-element-video").each(function (index) {
        var wt = $(this).closest(".k-element-box").width();
        var ht = $(this).closest(".k-element-box").height();
        var fsrc = $(this).attr("fsrc");
        var ftype = $(this).attr("ftype");
        fLoadVideoJsPlayer($(this), undefined, { "src": fsrc, "vidtype": ftype, "wt": wt, "ht": ht });
    });

    contentArea.find(".k-element-textasset[fImgOrVideo='video']").each(function (index) {
        var wt = 120; // $(this).closest(".k-element-box").width();
        var ht = 100; // $(this).closest(".k-element-box").height();
        var fsrc = $(this).attr("fsrc");
        var ftype = $(this).attr("ftype");
        fLoadtextVideoJsPlayer($(this), undefined, { "src": fsrc, "vidtype": ftype, "wt": wt, "ht": ht });
    });

    //Rahul 12-jan-2015 - Audio Component
    contentArea.find(".k-element-box[temptype='Audio']").each(function () {
        var wt = $(this).closest(".k-element-box").width();
        var audWrapper = $(this).find(".k-element-audio");
        InitializeAudioJs(audWrapper, wt);
    });
    //Anu 14-apr-2015 txt fixed hgt issue sol


    //ApplyAutoAdjustment();

    //Set Height of container to maxheight. traverse throught container. In custom page it is column.
    contentArea.find(".column").each(function () {
        //setMaxHeightToContainer($(this));
    });
    contentArea.find(".colNum").html("");
}


//naveen-06-aprl-2015 show checklist feedback
function ShowCorrectIncorrectCheckItems(checklistid) {
    var selector = ".k-element-checklist";
    if (checklistid != undefined && checklistid != "")
        selector = checklistid = "#" + checklistid.replace("#", "");

    $(selector).find(".checkitem input:checked").each(function () {
        var iscorrect = $(this).attr("iscorrect");
        if (iscorrect == undefined) iscorrect = "Incorrect";
        if (iscorrect == "Correct") {
            $($(this).closest("tr").find("td")[0]).html("<div class='cchkitem'></div>")
        }
        else {
            $($(this).closest("tr").find("td")[0]).html("<div class='icchkitem'></div>")
        }
    })

    SetCorrectIncorrectItemStyle(checklistid)
}

function SetCorrectIncorrectItemStyle(checklistid) {
    var selector = ".k-element-checklist";
    if (checklistid != undefined && checklistid != "")
        selector = checklistid = "#" + checklistid.replace("#", "");

    $(selector).find(".checkitem input").each(function () {
        var iscorrect = $(this).attr("iscorrect");
        if (iscorrect == undefined) iscorrect = "Incorrect";
        if (iscorrect == "Correct") {
            $(this).closest("tr").css({ "font-weight": "bold" });
            $(this).closest("tr").find(".itemlabel").find("p").each(function () {
                $(this).getCKELastChild_temp().css({ "font-weight": "bold" })
            });
        }
        else {
            $(this).closest("tr").css({ "font-weight": "normal", "color": "#999999" });
            $(this).closest("tr").find(".itemlabel").find("p").each(function () {
                $(this).getCKELastChild_temp().css({ "font-weight": "normal", "color": "#999999" })
            });
        }
    });
}
//gp 28april 2015 added for assessment
function FindObjectIndexArray(arr, property, value) {
    var objIndex;
    for (var i = arr.length - 1; i >= 0; i--) {
        if (arr[i][property] == value) {
            objIndex = i;
        }
    }
    return objIndex;
}

function SetAssessmentResult(_ths) {
    gPollResult = [];

    _ths.find(".k-element-question").each(function () {

        var questionNo = $(this).find("td.qno").text();
        var objIndex = -1;
        var pollQuestion = FindObjectInArray(gAssessmentResult, "QNo", questionNo);
        if (pollQuestion == undefined || pollQuestion == null) {
            pollQuestion = {};
        }
        else {
            objIndex = FindObjectIndexArray(gAssessmentResult, "QNo", questionNo);
        }

        pollQuestion.correctFeedbackRefId = $(this).attr("action-refid-correct");
        pollQuestion.incorrectFeedbackRefId = $(this).attr("action-refid-incorrect");
        pollQuestion.Points = $(this).attr("points");
        if (gCurrPageObj.AssessmentAsSimulation != undefined && gCurrPageObj.AssessmentAsSimulation == true) {
            gTotalSimScore += Number($(this).attr("points"))
        }

        pollQuestion.QNo = $(this).find("td.qno").text();
        //gp 28april 2015 commented for assessment
        //if ($(this).find("td.qtextdata").find(".k-element-box-clone[temptype='Video']").length > 0) {
        //    $(this).find("td.qtextdata").find(".k-element-box-clone[temptype='Video']").remove();
        //}
        //if ($(this).find("td.qtextdata").find(".k-element-box-clone[temptype='Image']").length > 0) {
        //    $(this).find("td.qtextdata").find(".k-element-box-clone[temptype='Image']").remove();
        //}
        pollQuestion.QText = $(this).find("td.qtextdata").text();
        pollQuestion.Options = [];
        pollQuestion.SelectedOptions = "";
        pollQuestion.SelectedOptionsText = "";
        pollQuestion.SelectedOptionValue = 0;
        var optcounter = 0;
        var addComma = false;
        $(this).find("tr.optionrow").each(function () {
            optcounter++;
            var pollOption = {};
            // VinodBonde -- option id should be unique and not the counter. This will be required when we need randomization of options in output
            pollOption.OptNo = optcounter;
            pollOption.AssessmentValue = $(this).attr("assessmentvalue");
            pollOption.Feedback = $(this).attr("feedback");//Anu 21-apr-2015 asmnt feedback
            pollOption.OptionMarks = $(this).attr("optionmarks");
            //if ($(this).find("td.qoptdata").find(".k-element-box-clone[temptype='Video']").length > 0) {
            //    $(this).find("td.qoptdata").find(".k-element-box-clone[temptype='Video']").remove();
            //}
            //if ($(this).find("td.qoptdata").find(".k-element-box-clone[temptype='Image']").length > 0) {
            //    $(this).find("td.qoptdata").find(".k-element-box-clone[temptype='Image']").remove();
            //}
            pollOption.OptText = $.trim($(this).find("td.qoptdata").text());
            ////console.log("pollOption.OptText====" + pollOption.OptText);
            pollQuestion.Options.push(pollOption);
            if ($(this).hasClass("selected")) {
                pollQuestion.SelectedOptions += "," + optcounter;

                if (gCurrPageObj.AssessmentAsSimulation != undefined && gCurrPageObj.AssessmentAsSimulation == true) {
                    if (addComma)
                        pollQuestion.SelectedOptionsText += ",";
                    pollQuestion.SelectedOptionsText += " " + GetSelectedOptionText(pollOption.OptText);
                    pollQuestion.SelectedOptionValue += Number(GetSelectedOptionValue(pollOption.OptText));
                    if (pollOption.OptionMarks != undefined) {
                        //gSimScore += Number(pollOption.OptionMarks);
                        if (gSimScore.Parameters != undefined) {
                            for (var i = 0; i < gSimScore.Parameters.length; i++) {
                                var fvalue = pollOption.OptionMarks;
                                if (fvalue == undefined || fvalue == "")
                                    fvalue = 0;
                                else
                                    fvalue = Number(fvalue);
                                gSimScore.Parameters[i].Score += fvalue;
                                gPageScore.Parameters[i].Score += fvalue;
                            }
                        }
                    }
                }
                addComma = true;

            }
        });
        if (pollQuestion.SelectedOptions != "") {
            pollQuestion.SelectedOptions += ",";
        }
        pollQuestion.SelectedOptions = pollQuestion.SelectedOptions.replace(/\,,/g, "");

        if (objIndex == -1) {
            gAssessmentResult.push(pollQuestion);
        }
        else {
            //gAssessmentResult.remove(objIndex)
            gAssessmentResult.splice(objIndex, 1, pollQuestion)
        }

    });

}
//gp 15 april added for assessment
function DisplayPreviousQuestion(index) {
    var bandContainer = $(".ContentArea").find(".TbodyText");
    bandContainer.find(".questionBand").hide();
    var i = 0;
    bandContainer.find(".questionBand").each(function () {
        if (i == index) {
            $(this).show();
            $(this).find("#btnPreviousQuestion").attr("onclick", "");
            if (i == 0) {
                $(this).find("#btnPreviousQuestion").attr("disabled", disabled);
            }
            else {
                $(this).find("#btnPreviousQuestion").attr("onclick", "DisplayPreviousQuestion(" + (i - 1) + ")");
            }
        }

        i++;
    })
}
//gp 28april 2015 added for assessment
function GetSelectedOptionText(optText) {
    var optionText = (optText).split("[")[0];
    return $.trim(optionText);
}
//gp 28april 2015 added for assessment
function GetSelectedOptionValue(optText) {
    var optionValue = (optText).split("[")[1].split("$")[1].split("]")[0];
    return optionValue;
}
//gp 28april 2015 added for assessment
function GetSummary() {
    var summaryString = ""
    var totalValue = 0;
    for (i = 0; i < gAssessmentResult.length; i++) {
        var assessmentQuestion = gAssessmentResult[i];
        var assessmentValue = "";
        if (assessmentQuestion.SelectedOptionValue != undefined && assessmentQuestion.SelectedOptionValue != null) {
            assessmentValue = "$" + assessmentQuestion.SelectedOptionValue;
            totalValue += assessmentQuestion.SelectedOptionValue;
        }
        summaryString += "<tr><td>" + assessmentQuestion.SelectedOptionsText + "</td><td>" + assessmentValue + "</td></tr>"
    }
    summaryString = "<table>" + summaryString + "</table>";
    if (summaryString != "") {
        var summaryTitle = "<div><b>Shopping cart</b><br></div>"
        summaryString = "<div class='summaryDiv'><p>" + summaryTitle + "</p>" + summaryString + "<div class='totalDiv'> Total price : $" + totalValue + "</div></div>"
    }
    return summaryString;
}
//gp 15 april changed for assessment
//AR 19 May 2015 - To show instruction one by one
function saveAssessmentLocal(_this, oneByOneQuestions, questionIndex, showSummary, oneByOneInstruction) {
    //band context
    var _ths = $(_this);
    if (oneByOneQuestions) {
        var bandDiv = _ths.closest(".band");

        //validation
        if (bandDiv.find("tr.optionrow.selected").length < 1) {
            //do nothing.
            fshowMessagePopup('<div style="font-size:16px;font-family:arial narrow;color:#333;padding:10px">Please select the option first.</div>', '<p>Feedback</p>', false);
        }
        else {
            //Save data - passed band context
            SetAssessmentResult(bandDiv);

            //before navigation save response of curr band data
            var nextBand = bandDiv.next('.questionBand');
            var previousBand = nextBand.prev('.questionBand');
            if (previousBand.length > 0 && questionIndex >= 0) {
                nextBand.find("#btnPreviousQuestion").removeAttr("disabled")
                nextBand.find("#btnPreviousQuestion").attr("onclick", "DisplayPreviousQuestion(" + (questionIndex) + ")");
            }

            if (nextBand.length > 0) {
                //Aftermath
                bandDiv.hide();
                nextBand.show();
                //AR 19 May 2015 - To show instruction one by one
                if (oneByOneInstruction) {

                    var heading = "Instructions";
                    quesInstruction = nextBand.find(".k-element-question").attr("questioninstruction");

                    if (quesInstruction != undefined) {
                        $(".TSideBar").find(".quesionInstruction").remove();

                        //AR NOTE:This is a temporary popup - Will need to create a functionality like "Edit page load popup"
                        var refText;;
                        refText = "<div style='display:none'><div id='instructionDiv' style='width:493px;height:325px;'><span style='font-size:20px;padding:15px;'><span style='font-family:arial narrow;'><span style='color:#333;'><b>" + questionShortTitles[questionIndex] + "</b></span></span></span><p></p><br/><p style='padding:15px;'><span style='font-size:16px;'><span style='font-family:arial narrow;'><span style='color:#333;'>" + quesInstruction + "</span></span></span></p><div class='k-element-box' temptype='Button' style='z-index: 2; position: absolute; left: 386px; top: 289px; padding: 3px; border-radius: 5px; width: 71px; height: 22px; border-color: rgb(0, 0, 0); border-width: 0px; opacity: 1; background-color: rgb(20, 189, 212);' sizeprop='FTC' defaultvisibility='Visible'><div class='k-element-button div-edit-properties' contenteditable='false' id='instructionButton' onclick='$.fancybox.close();' btn-type='ELLiP' image-avail='false' img-dname='' action-type='SCRIPT' action-value=''><img class='lblImg dis-none'><span class='lbl'><p><strong><span style='font-size:16px;'><span style='font-family:arial narrow;'><span style='color:#333;'>&nbsp; &nbsp;Next&#8203;</span></span></span></strong></p></span></div></div></div></div>";

                        $(".TSideBar").append(refText);
                        $.fancybox({
                            content: $('#instructionDiv'),
                            modal: true
                        });
                    }
                }
                else {
                    DisplayQuestionInstruction(nextBand);
                }
                if (showSummary == true) {
                    var summaryDiv = GetSummary();
                    nextBand.closest(".TbodyText").find(".summaryDiv").remove();
                    nextBand.closest(".TbodyText").append(summaryDiv);
                }


            }
            else {
                //show assessment scorecard
                //parent class -> .TbodyText

                //gp commented following to set assessment result after each question
                //_ths.closest(".questionBand").parent().find(".questionBand").each(function () {
                //    SetAssessmentResult($(this));
                //})

                $(".TbodyText").find(".summaryDiv").remove();
                _ths.closest(".questionBand").parent().find(".band").each(function () {
                    $(this).hide();
                })
                _ths.hide();
                $(".band:first-child").show()
                $("#k-element-text2665").closest(".k-element-box").hide();
                $("#k-element-text2666").closest(".k-element-box").show();
                ShowAssessmentScorecard(_ths.closest(".questionBand").parent());
                //ShowAssessmentScorecard(bandDiv.parent());
                //bandDiv.hide();
            }
        }
    }
    else {
        $(".TSideBar").empty();
        $(".TSideBar").hide();
        _ths.parent().find(".questionBand").each(function () {
            SetAssessmentResult($(this));
        })
        _ths.parent().find(".band").each(function () {
            $(this).hide();
        })
        _ths.hide();
        ShowAssessmentScorecard(_ths.parent());
    }
}
//gp 28april 2015 added for assessment
function DisplayQuestionInstruction(_ths) {
    quesInstruction = _ths.find(".k-element-question").attr("questioninstruction");
    if (quesInstruction != undefined) {
        var quesI = "<div class='quesionInstruction'>" + quesInstruction + "</div>";
        $(".TSideBar").find(".quesionInstruction").remove();
        $(".TSideBar").append(quesI);
    }
    //align footer div
    var top = _ths.css("top").slice(0, -2);
    var height = _ths.outerHeight();
    if (top != undefined && height != undefined) {
        top = Number(height) + Number(top);
        $(".ContentArea").find(".assessmentFooter").css({ "top": top + "px" });
    }
}

//gp 28 april added for saving single question answer
function SaveAssessmentAnswer(_this, questionIndex, ShowSimulationSummary) {
    //band context
    var _ths = $(_this);

    var bandDiv = _ths.closest(".band");

    //validation
    //if (bandDiv.find("tr.optionrow.selected").length < 1) {
    //do nothing.
    //    fshowMessagePopup('<div style="font-size:16px;font-family:arial;color:#333;padding:10px">Please select the option first.</div>', '<p>Feedback</p>');
    //}
    //else {
    //Save data - passed band context
    SetAssessmentResult(bandDiv);
    //bandDiv.find(".btnAssessmentNext").removeAttr("disabled");
    if (ShowSimulationSummary == true) {
        var summaryDiv = GetSummary();
        bandDiv.closest(".TbodyText").find(".summaryDiv").remove();
        bandDiv.closest(".TbodyText").append(summaryDiv);
    }
    //}

}
//gp 28april 2015 added for assessment
function AssessmentNextQuestion(_this, questionIndex, ShowSimulationSummary) {

    //band context
    var _ths = $(_this);
    var bandDiv = _ths.closest(".band");

    //validation
    // if (bandDiv.find("tr.optionrow.selected").length < 1) {
    //do nothing.
    //     fshowMessagePopup('<div style="font-size:16px;font-family:arial;color:#333;padding:10px">Please select the option first.</div>', '<p>Feedback</p>');
    // }
    // else {

    var nextBand = bandDiv.next('.band');
    var previousBand = nextBand.prev('.questionBand');
    if (previousBand.length > 0 && questionIndex >= 0) {
        nextBand.find("#btnPreviousQuestion").removeAttr("disabled")
        nextBand.find("#btnPreviousQuestion").attr("onclick", "DisplayPreviousQuestion(" + (questionIndex) + ")");
    }

    if (nextBand.length > 0 && !nextBand.hasClass("assessmentFooter")) {
        //Aftermath
        bandDiv.hide();
        nextBand.show();
        DisplayQuestionInstruction(nextBand);
        if (ShowSimulationSummary == true) {
            var summaryDiv = GetSummary();
            nextBand.closest(".TbodyText").find(".summaryDiv").remove();
            nextBand.closest(".TbodyText").append(summaryDiv);
        }
    }
    else if (nextBand.hasClass("assessmentFooter")) {
        $(".TbodyText").find(".summaryDiv").remove();
        $(".TSideBar").empty();
        $(".TSideBar").hide();
        _ths.closest(".questionBand").parent().find(".band").each(function () {
            $(this).hide();
        })
        _ths.hide();
        ShowAssessmentScorecard(_ths.closest(".questionBand").parent());
    }
    // }
}


function ShowAssessmentScorecard(_parentOfQueDivs) {

    if (gCurrPageObj.ShowScorecard) {
        var questionPositionX = 50; var questionPositionY = 100;  //gp 16 april 2015 changed to  set default value for question positions
        if (gCurrPageObj.QuestionPositionX != undefined && gCurrPageObj.QuestionPositionX != null && gCurrPageObj.QuestionPositionX != "") {
            questionPositionX = gCurrPageObj.QuestionPositionX;
        }
        if (gCurrPageObj.QuestionPositionY != undefined && gCurrPageObj.QuestionPositionY != null && gCurrPageObj.QuestionPositionY != "") {
            questionPositionX = gCurrPageObj.QuestionPositionY;
        }
        var ptsObtn = 0, ptsTotal = 0, styles = "position:absolute;left:" + questionPositionX + "px;top:" + questionPositionY + "px";
        //var resultString = "<div class='band' style='height:380px;overflow:auto;width:890px;position:absolute;left:" + questionPositionX + "px;top:" + (Number(questionPositionY) + 100) + "px'>";
        var resultString = "<div class='band assessmentBand' style='z-index:1;height:370px;overflow:auto;width:869px;position:absolute;left:" + questionPositionX + "px;'>";

        var compName = "";
        var totalCost = "";

        if (baseUnitName && baseUnitName != undefined) {
            compName = baseUnitName;
        }
        if (totalValue && totalValue != undefined) {
            totalCost = totalValue;
        }
        //AR 19 May 2015 - Show feedback in a popup {build my dell format}
        if (gCurrPageObj.ShowFeedbackPopup) {
            //AR NOTE:This is a temporary popup in table format - Will need to create a functionality like edit summary

            resultString += "<div style='display:none;index:1;height:600px;max-height:600px;width:869px;overflow:hidden'><div class='AssessmentDiv' style='z-index:1;height:600px;max-height:600px;width:869px;overflow:hidden'><div><span style='font-size:18px;'><span style='font-family:arial narrow;'><span style='color:#000;'>&nbsp;<b>Review Summary</b></span></span></span></div><div><span style='font-size:16px;'><span style='font-family:arial narrow;'><span style='color:#000;'>&nbsp;<b>" + compName + "</b><br/>&nbsp;Total cost: $" + totalCost + "</span></span></span></div><div><span style='font-size:16px;'><span style='font-family:arial narrow;'><span style='color:#000;'>&nbsp;Please Take a Moment to Review.</span></span></span></div><div style='background-color:#FFF;height:1px;'></div><div style='background-color:#999;height:1px;'></div><div style='background-color:#FFF;height:1px;'></div><div style='background-color:#999;'><span style='font-size:16px;'><span style='font-family:arial narrow;'><span style='color:#FFF;'>&nbsp;Review Your Choices</span></span></span></div><div style='width:860px;height:375px;overflow:auto;'><table style='width:100%;'><tr><td style='width:22%'></td><td></td></tr>"
            for (var incr = 0; incr < gAssessmentResult.length; incr++) {
                //  resultString += "<tr bgcolor='#A4A4A4'><td>" + gAssessmentResult[incr].QText + "</td>";

                var arrOpts = gAssessmentResult[incr].Options;
                if (arrOpts.length > 0) {
                    var optString = "", isCorrFdbk = true, correctAnswerStr = "", yourSelectionStr = "", yourSelectionFeedback = '';
                    var queFeed = ""
                    for (iOpt = 0; iOpt < arrOpts.length; iOpt++) {
                        if (IsElementExistInStr(gAssessmentResult[incr].SelectedOptions, iOpt + 1 + "")) {
                            if (arrOpts[iOpt].AssessmentValue == "Correct") {
                                if (yourSelectionStr == "") {
                                    yourSelectionStr += arrOpts[iOpt].OptText;
                                } else {
                                    yourSelectionStr += "<br/>" + arrOpts[iOpt].OptText;
                                }
                            }
                            else {
                                isCorrFdbk = false;
                                if (yourSelectionStr == "") {
                                    yourSelectionStr += arrOpts[iOpt].OptText;
                                } else {
                                    yourSelectionStr += "<br/>" + arrOpts[iOpt].OptText;
                                }
                            }

                            if (yourSelectionFeedback == "") {
                                yourSelectionFeedback += arrOpts[iOpt].Feedback;
                            } else {
                                yourSelectionFeedback += "<br/>" + arrOpts[iOpt].Feedback;
                            }
                        }
                    }
                    if (yourSelectionStr != "") {
                        resultString += "<tr bgcolor='#E5E4E2'><td style='padding:5px'><span style='font-size:16px;'><span style='font-family:arial narrow;'><b>" + questionShortTitles[incr] + "</b></span></span></td>";
                        optString += "<td style='padding:5px'><span style='font-size:16px;'><span style='font-family:arial narrow;'>" + yourSelectionStr + "</span></td></tr><tr><td></td><td style='padding:5px'><span style='font-size:16px;'><span style='font-family:arial narrow;'>" + yourSelectionFeedback + "</span></td></tr>";
                    }
                }
                resultString += optString;
            }

            resultString += "</table></div><div class='k-element-box' temptype='Button' style='z-index: 2; position: relative; left: 768px;top:5px; padding: 3px; border-radius: 5px; width: 80px; height: 24px; border-color: rgb(0, 0, 0); border-width: 0px; opacity: 1; background-color: rgb(20, 189, 212);display:table;' sizeprop='FTC' defaultvisibility='Visible'><div class='k-element-button div-edit-properties' contenteditable='false' id='k-summaryButton' style='padding:0px;width: 80px; height: 24px;display: table-cell;text-align: center;vertical-align: middle;float: none;padding:0px;' onclick='$.fancybox.close();GotoPage(6);' btn-type='ELLiP' image-avail='false' img-dname='' action-type='SCRIPT' action-value=''><img class='lblImg dis-none'><span class='lbl' style='float:none;'><p><strong><span style='font-size:16px;'><span style='font-family:arial narrow;'><span style='color:#333;'>Next</span></span></span></strong></p></span></div></div></div></div></div>";

            _parentOfQueDivs.append(resultString);
            $.fancybox({
                content: $('.AssessmentDiv'),
                modal: true,
                'width': 869,
                'height': "auto",
                'autoDimensions': true,
                'scrolling': 'no'
            });

        } else {
            for (var incr = 0; incr < gAssessmentResult.length; incr++) {
                var assqno = gAssessmentResult[incr].QNo;
                if (gCurrPageObj.HideQuestionNumber != undefined && gCurrPageObj.HideQuestionNumber == true) {
                    assqno = "";
                }
                resultString += "<div class='AssessmentDiv' style='z-index:1;'><div class='QueAssess'>" + assqno + " " + gAssessmentResult[incr].QText + "</div>";

                var arrOpts = gAssessmentResult[incr].Options;
                if (arrOpts.length > 0) {
                    var optString = "<div>", isCorrFdbk = true, correctAnswerStr = "", yourSelectionStr = "", yourSelectionFeedback = '';
                    for (iOpt = 0; iOpt < arrOpts.length; iOpt++) {
                        yourSelectionFeedback = arrOpts[iOpt].Feedback;
                        var studUserResp = "";
                        if (IsElementExistInStr(gAssessmentResult[incr].SelectedOptions, iOpt + 1 + "")) {
                            if (arrOpts[iOpt].AssessmentValue == "Correct") {
                                studUserResp = "<div class='cchkitem fl_l'></div>";
                                yourSelectionStr += iOpt + 1;
                            }
                            else {
                                isCorrFdbk = false;
                                studUserResp = "<div class='icchkitem fl_l'></div>";
                                yourSelectionStr += iOpt + 1;
                            }
                        }
                            //gp 16 april 2015 changed if all correct options are not selected do not give the points and show incorrect feedback
                        else if (arrOpts[iOpt].AssessmentValue == "Correct") {
                            isCorrFdbk = false;
                            studUserResp = "<div class='icchkitem fl_l'></div>";
                            yourSelectionStr += iOpt + 1;
                        }
                        else {
                            studUserResp = "<div class='echkitem fl_l'></div>";
                            yourSelectionStr += iOpt + 1;
                        }
                        var studChk = arrOpts[iOpt].AssessmentValue == "Correct" ? "<div class='cchkitem fl_l'></div>" : "<div class='echkitem fl_l'></div>";
                        if (arrOpts[iOpt].AssessmentValue == "Correct") {
                            correctAnswerStr += (iOpt + 1) + ",";
                        }
                        //removed check boxes
                        studUserResp = "<div class='echkitem fl_l'>" + (iOpt + 1) + ".</div>";
                        studChk = "";
                        optString += "<div class='OpAssess clearfix'>" + studUserResp + " " + studChk + "<div class='OpTxt fl_l'>" + arrOpts[iOpt].OptText + "</div></div>";
                    }
                    optString += "</div>";
                    // Add correct feedback and incorrect feedback
                    var queFeed = "", queFeedPopupId;
                    if (isCorrFdbk) {
                        queFeedPopupId = gAssessmentResult[incr].correctFeedbackRefId;
                        ptsObtn += Number(gAssessmentResult[incr].Points);
                    } else {
                        queFeedPopupId = gAssessmentResult[incr].incorrectFeedbackRefId;
                    }
                    ptsTotal += Number(gAssessmentResult[incr].Points);
                    if (gCurrPageObj.References == "[]") {
                        // get the data from pageIdReferences.js synchronously
                        gCurrPageObj.References = getDataFromJsFile(gCurrPageObj.PageId + "References.js");
                    }
                    if (gCurrPageObj.References != undefined && gCurrPageObj.References != null && gCurrPageObj.References.length > 0) {
                        for (var i = 0; i <= gCurrPageObj.References.length - 1; i++) {
                            if (queFeedPopupId == gCurrPageObj.References[i].RefId) {
                                var refText = "<div>" + gCurrPageObj.References[i].PopupText + "</div>";
                                var refContent = $(refText);
                                removeUnwantedDivs(refContent);
                                if ($(gCurrPageObj.References[i].PopupText).find(".column").length > 0) {
                                    queFeed = refContent.text();
                                } else {
                                    queFeed = refContent.text();
                                }
                            }
                        }
                    }
                    optString += "<div class='FeedbackDiv'> Your Selection: " + GetTrimmedStr(gAssessmentResult[incr].SelectedOptions) + "</div>";
                    optString += "<div class='FeedbackDiv'> Correct Answer: " + GetTrimmedStr(correctAnswerStr) + "</div>";
                    optString += "<div class='FeedbackDiv'> Feedback: " + queFeed + "</div>";
                    //Anu 21-apr-2015 show feedback for assmnt
                    if (gCurrPageObj.AssessmentAsSimulation != undefined && gCurrPageObj.AssessmentAsSimulation == true) {
                        if (yourSelectionFeedback != undefined && yourSelectionFeedback != '')
                            optString += "<div class='FeedbackDiv'> Feedback for your Selection: " + yourSelectionFeedback + "</div>";
                    }
                }
                resultString += optString + "</div>";
            }
            resultString += "</div>";

            //scoresheet points
            var showSCSummary = false;
            if (gCurrPageObj.ShowScorecardSummary != undefined && gCurrPageObj.ShowScorecardSummary == true) {
                resultString = ShowScoreSheetTable(ptsObtn, ptsTotal, styles, gCurrPageObj) + resultString;
            }

            _parentOfQueDivs.append(resultString);
            if (_parentOfQueDivs.find(".ScoreBoard").length > 0) {
                var sbheight = _parentOfQueDivs.find(".ScoreBoard").outerHeight();
                var sbtop = _parentOfQueDivs.find(".ScoreBoard").position().top;
                if (sbtop == undefined && gCurrPageObj.ScorecardTop != undefined && gCurrPageObj.ScorecardTop != "") {
                    sbtop = gCurrPageObj.ScorecardTop;
                }
                _parentOfQueDivs.find(".assessmentBand").css("top", sbheight + sbtop + 10 + "px");
            }

            //gp 15 april changed for assessment
            if (gCurrPageObj.ShowFeedbackOneByOne) {
                var assessmentDivs = _parentOfQueDivs.find(".AssessmentDiv").hide();
                if (assessmentDivs.length > 0) {
                    var parentDiv = _parentOfQueDivs.find(".AssessmentDiv:first").parent();
                    _parentOfQueDivs.find(".AssessmentDiv").hide();
                    parentDiv.append("<br/><input type='button' id='btnPrevFeedback' value='Previous feedback'  disabled='disabled'>" + "     " +
	                "<input type='button' id='btnNextFeedback' value='Next feedback' onclick='DisplayNextFeedBack(1)'>")
                    DisplayNextFeedBack(0)
                }

            } // else closing
        }

        //For Scorm review mode
        if (typeof fSetScoreForReviewMode == 'function') {
                fSetScoreForReviewMode();
        }
        //post quiz tracking data to server
        var pdata = {}
        pdata.QuizScore = ptsObtn;
        //Result string is no longer required as learner cannot navigate back and forth
        //pdata.scorecard = resultString;
        pdata.QuizTotalScore = ptsTotal;
        SetScoreInTrackingData(true, pdata);
    }
    fUpdateAttemptDetails();
}
//gp 15 april added for assessment
function DisplayNextFeedBack(displayIndex) {
    var contentArea = $(".ContentArea");
    var assessmentDivs = contentArea.find(".AssessmentDiv");
    contentArea.find(".AssessmentDiv").hide();
    var i = 0;
    assessmentDivs.each(function () {
        if (i == displayIndex) {
            $(this).show();
        }
        i++;
    });
    var nextQuestionIndex = displayIndex + 1;
    var previousQuestionIndex = displayIndex - 1;
    $("#btnNextFeedback").removeAttr('onclick');
    $("#btnPrevFeedback").removeAttr('onclick');
    if (nextQuestionIndex < assessmentDivs.length) {
        $("#btnNextFeedback").removeAttr('disabled');
        $("#btnNextFeedback").attr('onclick', 'DisplayNextFeedBack(' + nextQuestionIndex + ')')
    }
    else {
        $("#btnNextFeedback").attr('disabled', 'disabled');
    }
    if (previousQuestionIndex >= 0) {
        $("#btnPrevFeedback").removeAttr('disabled');
        $("#btnPrevFeedback").attr('onclick', 'DisplayPreviousFeedBack(' + previousQuestionIndex + ')')
    }
    else {
        $("#btnPrevFeedback").attr('disabled', 'disabled');
    }

}
//gp 15 april added for assessment
function DisplayPreviousFeedBack(displayIndex) {
    var contentArea = $(".ContentArea");
    var assessmentDivs = contentArea.find(".AssessmentDiv");
    contentArea.find(".AssessmentDiv").hide();
    var i = 0;
    assessmentDivs.each(function () {
        if (i == displayIndex) {
            $(this).show();
        }
        i++;
    });
    var nextQuestionIndex = displayIndex + 1;
    var previousQuestionIndex = displayIndex - 1;
    $("#btnNextFeedback").removeAttr('onclick');
    $("#btnPrevFeedback").removeAttr('onclick');
    if (nextQuestionIndex < assessmentDivs.length) {
        $("#btnNextFeedback").removeAttr('disabled');
        $("#btnNextFeedback").attr('onclick', 'DisplayNextFeedBack(' + nextQuestionIndex + ')')
    }
    else {
        $("#btnNextFeedback").attr('disabled', 'disabled');
    }
    if (previousQuestionIndex >= 0) {
        $("#btnPrevFeedback").removeAttr('disabled');
        $("#btnPrevFeedback").attr('onclick', 'DisplayPreviousFeedBack(' + previousQuestionIndex + ')')
    }
    else {
        $("#btnPrevFeedback").attr('disabled', 'disabled');
    }

}
function ShowScoreSheetTable(userQzScore, totalQzScore, styles, gCurrPageObj) {
    var stop = "90";
    var sleft = "387";
    var sbgcolor = "#000000";
    //gp 28april 2015 added for assessment
    if (gCurrPageObj.ScorecardTop != undefined && gCurrPageObj.ScorecardTop != "") {
        stop = gCurrPageObj.ScorecardTop;
    }
    if (gCurrPageObj.ScorecardLeft != undefined && gCurrPageObj.ScorecardLeft != "") {
        sleft = gCurrPageObj.ScorecardLeft;
    }
    if (gCurrPageObj.ScorecardBackground != undefined && gCurrPageObj.ScorecardBackground != "") {
        sbgcolor = "#" + gCurrPageObj.ScorecardBackground;
    }

    var pctQzScore = (userQzScore / totalQzScore) * 100;
    var objSimScore = GetSimScoreDetail();
    //gp 16 april 2015
    avgScore = 0;
    if (totalQzScore > 0 && Number(objSimScore.TotalSimScore) > 0) {
        avgScore = (Number(objSimScore.PctSimScore) + Number(pctQzScore)) / 2
    }
    else if (totalQzScore > 0) {
        avgScore = Number(pctQzScore);
    }
    else if (Number(objSimScore.TotalSimScore) > 0) {
        avgScore = Number(objSimScore.PctSimScore)
    }
    avgScore = avgScore.toFixed(2);
    var str_SimScore = "";
    if (objSimScore.TotalSimScore != "") {
        str_SimScore = objSimScore.UserSimScore + "/" + objSimScore.TotalSimScore + "(" + Number(objSimScore.PctSimScore).toFixed(2) + "%" + ")";;
    }
    else {
        str_SimScore = objSimScore.UserSimScore;
    }

    var str_qizScore = "";
    if (totalQzScore != "") {
        str_qizScore = userQzScore + "/" + totalQzScore + "(" + Number(pctQzScore).toFixed(2) + "%" + ")";;
    }
    else {
        str_qizScore = userQzScore;
    }


    styles += ";position: absolute;  left: " + sleft + "px;  top: " + stop + "px;background-color:transparent;"
    var scoreComponentHtml = "";    //later on get template TODO: define template somewhere else
    //gp 15 april added for assessment
    var scoreCardTitle = "Score Summary";
    var scoreCardSummary = "";
    if (gCurrPageObj.ScoreCardTitle != undefined && gCurrPageObj.ScoreCardTitle != "") {
        scoreCardTitle = gCurrPageObj.ScoreCardTitle
    }
    if (gCurrPageObj.ScoreCardSummary != undefined && gCurrPageObj.ScoreCardSummary != "") {
        scoreCardSummary = gCurrPageObj.ScoreCardSummary
    }
    scoreComponentHtml = '<div id="ScoreBoard" class="band ScoreBoard  " style="' + styles + ';">';
    scoreComponentHtml += '<div class="clearfix"><div class="fl_l sbLbl" style="font-style: italic;    font-weight: bold;  width: 200px;"><span style="font-size:24px;"><span style="font-family:times new roman;">' + scoreCardTitle + '</span></span></div></div>';
    scoreComponentHtml += '<div class="clearfix"><div class="fl_l" style="width:200px">' + scoreCardSummary + '</div></div>';
    //gp 16 april 2015
    if (str_SimScore != "") {
        scoreComponentHtml += '<div class="clearfix"><div class="fl_l sbLbl">Sim Score:</div><div class="fl_l">' + str_SimScore + '</div></div>';
    }
    if (str_qizScore != "") {
        scoreComponentHtml += '<div class="clearfix"><div class="fl_l sbLbl">Quiz Score:</div><div class="fl_l">' + str_qizScore + '</div></div>';
    }
    scoreComponentHtml += '<div class="clearfix"><div class="fl_l sbLbl">Total Score:</div><div class="fl_l">' + avgScore + '%</div></div>';
    scoreComponentHtml += '</div>';

    gRMAttemptData.Score = avgScore;

    if ((gPackageType == 'SCORM 1.2' || gPackageType == 'SCORM 2004')) {
        if(!(lms_mode != undefined && lms_mode == "review")){
            setScore(avgScore + "");
            complete();
        }
    }
    $("#k-element-text2626").closest(".k-element-box").hide();
    //$("#k-element-text2640").closest(".k-element-box").show();
    return scoreComponentHtml;
}

function GetSumOfSimScore() {
    var sumsimscore = 0
    if (gRMAttemptData.TrackingData != undefined) {
        if (gRMAttemptData.TrackingData.length > 0) {
            for (var i = 0; i < gRMAttemptData.TrackingData.length; i++) {
                var trackdataObj = gRMAttemptData.TrackingData[i];
                if (trackdataObj != undefined) {
                    if (trackdataObj.SimScore != undefined && trackdataObj.SimScore != "") {
                        sumsimscore = sumsimscore + Number(trackdataObj.SimScore);
                    }
                }
            }
        }
    }

    return sumsimscore;
}

function IsElementExistInStr(sourceStr, elem) {
    var s = sourceStr;
    var match = s.split(',');
    var iselemFound = false;
    for (var a in match) {
        if (elem == match[a]) {
            iselemFound = true;
            break;
        }
    }
    return iselemFound;
}

//trackingdata should be string i.e. if it is json object please use JSON.stringify before pass to function.
//pageid if not passed it will post for current page. default will be async call
function postpagetrackingdata(trackingdata, pageid, isasync) {
    if (gRMID != undefined && gRMID != null && gRMID != "") {
        jsonObject = {};
        jsonObject.knowdTrackingData = trackingdata;
        jsonObject.ReleaseModuleId = gRMID;
        jsonObject.AccessUserId = gRMAttemptData.AccessUserId;
        jsonObject.AttemptId = gRMAttemptData.AttemptId;
        if (pageid == undefined || pageid == null) {
            jsonObject.KnowdId = gCurrPageObj.PageId;
            jsonObject.KnowdType = gCurrPageObj.PageType;
        }

        if (isasync != undefined && isasync != "")
            isasync = true;

        /*var servcUrl = knowdlBaseUrl + "/ReleaseInteraction/Process?command=postknowdtrackingdata";
        $.ajax({
            type: "POST",
            url: servcUrl,
            async: isasync,
            data: "jsonData=" + JSON.stringify(jsonObject),
            success: function (result) {
            },
            error: function (error) {
            }
        }); */
    }
}

//pageid if not passed it will get for current page.
//attempt id if passed will return tracking data specific to attempt or say current attempt.
function getpagetrackingdata(pageid, attemptid) {
    var resultdata = "";
    if (gRMID != undefined && gRMID != null && gRMID != "") {
        jsonObject = {};
        jsonObject.ReleaseModuleId = gRMID;
        jsonObject.AccessUserId = gRMAttemptData.AccessUserId;
        if (attemptid != undefined && attemptid == null && attemptid != "") {
            if (gRMAttemptData.AttemptId != undefined && gRMAttemptData.AttemptId == null && gRMAttemptData.AttemptId != "") {
                jsonObject.AttemptId = gRMAttemptData.AttemptId;
            }
            else {
                jsonObject.AttemptId = attemptid;
            }
        }
        if (pageid == undefined || pageid == null || pageid == "") {
            jsonObject.KnowdId = gCurrPageObj.PageId;
        }
       /* var servcUrl = knowdlBaseUrl + "/ReleaseInteraction/Process?command=getknowdtrackingdata";
        $.ajax({
            type: "POST",
            url: servcUrl,
            async: false,
            data: "jsonData=" + JSON.stringify(jsonObject),
            success: function (result) {
                resultdata = result;
            },
            error: function (error) {

            }
        }); */
    }
    return resultdata;
}

function GetTrimmedStr(source, delimeter) {
    if (typeof delimeter == "undefined")
        delimeter = ",";
    return source.replace(/(^,)|(,$)/g, "")
}

function GetSimScoreDetail() {
    var obj = {};
    obj.UserSimScore = "";
    if (gSimScore.Parameters != undefined) {
        var userSimScore = 0;
        for (var i = 0; i < gSimScore.Parameters.length; i++) {
            var grpscore = GetCumulativeGroupScoreValue(gSimScore.Parameters[i].Name);
            userSimScore += (Number(gSimScore.Parameters[i].Score) + Number(grpscore))
        }
        obj.UserSimScore = userSimScore;
    }

    if (gCaseProperties.TotalSimScore != undefined && gCaseProperties.TotalSimScore != "") {
        obj.TotalSimScore = gCaseProperties.TotalSimScore
        obj.PctSimScore = ((Number(userSimScore) / Number(gCaseProperties.TotalSimScore)) * 100).toFixed(2);
    }
    else {
        obj.TotalSimScore = "";
        obj.PctSimScore = "";
    }

    return obj;
}
//gp 15 april added for assessment
function GetOptionNumberText(oListStyle, optIndex) {
    optNumberLabel = "";
    switch (oListStyle) {
        case "lower-alpha":
            optNumberLabel = gOptLables[optIndex].toLowerCase() + ")";
            break;
        case "cap-alpha":
            optNumberLabel = gOptLables[optIndex] + ")";
            break;
        case "roman":
            optNumberLabel = gRomanLabels[optIndex].toLowerCase() + ")";
            break;
        case "number":
            optNumberLabel = (optIndex + 1) + ")";
            break;
        case "decimal":
            optNumberLabel = (optIndex + 1) + ")";
            break;
    }
    return optNumberLabel;
}

$('.disabled').live('click', function (event) {
    event.preventDefault();
    return false;
});

//Anu 29-apr-2015 score for scorecard parameters
function showSimScore(flag) {
		//9 Nov 2016 AD_RA For Pearson review mode
		if ((gPackageType == 'SCORM 1.2' || gPackageType == 'SCORM 2004') && scorm.get('cmi.mode') == "review") {
			return true;
		}

    var txtLst = $(".k-element-text");
    for (var i = 0; i < txtLst.length; i++) {
        var k_text = $(txtLst[i]);
        var simscore = k_text.attr("simscore");
        if (simscore != undefined) {
            if (simscore == "Cumulative") {
                k_text.html(showScoreOf(gSimScore));
            }
            else if (simscore == "Page specific" && flag) {
                k_text.html(showScoreOf(gPageScore));
            }
        }
    }
    //Sets sims cumulative and page specific score to tracking data.
    SetScoreInTrackingData();
}

function showScoreOf(scoreObj) {
    var shtml = "";
    if (scoreObj.Parameters != undefined) {
        for (var i = 0; i < scoreObj.Parameters.length; i++) {
            var grpscore = GetCumulativeGroupScoreValue(scoreObj.Parameters[i].Name);
            //shtml += "<div><span style='font-weight:bold;'>" + scoreObj.Parameters[i].Name + "</span><span>" + (Number(scoreObj.Parameters[i].Score) + Number(grpscore)) + "</span></div>";
            shtml += "<div style='font-weight:bold;font-family:arial narrow;font-size:14px;'><span>" + (Number(scoreObj.Parameters[i].Score) + Number(grpscore)) + "</span></div>";
        }
    }
    return shtml;
}

function SetCumulativeAndPageScore(k_box, type) {
    if (type == "Hotspot") {
        if (gSimScore.Parameters != undefined) {
            for (var i = 0; i < gSimScore.Parameters.length; i++) {
                var fvalue = k_box[gSimScore.Parameters[i].Name];
                var gpName = k_box.GroupName;
                var actName = k_box.ActionName;
                if (fvalue == undefined || fvalue == "")
                    fvalue = 0;
                else
                    fvalue = Number(fvalue);
                if (gpName != undefined && gpName != "") {
                    UpdateCustomScoreArray(gSimScore.Parameters[i].Name, gpName, fvalue, actName)
                } else {
                    gSimScore.Parameters[i].Score += fvalue;
                    gPageScore.Parameters[i].Score += fvalue;
                }
            }
        }
    }
    else {
        if (gSimScore.Parameters != undefined) {
            for (var i = 0; i < gSimScore.Parameters.length; i++) {
                var fvalue = k_box.attr(gSimScore.Parameters[i].Name);
                var gpName = k_box.attr("groupname");
                var actName = k_box.attr("actionname");
                if (fvalue == undefined || fvalue == "")
                    fvalue = 0;
                else
                    fvalue = Number(fvalue);

                if (gpName != undefined && gpName != "") {
                    UpdateCustomScoreArray(gSimScore.Parameters[i].Name, gpName, fvalue, actName)
                } else {
                    gSimScore.Parameters[i].Score += fvalue;
                    gPageScore.Parameters[i].Score += fvalue;
                }
            }
        }
    }
}

function resetPageScore() {
    if (gPageScore.Parameters != undefined) {
        for (var i = 0; i < gPageScore.Parameters.length; i++) {
            gPageScore.Parameters[i].Score = 0;
        }
    }
}

function UpdateCustomScoreArray(scoreName, GpName, actionScore, actionName) {
    var obj = {};

    if (g_GroupScoreArray == undefined)
        g_GroupScoreArray = [];

    if (g_GroupScoreArray.length <= 0) {
        obj.ScoreName = scoreName;
        obj.GpScore = actionScore;
        obj.GpName = GpName;
        obj.ActionItems = [];
        obj.ActionItems.push(actionName);
        g_GroupScoreArray.push(obj);
    }
    else {
        for (var i = 0; i <= g_GroupScoreArray.length - 1; i++) {
            if (g_GroupScoreArray[i].GpName == GpName && g_GroupScoreArray[i].ScoreName == scoreName) {
                for (var k = 0; k <= g_GroupScoreArray[i].ActionItems.length - 1; k++) {
                    if (g_GroupScoreArray[i].ActionItems[k] == actionName) {
                        return;
                    }
                }
                g_GroupScoreArray[i].ActionItems.push(actionName);
                g_GroupScoreArray[i].GpScore = Number(g_GroupScoreArray[i].GpScore) + Number(actionScore);
                return;
            }
        }
        obj.ScoreName = scoreName;
        obj.GpScore = actionScore;
        obj.GpName = GpName;
        obj.ActionItems = [];
        obj.ActionItems.push(actionName);
        g_GroupScoreArray.push(obj);
    }
}

function GetCumulativeGroupScoreValue(scoreName) {
    var _score = 0;
    if (g_GroupScoreArray != undefined && g_GroupScoreArray.length > 0) {
        for (var i = 0; i <= g_GroupScoreArray.length - 1; i++) {
            if (g_GroupScoreArray[i].ScoreName == scoreName) {
                _score = _score + Number(g_GroupScoreArray[i].GpScore);
            }
        }
    }
    return _score;
}

function CalculateAndShowScore(_ths, cmpType) {
    var isclicked = _ths.attr("isclicked");
    if (gActionScoreTracking && isclicked == undefined) {
        if (cmpType == "Hotspot") {
            _ths.attr("isclicked", "true");
            var imgId = _ths.attr("imageid");
            var hsId = _ths.attr("hsid");
            var imgHs = FindObjectInArray(gCurrPageObj.ImageHotspots, "ImageId", imgId);
            if (imgHs != undefined) {
                for (var i = 0; i < imgHs.Hotspots.length; i++) {
                    if (imgHs.Hotspots[i].HotspotId == hsId) {
                        SetCumulativeAndPageScore(imgHs.Hotspots[i], "Hotspot");
                        break;
                    }
                }
            }
        }
        else {
            _ths.attr("isclicked", "true");
            SetCumulativeAndPageScore(_ths);
        }
        showSimScore(true);
    }
}

//Naveen-function used to track data for analytics report.
function SetScoreInTrackingData(isQuizScore, quizObject) {
    var lPageId = gCurrPageObj.PageId;
    var trackDataObject = undefined;
    if (gRMAttemptData.TrackingData == undefined) {
        gRMAttemptData.TrackingData = [];
    }
    for (var i = 0; i < gRMAttemptData.TrackingData.length; i++) {
        if (gRMAttemptData.TrackingData[i].PageId == lPageId) {
            trackDataObject = gRMAttemptData.TrackingData[i];
            break;
        }
    }
    var isnew = false;
    if (trackDataObject == undefined) {
        trackDataObject = {};
        isnew = true;
    }
    if (isQuizScore != true) {
        var lsimscore = '';
        if (gSimScore.Parameters != undefined && gSimScore.Parameters.length > 0) {
            var llscore = 0;
            for (var i = 0; i < gSimScore.Parameters.length; i++) {
                var grpscore = GetCumulativeGroupScoreValue(gSimScore.Parameters[i].Name);
                trackDataObject[gSimScore.Parameters[i].Name] = (Number(gSimScore.Parameters[i].Score) + Number(grpscore));
                llscore += (Number(gSimScore.Parameters[i].Score) + Number(grpscore));
            }
            lsimscore = llscore;
        }
        var lpagescore = '';
        if (gPageScore.Parameters != undefined && gPageScore.Parameters.length > 0) {
            var llscore = 0;
            for (var i = 0; i < gPageScore.Parameters.length; i++) {
                var grpscore = GetCumulativeGroupScoreValue(gPageScore.Parameters[i].Name);
                trackDataObject[gPageScore.Parameters[i].Name] = (Number(gPageScore.Parameters[i].Score) + Number(grpscore));
                llscore += (Number(gPageScore.Parameters[i].Score) + Number(grpscore));
            }
            lpagescore = llscore
        }
        trackDataObject.PageId = lPageId;
        trackDataObject.SimScore = lsimscore;
        trackDataObject.PageSimScore = lpagescore;
    }
    else {
        trackDataObject.PageId = lPageId;
        if (quizObject.QuizScore != undefined)
            trackDataObject.QuizScore = quizObject.QuizScore;
        if (quizObject.scorecard != undefined)
            trackDataObject.scorecard = quizObject.scorecard;
        if (quizObject.QuizTotalScore != undefined)
            trackDataObject.QuizTotalScore = quizObject.QuizTotalScore;
    }
    if (isnew) {
        gRMAttemptData.TrackingData.push(trackDataObject);
    }
}
//Naveen- function already added to sync template data js file.
//Need to remove it from here once template integration is done and required to rename
//added 27-May to style correct incorrect check items.
(function (cash) {
    var g_lastchild;
    $.fn.getCKELastChild_temp = function () {
        recursive_getlastchild(this)
        return g_lastchild;
    }

    //private function
    function recursive_getlastchild(_element) {
        if ($.trim(_element.clone().children().remove().end().text()) == "" && _element.children().length == 1) {
            recursive_getlastchild(_element.children());
        }
        else {
            g_lastchild = _element;
        }
    }

})(jQuery);
//Naveen-end

var ActionBuilder = null;
var actionCounter = 0;

function SetExcelAction() {
    ActionBuilder = null;
    if (gCurrPageObj.ActionBuilders != undefined && gCurrPageObj.ActionBuilders != null && gCurrPageObj.ActionBuilders.length > 0 && actionCounter < gCurrPageObj.ActionBuilders.length) {
        ActionBuilder = gCurrPageObj.ActionBuilders[actionCounter];
        $(".actionInstruction").empty();
        $(".actionInstruction").html(ActionBuilder.InstructionText);
        actionCounter++;
    }

}
function LoadExcelPageContent(pageToLoad, contentArea) {
    return; //vb commented
    actionCounter = 0;
    ActionBuilder = null;
    SetExcelAction();
    htmlContent = $("#Template_Excel").html();
    contentArea.empty();
    contentArea.append(htmlContent);
    contentArea.find("#excelFrame").attr("src", "ExcelDemo/demo/Excel.html");
    //$("#excelFrame").contents().find("head").append('<script type="text/javascript"> var ActionBuilders = ' + ActionBuildersarray + ';</script>');
}
//Anu 28-july-2015 Ref pop up issue sol
function SetRefPopupProps(_obj, _templateObj) {
    if (_templateObj.HideHeader != undefined && _templateObj.HideHeader == true) {
        _obj.HideHeader = _templateObj.HideHeader
    }
    if (_templateObj.ProgressToNextPage != undefined && _templateObj.ProgressToNextPage == true) {
        _obj.ProgressToNextPage = _templateObj.ProgressToNextPage
    }
    if (_templateObj.BoxPadding != undefined && _templateObj.BoxPadding != '') {
        _obj.BoxPadding = _templateObj.BoxPadding;
    }
    if (_templateObj.RefIcon != undefined && _templateObj.RefIcon != "") {
        _obj.RefIcon = _templateObj.RefIcon;
    }
    /*//Set Border color and width.
    if (_templateObj.CurrBorderWidth == "" || _templateObj.CurrBorderWidth == undefined || _templateObj.CurrBorderColor == "" || _templateObj.CurrBorderColor == undefined) {
    }
    else {
        _obj.CurrBorderColor = _templateObj.CurrBackgroundColor;
        _obj.CurrBorderWidth = _templateObj.CurrBorderWidth;
    }
    if (_templateObj.CurrBackgroundColor == "transparent") {
        _obj.CurrBackgroundColor = _templateObj.CurrBackgroundColor;
    }
    else if (_templateObj.CurrBackgroundColor != undefined) {
        _obj.CurrBackgroundColor = _templateObj.CurrBackgroundColor;
    }*/
}
//Anu 29-july-2015 Ref pop up updates
function removeUnwantedDivs(refContent) {
    refContent.find("span.colNum").remove();
    refContent.find("span.colWdt").remove();
    refContent.find("span.colHght").remove();
    refContent.find(".ui-resizable").removeClass("ui-resizable");
    refContent.find(".ui-draggable").removeClass("ui-draggable");
    refContent.find(".ui-draggable-dragging").removeClass("ui-draggable-dragging");
    refContent.find(".ui-resizable-handle").remove();
    refContent.find(".k-element-strip").remove();
    refContent.find(".k-element-text").attr("contenteditable", "false");
    refContent.find(".k-element-textentry").attr("contenteditable", "true"); //RA-25Sep15 - to make text entry editable
    refContent.find(".ui-widget-content").removeClass("ui-widget-content");
    refContent.find(".k-asset-Resize").remove();
    refContent.find(".block-controls").remove();
    refContent.find(".refContainer").css({ "position": "relative" });
    refContent.find(".k-element-box").removeClass("ui-resizable ui-draggable ui-draggable-dragging");
}

//Anu 20-aug-2015 btn comp new feature tab popup
function GeneratePopup(db_model, eleBtn) {
    var iDiv = document.createElement('div');
    iDiv.id = 'customPopupDiv';
    iDiv.className = 'popUpDiv';
    iDiv.style.backgroundColor = db_model.Background;
    //var closeBtn = $('<a href="#" class="fa fa-times customPopupClose">&#10006;</a>')[0];
    //iDiv.appendChild(closeBtn);
    var iImg = document.createElement("img");
    if (db_model.IconType == "TabBtnImg") {
        db_model.IconPath = eleBtn.find(".lblImg").attr("src");
    }
    //Anu 20-aug-2015 tab popup ui change
    if (db_model.IconPath == undefined) {
        iImg.style.display = "none";
    }
    iImg.setAttribute("src", db_model.IconPath);
    iImg.className = "iconDiv";
    iDiv.appendChild(iImg);
    var iUl = GenerateTabs(db_model.ItemList)
    iDiv.appendChild(iUl);
    // document.getElementsByTagName('body')[0].appendChild(iDiv);
    $.fancybox($(iDiv)[0].outerHTML);
    //$('.tabDiv:first-child').addClass('active');
}
function GenerateTabs(arrTabs) {
    var i, item, ref, ref_ul_tabs, ref_div_tabs;
    function ul_tabs() { return $('<ul class="tabNav"></ul>')[0]; }
    function div_tabs() { return document.createElement('div'); }
    function li_A(text, incr) {
        var e = document.createElement('li');
        var aTag = document.createElement('a');
        aTag.setAttribute('href', "#");
        aTag.innerHTML = text;
        aTag.id = 'tab_' + incr;
        if (incr == 0) {
            aTag.className = 'active';
        }
        e.appendChild(aTag);
        return e;
    }
    function li_DIV(descr, incr) {
        var e = document.createElement('div');
        e.innerHTML = descr;
        if (incr == 0) {
            e.className = 'tabDiv active';
        }
        else {
            e.className = 'tabDiv';
        }
        e.id = 'tab_' + incr + '_Div';
        return e;
    }
    ref_ul_tabs = ul_tabs();
    ref_div_tabs = div_tabs()
    ref_div_tabs.style.padding = "10px";
    for (i = 0; i < arrTabs.length; ++i) {
        ref_ul_tabs.appendChild(li_A(arrTabs[i]['ItemTitle'], i));
        ref_div_tabs.appendChild(li_DIV(arrTabs[i]['ItemDesc'], i));
    }
    if (i === 0)
        return '';
    //cc

    ref = $('<div class="tabs"><center></center></div>');
    ref.find('center')[0].appendChild(ref_ul_tabs);
    ref[0].appendChild(ref_div_tabs);
    return ref[0];
}
$(document).on('click', '.tabs a', function () {
    var that = $(this);
    $('.tabs a').removeClass('active');
    that.addClass('active');
    $('.tabDiv').removeClass('active');
    var tabDiv = $('#' + this.id + '_Div');
    tabDiv.addClass('active')
});
function SetButtonSequence(btn_Sequence, rmDisplayname) { //gp 4 sept 2015 added for preview changes
    var btnArr = ["Close", "Next", "Page#", "Prev", "Menu", "Map", "Video", "Home", "Additional Resources", "Audio", "Glossary"];
    var pos_x = 0;
    if (gThemeId > 0) {
        if (btn_Sequence != undefined && btn_Sequence != null) {
            btnArr = btn_Sequence.split(',');
        } else {
            btnArr = {};
        }
    }
    for (var i = 0 ; i < btnArr.length ; i++) {
        var btn = btnArr[i];
        switch (btn) {
            case "Video":
                if (gCaseProperties.ShowVideoLibrary) {
                    $(".AlgoVideoLibraryWrap").css({ "right": pos_x + "px", "display": "inline-block" });
                    pos_x = pos_x + 30;
                }
                break;
            case "Home":
                if (gCaseProperties.ShowHome) {
                    $(".HomeIconWrap").css({ "right": pos_x + "px", "display": "inline-block" });
                    pos_x = pos_x + 30;
                }
                break;
            case "Map":
                if (gCaseProperties.ShowMap) {
                    $(".AlgoMapWrap").css({ "right": pos_x + "px", "display": "inline-block" });
                    pos_x = pos_x + 30;
                }
                break;
            case "Menu":
                if (gCaseProperties.ShowMenu) {
                    $(".MenuIconWrap").css({ "right": pos_x + "px", "display": "inline-block" });
                    pos_x = pos_x + 30;
                }
                break;
            case "Close":
                $(".closePlayerWrap").css({ "right": pos_x + "px", "display": "inline-block" });
                pos_x = pos_x + 30;
                break;
            case "Prev":
                $(".PrevPageWrap").css({ "right": pos_x + "px", "display": "inline-block" });
                pos_x = pos_x + 30;
                break;
            case "Next":
                $(".NextPageWrap").css({ "right": pos_x + "px", "display": "inline-block" });
                pos_x = pos_x + 30;
                break;
            case "Additional Resources":
                $(".RMSliderLink").css({ "right": pos_x + "px", "display": "inline-block" });
                if (rmDisplayname == undefined || rmDisplayname == null)
                {
                    rmDisplayname = "Additional Resources";
                }
                var arbtnlength = (rmDisplayname.length * 7) + 20;
                pos_x = pos_x + arbtnlength;
                break;
            case "Audio":
                $(".AudioIconWrap").css({ "right": pos_x + "px", "display": "inline-block" });
                pos_x = pos_x + 30;
                break;
            case "Glossary":
                $(".GlossaryIconWrap").css({ "right": pos_x + "px", "display": "inline-block" });
                pos_x = pos_x + 30;
                break;
            case "Page#":
                if (gCaseProperties.ShowPagingText) {
                    pos_x = pos_x + 15;
                    $(".pagingTextWrap").css({ "right": pos_x + "px", "display": "inline-block" });
                    pos_x = pos_x + 70;
                }
                break;
            default:
                break;
        }
        pos_x = pos_x + 10;
    }
    $(".nvgbtncontainer").css({ "width": pos_x + "px" });
}
function MCQShowFeedback(feedback) {
    $("#fancyreferencePopup").css("border","0px")
    $("#fancyreferencePopup .refContent").html(feedback.Text);
    $("#fancyreferencePopup .refContent").css("padding", "0px");
    $("#fancyreferencePopup .refHeader").hide();
    $("#fancyreferencePopup .refContent .k-element-box").removeClass("ui-resizable ui-draggable ui-draggable-dragging ui-widget-content");
    $("#fancyreferencePopup .refContent .ui-resizable-handle").remove();
    ////nav-device - required to enable call RenderContentForMode
    //k_DeviceManager.RenderContentForMode("#fancyreferencePopup .refContent");
    ////end
    var hdonoverlay = true;
    if (feedback.hideonoverlay != undefined) {
        if (feedback.hideonoverlay == false)
            hdonoverlay = false;
    }
    $.fancybox({
        'href': "#fancyreferencePopup",
        'padding': 0,
        'showCloseButton': false,
        'hideOnOverlayClick': hdonoverlay,
        'hideOnContentClick': false,
        'onStart': function(){
			$(".fancybox-bg").hide()
			//$(".fancybox-bg").remove();
			$("#fancyreferencePopup").parent().css({ "overflow": "hidden" });
			$("#fancybox-overlay").show();
			$("#fancyreferencePopup").css({"background-color":"transparent"});
            $("#fancybox-outer").css({"background-color":"transparent"});
		},
        'onComplete': function () {
			$(".fancybox-bg").hide()
            $("#fancyreferencePopup").parent().css({ "overflow": "hidden" });
            $("#fancybox-overlay").show();
            $("#fancyreferencePopup").css({"background-color":"transparent"});
            $("#fancybox-outer").css({"background-color":"transparent"});
            //$(".fancybox-bg").remove();
            //var perc = getPerc(popupWidth, devicewidth); //, $(window).width());
            //$("#fancybox-wrap").css({ 'width': perc + "%", "max-width": devicewidth });
            //$("#fancybox-content").css('width', "100%");

            InitializeComponents($('#fancybox-content'));
            removeUIObjects();
        },
        'onClosed': function () {
            if (gotoNextPageFlag || $("#fancyreferencePopup").attr("navtoNext") == "true") {
                gotoNextPageFlag = false;
                // Dont need transition effect
                //$("#NextPage").click();
                var tmpNxtPg = GetPage(gCurrPageObj.NextPageId);
                if (tmpNxtPg != undefined && tmpNxtPg != null) {
                    setTimeout(function () { SelectPageFromMap(gCurrPageObj.NextPageId); }, 0);
                }
            }
            if ($('.audiocontent').html() != '') {
                var player = MediaElementPlayer($('.audiocontent').find('audio'));
                player.pause();
            }
        }
    });
}



function GetMCQdetailObject(objid) {

    var mcqdetailObj = undefined;
    if (gCurrPageObj.MCQDetailArray == "[]") {
        // get the data from pageIdScript.js synchronously
        gCurrPageObj.MCQDetailArray = getDataFromJsFile(gCurrPageObj.PageId + "MCQArray.js");
    }
    if (gCurrPageObj != undefined && objid != undefined) {
        if (gCurrPageObj.MCQDetailArray != undefined && gCurrPageObj.MCQDetailArray.length > 0) {
            for (var i = 0; i < gCurrPageObj.MCQDetailArray.length; i++) {
                if (gCurrPageObj.MCQDetailArray[i].Id == objid) {
                    mcqdetailObj = gCurrPageObj.MCQDetailArray[i];
                    break;
                }
            }
        }
    }
    return mcqdetailObj
}
//RA-24Dec15-TabIndex
function setAccessibilityData(_kElement) {
    //debugger;
    var _tempType = _kElement.attr("temptype");
    var _tabIndex = _kElement.attr("tabindex");
    if (_tabIndex != "") {
        //DDeva: 18Apr17
        //_tabIndex = parseInt(_tabIndex, 10) + 20;
        _kElement.attr("t_tabIndex", _tabIndex);
    }
    _tabIndex = _kElement.attr("t_tabIndex");
    var _contentTitle = _kElement.attr("content-title");
    var _assetTitle = _kElement.attr("asset-title");
    _kElement.attr({ "tabindex": ""});
    if (_tabIndex != undefined && _tabIndex != "") {
        switch (_tempType) {
            case "Image":
                if (_assetTitle != undefined) {
                    if (_kElement.find(".divImageDescription").text() == "" || _kElement.find(".divImageDescription").text() == undefined) {
                        $(_kElement).find(".k-element-image").attr({ "tabindex": _tabIndex, "alt": _assetTitle, "asset-title": _assetTitle });
                    } else {
                        //$(_kElement).find(".k-element-image").attr({ "alt": "" });
                        $(_kElement).attr({ "tabindex": _tabIndex, "title": "" });
                    }
                } else {
                    if (_kElement.find(".divImageDescription").text() == "" || _kElement.find(".divImageDescription").text() == undefined) {
                        $(_kElement).find(".k-element-image").attr({ "tabindex": _tabIndex, "alt": "" });
                    } else {
                        //$(_kElement).find(".k-element-image").attr({ "alt": "" });
                        $(_kElement).attr({ "tabindex": _tabIndex, "title": "" });
                    }
                }
                break;
            case "TextAsset":
                if (_assetTitle != undefined) {
                    $(_kElement).find(".TIC-img").attr({ "tabindex": _tabIndex, "alt": _assetTitle, "asset-title": _assetTitle });
                } else {
                    $(_kElement).find(".TIC-img").attr({ "tabindex": _tabIndex, "alt": "" });
                }
                //NM - role = text is added for mobile accessibility, to skip navigation through child elements , android accessibility issue
                //yet this will not follow tabindex and will follow dom sequence.
                if (_contentTitle != undefined) {
                    $(_kElement).find(".TICContent").attr({ "tabindex": _tabIndex++});
                } else {
                    $(_kElement).find(".TICContent").attr({ "tabindex": _tabIndex++});
                }
                //NM
                if(k_DeviceManager.Is_Android_or_iOs()){
                    if (_contentTitle != undefined) {
                        $(_kElement).find(".TICContent").attr({ "role":"text"});
                    } else {
                        $(_kElement).find(".TICContent").attr({ "role":"text"});
                    }
                }
                //Aditi:Required aria-label for safari and Jaws IE11
                if(!$(_kElement).find(".TICContent").get(0).hasAttribute("aria-label"))
                {
                    $(_kElement).find(".TICContent").attr({"aria-label":$(_kElement).find(".TICContent").text()});
                }
                //NM:Required role='article' for Jaws IE11 to read independant elements.
                $(_kElement).attr("role","article");

                break;
            case "Video":
                if (_contentTitle != undefined) {
                    $(_kElement).find(".vjs-big-play-button").attr({ "tabindex": _tabIndex, "aria-label": _contentTitle });
                } else {
                    $(_kElement).find(".vjs-big-play-button").attr({ "tabindex": _tabIndex, "aria-label": "" });
                }
                break;
            case "Button":
                    //hardcoded for qlsim options NVDA Firefox issue. tab+enter was not working for options in decision page.
                    if($(_kElement).get(0).hasAttribute("simscore"))
                    {
                        if (_contentTitle != undefined) {
                            $(_kElement).attr({ "tabindex": _tabIndex});
                        } else {
                            $(_kElement).attr({ "tabindex": _tabIndex});
                        }
                    }else{
                        if (_contentTitle != undefined) {
                            $(_kElement).find(".k-element-button").attr({ "tabindex": _tabIndex/*, "title": _contentTitle*/ });
                        } else {
                            $(_kElement).find(".k-element-button").attr({ "tabindex": _tabIndex/*, "title": ""*/ });
                        }
                        $.each($(_kElement).get(0).attributes, function () {
                            if (this.specified) {
                                if (this.name.indexOf("aria") > -1 || this.name == "role"){
                                    var attrval = $(_kElement).attr(this.name)
                                    $(_kElement).find(".k-element-button").attr(this.name,attrval)

                                }
                            }
                        });
                        /*$.each($(_kElement).get(0).attributes, function () {
                            if (this.specified) {
                                if (this.name.indexOf("aria") > -1 || this.name == "role"){
                                    $(_kElement).removeAttr(this.name);
                                }
                            }
                        });*/
                        var attarr = $(_kElement).get(0).attributes;
                        var dup_arr = $.map(attarr, function(el) { return el });
                        for(var a=0; a < dup_arr.length; a++){
                                if (dup_arr[a].name.indexOf("aria") > -1 || dup_arr[a].name == "role"){
                                    $(_kElement).removeAttr(dup_arr[a].name);
                                }
                        }
                        $(_kElement).removeAttr("tabindex");
                    }

                    break;
                case "Text":
                    //NM - role = text is added for mobile accessibility, to skip navigation through child elements, android accessibility issue
                    //yet this will not follow tabindex and will follow dom sequence.
                    if (_contentTitle != undefined) {
                        $(_kElement).attr({  "tabindex": _tabIndex});
                    } else {
                        $(_kElement).attr({ "tabindex": _tabIndex})
                    }
                    if(k_DeviceManager.Is_Android_or_iOs()){
                        if(!$(_kElement).get(0).hasAttribute("role"))
                        {
                            $(_kElement).attr({"role":"text"});
                        }
                    }
                    //Required aria-label for safari and Jaws IE11
                    if(!$(_kElement).get(0).hasAttribute("aria-label"))
                    {
                        $(_kElement).attr({"aria-label":$(_kElement).text()});
                    }
                    break;
                case "TextEntry":
                    if (_contentTitle != undefined) {
                        $(_kElement).attr({ "tabindex": _tabIndex/*, "title": _contentTitle */});
                    } else {
                        $(_kElement).attr({ "tabindex": _tabIndex/*, "title": "" */});
                    }
                    break;

                case "MCQDropdown":
                    //NM - role = text is added for mobile accessibility, to skip navigation through child elements, android accessibility issue
                    //yet this will not follow tabindex and will follow dom sequence.
                    if(k_DeviceManager.Is_Android_or_iOs()){
                        $(_kElement).attr({ "tabindex": _tabIndex,"role":"text"/*, "title": _contentTitle */});
                    } else {
                        $(_kElement).attr({ "tabindex": _tabIndex});
                    }
                    break;
                case "Checklist":
                    $(_kElement).find(".checkitem input").each(function(){
                        $(this).attr("tabindex",_tabIndex);
                    });
                    break;
            }
        }
        $("[aria-describedby]").removeAttr("aria-describedby");
    }
    //DDeva:30/05/16 -Screen resolution change event
$(window).resize(function () {
        /*if ((screen.availHeight || screen.height - 30) <= window.innerHeight) {
            // browser is almost certainly fullscreen
            return;
        }*/
	var isTouchDevice = function() {  return 'ontouchstart' in window || 'onmsgesturechange' in window; };
    var isDesktop = window.screenX != 0 && !isTouchDevice() ? true : false;

    var userAgent = window.navigator.userAgent.toLowerCase(),
            iphone = /iphone/.test(userAgent),
            ipad = /ipad/.test(userAgent);

    if(!isTouchDevice() && !(iphone || ipad)){
    	k_windowResize(k_DeviceManager.GetClientWidth());
    }
});

function k_windowResize(_clientwidth)
    {

    if (gCaseProperties.IsResponsive) {
    k_DeviceManager.IdentifyModeAndUpdatePlayerLayout(_clientwidth, Number(gCaseProperties.StageSize))
    k_DeviceManager.RenderContentForMode("#contentContainer", "", true);
    $(".k-element-box[defaultVisibility='Hidden']").hide();
    $(".k-element-box[defaultVisibility='Visible']").show();
    removeUIClasses();
    k_DeviceManager.TempInitiateElements("#contentContainer");
    if (/Edge/.test(navigator.userAgent)) {
        setTimeout(function(){
            $(".ContentArea").find(".k-element-box").each(function () {
	                var _kElement = $(this);
	                setAccessibilityData(_kElement);
            });
        },50)
    }
    else {
        $(".ContentArea").find(".k-element-box").each(function () {
            var _kElement = $(this);
            setAccessibilityData(_kElement);
         });
    }
    if (typeof k_Cust_OnOrientationChange == 'function') {
        k_Cust_OnOrientationChange();
    }
    //add attr aria-hidden="true" for hidden div's.
    SetAriaHidden();

}
}

$(".ToptDTP .Options li").live("mouseover", function () {
    $(".ToptDTP .Options li").removeClass("over")
    $(this).addClass("over");
});

$(".ToptDTP .Options li").live("mouseout", function () {
    $(this).removeClass("over")
});

function SetAriaHidden(){
    $("[aria-hidden]:not(.notaccessible)").removeAttr("aria-hidden");
    //$("[aria-hidden]").removeAttr("aria-hidden")
    //$("div:hidden").attr("aria-hidden", "true")
    $("div:hidden:not(.notaccessible)").attr("aria-hidden", "true")

    if ($.trim($("#ExtLinkDialog").text()) == "")
        $("#ExtLinkDialog").attr("aria-hidden", "true")

    if ($.trim($("#dummydivkbox").text()) == "")
        $("#dummydivkbox").attr("aria-hidden", "true")
}



(function($) {
  if ($.fn.style) {
    return;
  }

  // Escape regex chars with \
  var escape = function(text) {
    return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
  };

  // For those who need them (< IE 9), add support for CSS functions
  var isStyleFuncSupported = !!CSSStyleDeclaration.prototype.getPropertyValue;
  if (!isStyleFuncSupported) {
    CSSStyleDeclaration.prototype.getPropertyValue = function(a) {
      return this.getAttribute(a);
    };
    CSSStyleDeclaration.prototype.setProperty = function(styleName, value, priority) {
      this.setAttribute(styleName, value);
      var priority = typeof priority != 'undefined' ? priority : '';
      if (priority != '') {
        // Add priority manually
        var rule = new RegExp(escape(styleName) + '\\s*:\\s*' + escape(value) +
            '(\\s*;)?', 'gmi');
        this.cssText =
            this.cssText.replace(rule, styleName + ': ' + value + ' !' + priority + ';');
      }
    };
    CSSStyleDeclaration.prototype.removeProperty = function(a) {
      return this.removeAttribute(a);
    };
    CSSStyleDeclaration.prototype.getPropertyPriority = function(styleName) {
      var rule = new RegExp(escape(styleName) + '\\s*:\\s*[^\\s]*\\s*!important(\\s*;)?',
          'gmi');
      return rule.test(this.cssText) ? 'important' : '';
    }
  }

  // The style function
  $.fn.style = function(styleName, value, priority) {
    // DOM node
    var node = this.get(0);
    // Ensure we have a DOM node
    if (typeof node == 'undefined') {
      return this;
    }
    // CSSStyleDeclaration
    var style = this.get(0).style;
    // Getter/Setter
    if (typeof styleName != 'undefined') {
      if (typeof value != 'undefined') {
        // Set style property
        priority = typeof priority != 'undefined' ? priority : '';
        style.setProperty(styleName, value, priority);
        return this;
      } else {
        // Get style property
        return style.getPropertyValue(styleName);
      }
    } else {
      // Get CSSStyleDeclaration
      return style;
    }
  };
})(jQuery);
//DDeva: 18Apr17 - not used
function HiddenAccessibility(isAriaHidden, elemId) {
    if (typeof elemId !== 'undefined') {
        $(elemId).attr('aria-hidden', isAriaHidden);
    }
}



//DDeva: 18Apr17 - used
(function ($) {
    var oldshow = $.fn.show;
    $.fn.show = function () {
        var ret = oldshow.apply(this, arguments);
        $(this).removeClass('hidden');
        $(this).find('.div-edit-properties').attr('aria-hidden', 'false')
        return ret;
    };

    var oldhide = $.fn.hide;
    $.fn.hide = function () {
        var ret = oldhide.apply(this, arguments);
        $(this).addClass('hidden');
        $(this).find('.div-edit-properties').attr('aria-hidden', 'true')
        return ret;
    };
})(jQuery);


function IsRevel() {
    if(gPackageType.toLowerCase().indexOf('revel')!=-1)
    {
        return true;
    }
    else{
        return false;
    }
}

