﻿//block2
debugger;
var reviewData = [];
var isReview = false;
var gReviewVars = {
    "questionCounter": 0,
    "suspend_data_assessment": {},
    "gAssessmentResultForReview": [],
    "userQzScore": 0,
    "totalQzScore": 0,
    "UserSimScore": 0,
    "TotalSimScore": 0
}
var groupMaxScore = [];
var globalSuspendData = "";

//NM-Revel Integration Changes
var g_tempIntv = null;
$(document).ready(function () {
    debugger;
    if (IsRevel()) {
        g_tempIntv = setInterval(function () {
            if (window.location.host == "stage1.knowdl.com"
                || (typeof piSession != 'undefined' && typeof piSession.currentToken() != 'undefined' && piSession.currentToken() != null)) {
                clearInterval(g_tempIntv);
                g_tempIntv = null;
                //The rest of the code will go here.
                LifeCycleEvents.InitParams();
                LifeCycleEvents.OnLoad();
                if (!k_Revel.isLaunchInitialize()) {
                    k_Revel.InitLaunch()
                    var suspend_data = JSON.stringify(k_Revel.get_StateData());
                    if (suspend_data != "" && suspend_data != "{}") {
                        //RA-2Aug18_Code changed to handle suspend data error
                        var isTrue = ITSimModule.SetScormString(suspend_data);
                        if (isTrue && k_Revel.get_LaunchData().mode == "do") {
                            ITSimModule.GoToBookmarkPage();
                        } else {
                            scorm.set("cmi.location", 1);
                            suspend_data = '';
                            k_Revel.set_StateData(JSON.parse(suspend_data))
                        }
                    }
                }
                if (k_Revel.get_LaunchData().mode == "review") {
                    var suspend_data = JSON.stringify(k_Revel.get_StateData());
                    if (suspend_data != "" && suspend_data != "{}") {
                        ITSimModule.SetScormString(suspend_data);
                        SetReviewMode();
                    }
                }
            }
        }, 100);
    }
    else if (IsScorm1_2_or_2004()) {
        var suspend_data = GetSuspendData();
        if (suspend_data != "" && suspend_data != "{}") {
            globalSuspendData = suspend_data;
            //ITSimModule.SetScormString(suspend_data);
            //RA-2Aug18_Code changed to handle suspend data error
            var isTrue = ITSimModule.SetScormString(suspend_data);
            if (!isTrue) {
                console.log("Scorm Error executed " + isTrue);
                scorm.set("cmi.location", 1)
                suspend_data = '';
                scorm.set("cmi.suspend_data", suspend_data);
                scorm.save();
            }
        }
    }
    debugger;
    //AR - For review mode
    if (IsScorm1_2_or_2004() && GetSuspendData() != "") {
        if (((scorm.get("cmi.mode") != undefined && IsReviewMode()) || (scorm.get("cmi.completion_status") != undefined && scorm.get("cmi.completion_status") == "completed"))) {
            SetReviewMode();
        }
    }

    $("#tk-element-button13").attr({ "role": "button" });
});
//NM-Revel Integration changes
function SetReviewMode() {
    AppendFooter();
    displayReviewScore(false, true);
    isReview = true;
    visitedNodesArray = "";
    $('#k-element-button421').closest(".k-element-box").addClass("disabled");
    for (var index in reviewSkipArray) {
        if (visitedNodesArray.indexOf("," + index + ",") >= 0) { } else {
            delete reviewSkipArray[index];
        }
    }
}
function IsScorm1_2_or_2004() {
    return (gPackageType == 'SCORM 1.2' || gPackageType == 'SCORM 2004');
}
function IsScorm1_2() {
    return (gPackageType == 'SCORM 1.2');
}
function IsScorm2004() {
    return (gPackageType == 'SCORM 2004');
}
function IsReviewMode() {
    return scorm.get('cmi.mode') == "review";
}

function GetSuspendData() {
    var suspend_data = "";
    if (IsScorm1_2_or_2004()) {
        suspend_data = scorm.get('cmi.suspend_data');
    }
    else {
        suspend_data = globalSuspendData;
    }
    return suspend_data;
}

//NM-Revel Integration changes
function GetRevelScoreDetails() {
    var objSimScore = GetSimScoreDetail();
    totalQuizScore = 0;
    achievedQuizScore = 0;
    if (assessmentObj != undefined && assessmentObj.hasOwnProperty("questions")) {
        for (var n11 = 0; n11 < assessmentObj.questions.length; n11++) {
            if (assessmentObj.questions[n11].hasOwnProperty("TotalScore")) {
                totalQuizScore += Number(assessmentObj.questions[n11].TotalScore);
            }
            if (assessmentObj.questions[n11].hasOwnProperty("score")) {
                achievedQuizScore += Number(assessmentObj.questions[n11].score);
            }
        }
    }

    achievedSimScore = Number(objSimScore.UserSimScore);
    totalSimScore = Number(objSimScore.TotalSimScore);

    averageTotalScore = 0;
    averageQuizScore = 0;
    if (totalSimScore > 0) {
        averageTotalScore = Number(((achievedSimScore / totalSimScore) * 100).toFixed(2));
    }
    if (totalQuizScore > 0) {
        averageQuizScore = Number(((achievedQuizScore / totalQuizScore) * 100).toFixed(2));
    }
    averageTotalSimScore = 0;
    if (totalSimScore > 0) {
        averageTotalSimScore = Number(((averageQuizScore + averageTotalScore) / 2).toFixed(2));
    }
    else
        averageTotalSimScore = averageQuizScore;

    var scoreDetails = {}
    scoreDetails.PercentTotalScore = averageTotalSimScore;
    scoreDetails.TotalEarnedPoints = achievedSimScore + achievedQuizScore;
    scoreDetails.TotalPoints = totalSimScore + totalQuizScore;

    return scoreDetails;

}

//AR -  Called on activity completion
function fSetScoreForReviewMode() {
    //NM-Revel Integration changes
    if (IsRevel()) {
        if ((gPages[0].PageId + "") != (gCurrPageObj.PageId + "")) {
            if (k_Revel.get_LaunchData().mode == LaunchModes.do) {
                var suspend_data = ITSimModule.GetScormString();
                k_Revel.set_StateData(JSON.parse(suspend_data))
                var scoredetail = GetRevelScoreDetails();
                k_Revel.PostData(scoredetail.PercentTotalScore, scoredetail.TotalEarnedPoints, true);
            }
        }
    }
    else if (!isReview) {
        var suspend_data = GetSuspendData();
        suspend_data = ITSimModule.GetScormString();
        globalSuspendData = suspend_data;
        if (IsScorm1_2_or_2004()) {
            scorm.set("cmi.suspend_data", suspend_data);
            scorm.save();
        }
    }
}

function displayReviewScore(isAssessment, isFirstPage) {
    debugger;
    var totalScore = ITSimModule.GetScore();
    var _displayScore = "";
    if (isAssessment != undefined && isAssessment == true) {
        _displayScore = "Total Score - " + totalScore.TotalScore + "%<br>Quiz Score - " + totalScore.AvgQuizScore + "%";

    }
    else if (isFirstPage != undefined && isFirstPage == true) {
        _displayScore = "Total Score - " + totalScore.TotalScore + "%";
    }
    else {
        var _score = GetPageScoreForReview();

        if (_score != "" && _score != "NA") {
            var _displayScore = "Total Score - " + totalScore.TotalScore + "%<br>Activity Score - " + _score;

        } else {
            _displayScore = "Total Score - " + totalScore.TotalScore + "%";

        }

    }
    $(".levelsubMenu").html(_displayScore);
    var simScore = totalScore.SimScore;
    Utility.replaceText('.SimPageScoreField', "Score: " + simScore);
    Utility.replaceText('.SimPageProgressField', STR_ModuleProgress + $(".pagingText").find(".progressForeground").css("width"));
}

function GetTotalActivityScoreForReview(k_box, type) {
    debugger;
    var score = 0;
    var gpName = k_box.GroupName;
    if (type == "Hotspot") {
        gpName = k_box.GroupName;
    } else {
        gpName = k_box.attr("groupname");
        totalScore = k_box.attr("score");
    }
    if (gpName != undefined) {
        if (groupMaxScore != undefined && groupMaxScore.length > 0) {
            for (var i = 0; i < groupMaxScore.length; i++) {
                if (gpName == groupMaxScore[i].GroupName) {
                    score = groupMaxScore[i].GroupScore;
                    break;
                }
            }
        }
    }
    return score;
}

function GetPageScoreForReview() {
    debugger;

    var pagesDataArray = ITSimModule.GetAllPagesData();

    var activityscore = 0;
    var totalActivityscore = 0;
    if (pagesDataArray != undefined && pagesDataArray.length > 0) {
        var currPageObj;
        for (var i = 0; i < pagesDataArray.length; i++) {
            if (gCurrPageObj.PageId == pagesDataArray[i].PageID) {
                currPageObj = pagesDataArray[i];
                break;
            }
        }
        if (currPageObj != undefined && currPageObj.GroupName != undefined && currPageObj.GroupName != "") {
            for (var i = 0; i < pagesDataArray.length; i++) {
                if (currPageObj.GroupName == pagesDataArray[i].GroupName) {
                    if (pagesDataArray[i].ScoreObtained != undefined) {
                        activityscore += pagesDataArray[i].ScoreObtained
                    }
                    totalActivityscore += parseInt(pagesDataArray[i].Score);

                }
            }
        }
    }
    if (totalActivityscore == 0)
        return "NA"
    return activityscore + "/" + totalActivityscore;
}




function fCheckScormReviewMode() {
    if (isReview)
        return true;
    return false;
}

function fSetScormReviewMode() {
    if (IsScorm1_2_or_2004() && GetSuspendData() != "") {
        if (((scorm.get("cmi.mode") != undefined && IsReviewMode()) || (scorm.get("cmi.completion_status") != undefined && scorm.get("cmi.completion_status") == "completed"))) {
            //nothing
        }
    }
}



function AddScroll(imageObj, reviewData) {
    var spos = 0;
    if (reviewData != undefined && reviewData.Positions != undefined && reviewData.Positions.length > 0) {
        for (var i = 0; i < reviewData.Positions.length; i++) {
            var posObj = reviewData.Positions[i];
            if (posObj.posY > 500) {
                spos = posObj.posY;
            }
        }
        if (spos > 500) {
            imageObj.closest('.k-element-box').animate({
                scrollTop: spos
            }, 'slow');
        }
    }
}

function DisplayCorrectIncorrect(imgObj, reviewData) {
    $(".reviewDiv").remove();
    if (reviewData != undefined && reviewData.Positions != undefined && reviewData.Positions.length > 0) {
        for (var i = 0; i < reviewData.Positions.length; i++) {
            var posObj = reviewData.Positions[i];
            var appendImage;
            if (posObj.imageId != undefined && posObj.imageId != "") {
                appendImage = $("#" + posObj.imageId);
            }
            else {
                appendImage = imgObj;
            }
            if (posObj.isCorrect) {
                var _div = "<div class='reviewDiv Correct' style='z-index:10000;width:39px;height:39px;position:absolute;left:" + posObj.posX + "px;top:" + posObj.posY + "px;'><img src='/assets/145/images/correct-icon-v1-1.png' style='width:39px;height:35px;' /></div>";
                appendImage.closest('.k-element-box').append(_div);


            } else {
                var _divI = "<div class='reviewDiv InCorrect' style='z-index:10000;width:39px;height:35px;position:absolute;left:" + posObj.posX + "px;top:" + posObj.posY + "px;'><img src='/assets/145/images/incorrect-icon-v1-1.png' style='width:39px;height:35px;' /></div>";

                appendImage.closest('.k-element-box').append(_divI);
            }
        }
    }
}

function AddEditPropertiesClick(event, imgObj, isDifferentImage) {
    debugger;
    if (isReview) {
        return false;
    }
    var posX = imgObj.offset().left;
    var posY = imgObj.offset().top;
    var found = false;
    console.log(gCurrPageObj.PageId);
    ImageId = "";
    if (isDifferentImage != undefined && isDifferentImage == true) {
        ImageId = imgObj.attr("id");
    }
    var rposX = (event.pageX - posX);
    var rposY = (event.pageY - posY);
    if (isNaN(rposX) || isNaN(rposY))
        return;
    var reviewData = ITSimModule.GetReviewData();
    for (var r = 0; r < reviewData.length; r++) {
        if (reviewData[r].pageId == gCurrPageObj.PageId) {
            var sameclick = false;
            if (reviewData[r].Positions != undefined) {
                for (var i = 0; i < reviewData[r].Positions.length; i++) {
                    if (reviewData[r].Positions[i].posX == rposX && reviewData[r].Positions[i].posy == rposY) {
                        sameclick = true;
                        break;
                    }
                }
                if (!sameclick) {
                    var position = { posX: rposX, posY: rposY, isCorrect: false, imageId: ImageId };
                    if (reviewData[r].Positions.length < 3) {
                        reviewData[r].Positions.push(position);
                    }
                    else {
                        reviewData[r].Positions.splice(0, 1);
                        reviewData[r].Positions.push(position);
                    }
                }
            }
            else {
                var position = { posX: rposX, posY: rposY, isCorrect: false, imageId: ImageId };
                reviewData[r].Positions = [position]
            }

            found = true;
        }
    }

    if (!found) {
        var _obj = {};
        _obj.pageId = gCurrPageObj.PageId;
        var position = { posX: rposX, posY: rposY, isCorrect: false, imageId: ImageId };
        _obj.Positions = [position]
        reviewData.push(_obj);
    }
    ITSimModule.SetReviewData(reviewData);
}

function AddHotspotClick(event, hotspotObj, imgObj) {
    debugger;
    if (isReview) {
        return false;
    }
    var posX = imgObj.offset().left;
    var posY = imgObj.offset().top;
    var found = false;
    var pageReviewData;
    console.log(gCurrPageObj.PageId);
    var reviewData = ITSimModule.GetReviewData();
    var rposX;
    var rposY;
    if (event != undefined && event.pageX != undefined) {
        rposX = (event.pageX - posX);
        rposY = (event.pageY - posY);
    }
    else {//gp if module is attmpted using accessibility
        rposX = hotspotObj.position().left + 20;
        rposY = hotspotObj.position().top + 20;
    }
    for (var r = 0; r < reviewData.length; r++) {
        if (reviewData[r].pageId == gCurrPageObj.PageId) {
            var sameclick = false;
            var posindex = 0;
            if (reviewData[r].Positions != undefined) {
                for (var i = 0; i < reviewData[r].Positions.length; i++) {
                    if (reviewData[r].Positions[i].posX == rposX && reviewData[r].Positions[i].posY == rposY) {
                        sameclick = true;
                        posindex = i;
                        break;
                    }
                }
                if (!sameclick) {
                    var position = { posX: rposX, posY: rposY, isCorrect: true };
                    if (reviewData[r].Positions.length < 3) {
                        reviewData[r].Positions.push(position);
                    }
                    else {
                        reviewData[r].Positions.splice(0, 1);
                        reviewData[r].Positions.push(position);
                    }
                }
                else {
                    if (reviewData[r].Positions[posindex].isCorrect == undefined || reviewData[r].Positions[posindex].isCorrect == false) {
                        reviewData[r].Positions[posindex].isCorrect = true;
                    }
                }
            }
            else {
                var position = { posX: rposX, posY: rposY, isCorrect: true };
                reviewData[r].Positions = [position]
            }
            pageReviewData = reviewData[r];
            found = true;
        }
    }

    if (!found) {
        var _obj = {};
        _obj.pageId = gCurrPageObj.PageId;
        var position = { posX: rposX, posY: rposY, isCorrect: true };
        _obj.Positions = [position]
        reviewData.push(_obj);
        pageReviewData = _obj
    }
    ITSimModule.SetReviewData(reviewData);
    fSetScoreForReviewMode(hotspotObj, pageReviewData, "Hotspot");
    $(".div-edit-properties1").die("click");
}

function DisplayAssessmentInReviewMode() {

    $(".btnAssessSubmit").hide();
    var spanCorrect = "<span style='position:absolute;color:#009933;padding-left:14px;margin-top:-2px;'>✔</span>";
    var spanIncorrect = "<span style='position:absolute;color:#ff0000;padding-left:14px;margin-top:-2px;'>✖</span>";
    debugger;
    if (gAssessmentResult != undefined && gAssessmentResult.length > 0) {
        var qsnband = $(".questionBand:visible");
        var questionNo = qsnband.find(".k-element-question").attr("position")
        for (var i = 0 ; i < gAssessmentResult.length; i++) {
            var currQues = gAssessmentResult[i];
            if (i == questionNo - 1) {
                var selOption = currQues.SelectedOptions.replaceAll(",", "");
                var iscorrect = false;
                var correctOptionId;
                for (j = 0; j < currQues.Options.length; j++) {
                    if (currQues.Options[j].AssessmentValue.toLowerCase() == "correct") {
                        correctOptionId = currQues.Options[j].OptNo;
                        if (Number(currQues.Options[j].OptNo) == Number(selOption)) {
                            iscorrect = true;
                        }
                    }

                }
                qsnband.find("td.optno").closest("tr.optionrow").addClass("optionrowdisabled");
                qsnband.find("td.optno").closest("tr.optionrow").removeClass("optionrow");
                qsnband.find("td.optno[data-optno='" + selOption + "']").find("input").prop("checked", true)
                qsnband.find("td.optno").find("input").attr("disabled", "true");
                qsnband.find("td.optno").prev("td").html("");
                qsnband.find("td.optno").prev("td").css({ "padding-right": "24px" });
                if (iscorrect) {
                    qsnband.find("td.optno[data-optno='" + correctOptionId + "']").closest("tr").find(".opttext span").css({ "color": "green" });
                    qsnband.find("td.optno[data-optno='" + correctOptionId + "']").prev("td").html(spanCorrect);
                }
                else {
                    qsnband.find("td.optno[data-optno='" + correctOptionId + "']").closest("tr").find(".opttext span").css({ "color": "green" });
                    qsnband.find("td.optno[data-optno='" + correctOptionId + "']").prev("td").html(spanCorrect)
                    qsnband.find("td.optno[data-optno='" + selOption + "']").closest("tr").find(".opttext span").css({ "color": "red" });
                    qsnband.find("td.optno[data-optno='" + selOption + "']").prev("td").html(spanIncorrect);

                }
            }
        }
    }
}


function AppendFooter() {
    debugger;
    if ($(".levelfooterdiv").length == 0) {
        var str = '<div class="levelfooterdiv"><div class="navBtn prev" onClick="GoToPrev()" role="button" tabindex = 195 aria-label="Previous"><a href="#"></a></div><div style="display: inline-block;width: 2px;"></div><div class="boxleveldropdown" style="width: 150px;"  role="button" tabindex = 196 aria-label="Scorecard"><span class="leftarrow"></span><ul class="levelmenu"><li class="uparrow" style = "width: 100px; margin-left: -8px;"><span class="menutitle" >Scorecard</span><div class="levelsubMenu" tabindex = 197 role="text">Total Score - <br>Activity Score - </div><a class="menuArrow"></a></div><div style="display: inline-block;width: 2px;"></div><div class="navBtn next" onClick="GoToNext()" role="button" tabindex = 198 aria-label="Next"><a href="#"></a></div></div>';
        $("#restOftheContent").append($(str));
        $(".navBtn.prev").css({
            "opacity": ".5",
            "pointer-events": "none"
        });
        $(".navBtn.prev").attr("aria-disabled", "true")
    }
}

$('.boxleveldropdown').die('click').live('click', function (event) {
    DisplaySubmenu();
});
$('.boxleveldropdown').die('keyup').live('keyup', function (event) {
    if (window.event) {
        key = window.event.keyCode;
    } else if (event) {
        key = event.keyCode;
    }
    // Was the Enter key pressed?
    if (key == 13) {

        $(this).trigger("click");
    }

});

function DisplaySubmenu() {
    if ($(".levelsubMenu").is(":visible")) {
        $(".levelsubMenu").hide();
        $('.rightarrow').removeClass('fa-chevron-up').addClass('fa-chevron-right');
    } else {
        $(".levelsubMenu").show();
        $('.rightarrow').removeClass('fa-chevron-right').addClass('fa-chevron-up');
    }
}

function GoToPrev() {
    //NM-Revel Integration changes
    if (IsRevel()) {
        LifeCycleEvents.OnInteraction("Previous button click.")
    }
    mTreeObj.GoToPrev();
}

function GoToNext() {
    //NM-Revel Integration changes
    if (IsRevel()) {
        LifeCycleEvents.OnInteraction("Next button click.")
    }
    mTreeObj.GoToNext();
}

var mTreeObj = {
    Goto: function (pageid) {
        SelectPageFromMap(pageid);
    },
    GoToPrev: function () {
        debugger;
        try {
            if ($(".navBtn.prev").css("pointer-events") == "none") {
                return;
            }
            var isAssessment = gCurrPageObj.PageId == assessmentPageId ? true : false;

            if (isAssessment) {

                if (assessmentObj.currentQuestion > 0) {

                    assessmentObj.currentQuestion--;
                    console.log(assessmentObj.currentQuestion);
                    buildAssessmentQuestion();
                } else {

                    if (gCurrPageObj.PrevPageId != undefined && gCurrPageObj.PrevPageId != "") {
                        if (reviewSkipArray[gCurrPageObj.PrevPageId] != undefined) {
                            SelectPageFromMap(reviewSkipArray[gCurrPageObj.PrevPageId].PrevPageId);
                        }
                        else {
                            SelectPageFromMap(gCurrPageObj.PrevPageId);
                        }
                    }
                    if (gCurrPageObj.NextPageId != undefined && gCurrPageObj.NextPageId != "") {
                        enableobj($(".navBtn.next"));
                    } else {
                        disableobj($(".navBtn.next"));
                    }
                    if (gCurrPageObj.PrevPageId != undefined && gCurrPageObj.PrevPageId != "") {
                        enableobj($(".navBtn.prev"));
                    } else {
                        disableobj($(".navBtn.prev"));
                    }
                }
            } else {
                if (gCurrPageObj.PrevPageId != undefined && gCurrPageObj.PrevPageId != "") {
                    if (reviewSkipArray[gCurrPageObj.PrevPageId] != undefined) {
                        SelectPageFromMap(reviewSkipArray[gCurrPageObj.PrevPageId].PrevPageId);
                    }
                    else {
                        SelectPageFromMap(gCurrPageObj.PrevPageId);
                    }
                }
                if (gCurrPageObj.NextPageId != undefined && gCurrPageObj.NextPageId != "") {
                    enableobj($(".navBtn.next"));
                } else {
                    disableobj($(".navBtn.next"));
                }
                if (gCurrPageObj.PrevPageId != undefined && gCurrPageObj.PrevPageId != "") {
                    enableobj($(".navBtn.prev"));
                } else {
                    disableobj($(".navBtn.prev"));
                }
            }
        } catch (expn) {
            //menuNodeIndex++;
            alert(expn.message);
        }
    },
    GoToNext: function () {
        try {
            debugger;
            if ($(".navBtn.next").css("pointer-events") == "none") {
                return;
            } else {
                var isAssessment = gCurrPageObj.PageId == assessmentPageId ? true : false;
                if (gCurrPageObj.NextPageId != undefined && gCurrPageObj.NextPageId == assessmentPageId) {
                    assessmentObj.currentQuestion = 0;

                }
                if (isAssessment) {

                    if (assessmentObj.questions != undefined && assessmentObj.currentQuestion < assessmentObj.questions.length - 1) {
                        assessmentObj.currentQuestion++;
                        console.log(assessmentObj.currentQuestion);
                        buildAssessmentQuestion();
                    } else {
                        if (gCurrPageObj.NextPageId != undefined && gCurrPageObj.NextPageId != "") {
                            if (reviewSkipArray[gCurrPageObj.NextPageId] != undefined) {
                                SelectPageFromMap(reviewSkipArray[gCurrPageObj.NextPageId].NextPageId);
                            }
                            else {
                                SelectPageFromMap(gCurrPageObj.NextPageId);
                            }
                        }
                        if (gCurrPageObj.NextPageId != undefined && gCurrPageObj.NextPageId != "") {
                            enableobj($(".navBtn.next"));
                        } else {
                            disableobj($(".navBtn.next"));
                        }
                        if (gCurrPageObj.PrevPageId != undefined && gCurrPageObj.PrevPageId != "") {
                            enableobj($(".navBtn.prev"));
                        } else {
                            disableobj($(".navBtn.prev"));
                        }
                    }
                } else {
                    if (gCurrPageObj.NextPageId != undefined && gCurrPageObj.NextPageId != "") {
                        if (reviewSkipArray[gCurrPageObj.NextPageId] != undefined) {
                            SelectPageFromMap(reviewSkipArray[gCurrPageObj.NextPageId].NextPageId);
                        }
                        else {
                            SelectPageFromMap(gCurrPageObj.NextPageId);
                        }
                    }
                    if (gCurrPageObj.NextPageId != undefined && gCurrPageObj.NextPageId != "") {
                        enableobj($(".navBtn.next"));
                    } else {
                        disableobj($(".navBtn.next"));
                    }
                    if (gCurrPageObj.PrevPageId != undefined && gCurrPageObj.PrevPageId != "") {
                        enableobj($(".navBtn.prev"));
                    } else {
                        disableobj($(".navBtn.prev"));
                    }
                }
            }
        } catch (expn) {
            //menuNodeIndex--;
            alert(expn.message);
        }
    }
};

function disenprevnext() {
    if (gCurrPageObj.PageId == 40 && $(".questionBand:visible").length == 0) {
        $(".navBtn.next").css({
            "opacity": ".5",
            "pointer-events": "none"
        });
        $(".navBtn.next").attr("aria-disabled", "true");
        $(".navBtn.prev").css({
            "opacity": "1",
            "pointer-events": ""
        });
        $(".navBtn.prev").attr("aria-disabled", "false");
    } else if (gCurrPageObj.ArrayIndex == 0) {
        $(".navBtn.prev").css({
            "opacity": ".5",
            "pointer-events": "none"
        });
        $(".navBtn.prev").attr("aria-disabled", "true");
        $(".navBtn.next").css({
            "opacity": "1",
            "pointer-events": ""
        });
        $(".navBtn.next").attr("aria-disabled", "false");
        $("#scorediv").show();
        g_isFromSummary = "";
    } else {
        $(".navBtn.prev").css({
            "opacity": "1",
            "pointer-events": ""
        });
        $(".navBtn.prev").attr("aria-disabled", "false");
        $(".navBtn.next").css({
            "opacity": "1",
            "pointer-events": ""
        });
        $(".navBtn.next").attr("aria-disabled", "false");
    }
}

function disableobj(obj) {
    obj.css({
        "opacity": ".5",
        "pointer-events": "none"
    });
    obj.attr("aria-disabled", "true");
}
function enableobj(obj) {
    obj.css({
        "opacity": "1",
        "pointer-events": ""
    });
    obj.attr("aria-disabled", "false");
}


function CustomReviewModeForTextEntry() {
    var settings = PageSettings[gCurrPageObj.PageId];
    reviewTextId = settings.ReviewTextId;
    var textEntryId = settings.EmbedSettings[0].childId;

    var k_box = $('.EmbededElement').closest(".k-element-box");
    if (isReview) {
        var reviewData = ITSimModule.GetReviewDataForPage();
        if (reviewData != undefined && reviewData.textEntry != undefined && reviewData.textEntry.length > 0) {
            var p = "";
            for (i = 0; i < reviewData.textEntry.length; i++) {
                if (reviewData.textEntry[i] != undefined && reviewData.textEntry[i] != "") {
                    var tEntry = reviewData.textEntry[i].trim().toLowerCase();
                    if (tEntry == "openoffice.org" || tEntry == "http://openoffice.org" || tEntry == "www.openoffice.org" || tEntry == "http://www.openoffice.org") {
                        if (reviewData.isCorrect && i == 0) {
                            $("#" + textEntryId).html("<p class='OpenSansFont' style='color:green;font-weight:bold;font-size: 13px; '>" + reviewData.textEntry[i] + "</p>")
                        }
                        else {
                            $("#" + reviewTextId).html("<p class='OpenSansFont'  style='color:green;font-weight:bold;font-size: 13px; '>" + reviewData.textEntry[i] + "</p>");
                            $("#" + reviewTextId).closest(".k-element-box").show();
                        }
                    }
                    else {
                        $("#" + textEntryId).html("<p class='OpenSansFont'  style='color:red;font-weight:bold;font-size: 13px; '>" + reviewData.textEntry[i] + "</p>")
                    }
                }
            }
        }


    }
}