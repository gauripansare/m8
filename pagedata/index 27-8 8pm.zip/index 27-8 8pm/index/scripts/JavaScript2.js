﻿///
/// Module 2: Application Software
///

//block1
var moduleLoaded = true;

debugger;
//DDeva : constants
var STR_ModuleProgress = "Module Progress: ";
var STR_Score = "Score: ";

var INT_assessmentPageIndex = 32;
var assessmentObj = {};
var ua = navigator.userAgent.toLowerCase();
var isAndroid = ua.indexOf("android") > -1;
var isIE11version = !!navigator.userAgent.match(/Trident.*rv\:11\./);
var isIOS = !!navigator.platform && /iPad|iPhone|iPod/.test(navigator.platform);
var isChrome = /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor);
var disableHintStepButtonArray = [];
var isSafari = $.browser.safari;
var isLoadFirstPage = true;
var assessmentPageId = 55;
var isKeyUpEventTriggered = false;

var reviewSkipArray = {
    15: {
        PrevPageId: 8,
        NextPageId: 12
    }
}
//DDeva : Generic functions
//1. Util
var Utility = function () {
    return {
        shuffle: function (e) {
            for (var t, n, r = e.length; 0 !== r;) n = Math.floor(Math.random() * r), r -= 1, t = e[r], e[r] = e[n], e[n] = t;
            return e
        },
        getParameterByName: function (e, t) {
            e = e.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
            var n = new RegExp("[\\?&]" + e + "=([^&#]*)"),
                r = n.exec(t);
            return null === r ? "" : decodeURIComponent(r[1].replace(/\+/g, " "))
        },
        updateHtml: function (e, t) {
            $.each(e, function (e, n) {
                var r = "",
                    a = $(n);
                $.each(t, function (e, t) {
                    var n = new RegExp(e, "g");
                    r += a.html().replace(n, t)
                }), a.html(r)
            })
        },
        mergeArray: function (e, t) {
            var n = e.concat(t).sort(function (e, t) {
                return e > t ? 1 : t > e ? -1 : 0
            });
            return n.filter(function (e, t) {
                return n.indexOf(e) === t
            })
        },
        injectCss: function (e) {
            var t = document.getElementsByTagName("head")[0],
                n = document.createElement("style");
            n.setAttribute("type", "text/css"), n.styleSheet ? n.styleSheet.cssText = e : n.appendChild(document.createTextNode(e)), t.appendChild(n)
        },
        getRandomIntInclusive: function (e, t) {
            return Math.floor(Math.random() * (t - e + 1)) + e
        },
        getAbbrNum: function (e, t, n, r) {
            if (0 > e) var a = -1;
            else var a = 1; -1 == a ? (a = "-", e = Math.abs(e)) : a = "", t = Math.pow(10, t);
            for (var o = ["k", "m", "b", "t"], c = o.length - 1; c >= 0; c--) {
                var u = Math.pow(10, 3 * (c + 1));
                if (e >= u) {
                    e = Math.round(e * t / u) / t, 1e3 == e && c < o.length - 1 && (e = 1, c++), e += o[c];
                    break
                }
            }
            return a + n + e
        },
        removeDuplicates: function (originalArray, objKey) {
            var trimmedArray = [];
            var values = [];
            var value;
            for (var i = 0; i < originalArray.length; i++) {
                value = originalArray[i][objKey];
                if (values.indexOf(value) === -1) {
                    trimmedArray.push(originalArray[i]);
                    values.push(value);
                }
            }
            return trimmedArray;
        },
        hasDuplicates: function (originalArray, objKey) {
            var hsDup = false;
            var values = [];
            var value;
            for (var i = 0; i < originalArray.length; i++) {
                value = originalArray[i][objKey];
                if (values.indexOf(value) === -1) {
                    values.push(value);
                } else {
                    hsDup = true;
                    break;
                }
            }
            return hsDup;
        },
        replaceText: function (selector, replacewith) {
            var all = $(selector + ' *:not(:has("*"))'),
                maxDepth = 0,
                deepest = [];
            all.each(function () {
                var depth = $(this).parents().length || 0;
                if (depth > maxDepth) {
                    deepest = [this];
                    maxDepth = depth;
                } else if (depth == maxDepth) {
                    deepest.push(this);
                }
            });
            $(deepest[0]).text(replacewith)
        }
    }
}();

//2. For click event binding
function BindEventFunction(selectors, func) {
    $(selectors).die("click").live("click", function (event) {
        if ($(this).hasClass("disabled") || $(this).find(".k-element-button").hasClass("disabled")) {
            return false;
        }
        func(event);
        //event.stopPropagation();
        //event.preventDefault();
    });

    $(selectors).die("keyup").live("keyup", function (event) {
        //isKeyUpEventTriggered = false;
        if ($(this).hasClass("disabled") || $(this).find(".k-element-button").hasClass("disabled")) {
            return false;
        }
        if (window.event) {
            key = window.event.keyCode;
        } else if (event) {
            key = event.keyCode;
        }
        if (key == 13) {
            $(this).trigger('click');
        }
    });

}

//3. define the scrollbar function to detec tin case of course launching in an iframe
(function ($) {
    $.fn.hasScrollBar = function () {
        return this.get(0).scrollHeight > this.height();
    }
})(jQuery);

//NM - 21-08-2017 - accessibility change
//Try to avoid custom code inside below four methods. Keep the method definition as simple as possible.
function k_Cust_LoadPageContentComplete() {
    ITSimModule.OnPageLoad();

}

function k_Cust_OnOrientationChange() {
    ITSimModule.OnOrientaionChange();
}

function k_Cust_RefPopupComplete() { }

function k_Cust_IdentifyMode() { }
//End

//NM - 21-08-2017 - accessibility change
/*
Common class defined on components
.IntroHeadingLevel1, .IntroHeadingLevel2, .IntroDescription, .IntroStartBtn 
.SimPageHeadingLevel1, .SimPageHeadingLevel2, .SimPageScoreField, .SimPageProgressField, 
.SimPageScoreBtn, .SimPageHintBtn, .SimPageStepByStepBtn, .SimPageHeaderBgImg
*/

var ITSimModule = (function () {
    var pagesDataArray = [];
    var simTotalScore = 0;
    var bookmarkPage = 1;
    var reviewData = [];
    var totalScore = {};
    var completionStatus = "inprogress";


    //action-values-are - next/popup/close
    PageSettings = {
        1: {},
        3: {
            NextPageId: 8,
            HotspotSettings: [{
                imageId: "tk-element-image32",
                hotspotId: "divHotspots0_1",
                action: "next",
                accessText: "Microsoft Edge icon"
            }],
            PageLoadPopup: {
                popupBtnId: "tk-element-button33",
                action: "close"
            }
        },
        8: {
            NextPageId: 15,
            EmbedSettings: [{
                parentId: "tk-element-image82",
                childId: "k-element-textentry81",
                type: "input",
                cssstyle: {
                    left: 231,
                    top: 136,
                    width: 318
                }
            }, {
                parentId: "tk-element-image82",
                childId: "k-element-text87",
                type: "text",
                cssstyle: {
                    left: 231,
                    top: 166,
                    width: 318
                }
            }],
            ReviewTextId: "k-element-text87",
            action: "next"
        },
        15: {
            NextPageId: 12,
            PageLoadPopup: {
                popupBtnId: "tk-element-button153",
                action: "next"
            }
        },
        12: {
            NextPageId: 13,
            HotspotSettings: [{
                imageId: "tk-element-image122",
                hotspotId: "divHotspots0_1",
                action: "next",
                accessText: "I want to learn more about OpenOffice link"
            }],
            PageLoadPopup: {
                popupBtnId: "tk-element-button123",
                action: "close"
            }
        },
        13: {
            NextPageId: 14,
            HotspotSettings: [{
                imageId: "tk-element-image132",
                hotspotId: "divHotspots0_1",
                action: "popup",
                accessText: "twenty years"
            }],
            SuccessPopup: {
                popupBtnId: "k-element-button134",
                action: "next"
            }
        },
        14: {
            NextPageId: 16,
            HotspotSettings: [{
                imageId: "tk-element-image142",
                hotspotId: "divHotspots0_1",
                action: "popup",
                accessText: "free of charge"
            }, {
                imageId: "tk-element-image142",
                hotspotId: "divHotspots0_2",
                action: "popup",
                accessText: "and its free"
            }],
            PageLoadPopup: {
                popupBtnId: "tk-element-button143",
                action: "close"
            },
            SuccessPopup: {
                popupBtnId: "k-element-button144",
                action: "next"
            }
        },
        16: {
            NextPageId: 17,
            HotspotSettings: [{
                imageId: "tk-element-image162",
                hotspotId: "divHotspots0_1",
                action: "popup",
                accessText: "Apache 2.0 License link"
            }],
            PageLoadPopup: {
                popupBtnId: "tk-element-button163",
                action: "close"
            },
            SuccessPopup: {
                popupBtnId: "k-element-button164",
                action: "next"
            }
        },
        17: {
            NextPageId: 18,
            HotspotSettings: [{
                imageId: "tk-element-image172",
                hotspotId: "divHotspots0_1",
                action: "popup",
                accessText: "as many computers as you like"
            }],
            PageLoadPopup: {
                popupBtnId: "tk-element-button173",
                action: "close"
            },
            SuccessPopup: {
                popupBtnId: "k-element-button174",
                action: "next"
            }
        },
        18: {
            NextPageId: 28,
            HotspotSettings: [{
                imageId: "tk-element-image182",
                hotspotId: "divHotspots0_1",
                action: "popup",
                accessText: "Product link"
            }],
            PageLoadPopup: {
                popupBtnId: "tk-element-button183",
                action: "close"
            },
            SuccessPopup: {
                popupBtnId: "k-element-button184",
                action: "next"
            }
        },
        28: {
            NextPageId: 19,
            HotspotSettings: [{
                imageId: "tk-element-image282",
                hotspotId: "divHotspots0_1",
                action: "popup",
                accessText: "Blog link"
            }],
            PageLoadPopup: {
                popupBtnId: "tk-element-button283",
                action: "close"
            },
            SuccessPopup: {
                popupBtnId: "k-element-button284",
                action: "next"
            }
        },
        19: {
            NextPageId: 20,
            HotspotSettings: [{
                imageId: "tk-element-image192",
                hotspotId: "divHotspots0_1",
                action: "next",
                accessText: "Back button"
            }],
            PageLoadPopup: {
                popupBtnId: "tk-element-button193",
                action: "close"
            }
        },
        20: {
            NextPageId: 21,
            HotspotSettings: [{
                imageId: "tk-element-image202",
                hotspotId: "divHotspots0_1",
                action: "popup",
                accessText: "Support link"
            }],
            SuccessPopup: {
                popupBtnId: "k-element-button204",
                action: "next"
            }
        },
        21: {
            NextPageId: 22,
            HotspotSettings: [{
                imageId: "tk-element-image212",
                hotspotId: "divHotspots0_1",
                action: "popup",
                accessText: "Contact us link"
            }],
            PageLoadPopup: {
                popupBtnId: "tk-element-button213",
                action: "close"
            },
            SuccessPopup: {
                popupBtnId: "k-element-button214",
                action: "next"
            }
        },
        22: {
            NextPageId: 23,
            HotspotSettings: [{
                imageId: "tk-element-image222",
                hotspotId: "divHotspots0_1",
                action: "popup",
                accessText: "Product Documentation link"
            }],
            PageLoadPopup: {
                popupBtnId: "tk-element-button223",
                action: "close"
            },
            SuccessPopup: {
                popupBtnId: "k-element-button224",
                action: "next"
            }
        },
        23: {
            NextPageId: 24,
            HotspotSettings: [{
                imageId: "tk-element-image232",
                hotspotId: "divHotspots0_1",
                action: "next",
                accessText: "OpenOffice Wiki: Documentation area link"
            }],
            PageLoadPopup: {
                popupBtnId: "tk-element-button233",
                action: "close"
            }
        },
        24: {
            NextPageId: 25,
            HotspotSettings: [{
                imageId: "tk-element-image242",
                hotspotId: "divHotspots0_1",
                action: "popup",
                accessText: "Apache OpenOffice 4.1 Writer for Students in English, Chinese, French, and German link"
            }],
            SuccessPopup: {
                popupBtnId: "k-element-button244",
                action: "next"
            }
        },
        25: {
            NextPageId: 31,
            HotspotSettings: [{
                imageId: "tk-element-image252",
                hotspotId: "divHotspots0_1",
                action: "popup",
                accessText: "FAQ link"
            }, {
                imageId: "tk-element-image252",
                hotspotId: "divHotspots0_2",
                action: "popup",
                accessText: "Frequently Asked Question"
            }],
            PageLoadPopup: {
                popupBtnId: "tk-element-button253",
                action: "close"
            },
            SuccessPopup: {
                popupBtnId: "k-element-button254",
                action: "next"
            }
        },
        31: {
            NextPageId: 39,
            HotspotSettings: [{
                imageId: "tk-element-image312",
                hotspotId: "divHotspots0_1",
                action: "next",
                accessText: "Back button"
            }],
            PageLoadPopup: {
                popupBtnId: "tk-element-button313",
                action: "close"
            },
        },
        39: {
            NextPageId: 40,
            HotspotSettings: [{
                imageId: "tk-element-image392",
                hotspotId: "divHotspots0_1",
                action: "next",
                accessText: "Download link"
            }],
        },
        40: {
            NextPageId: 41,
            HotspotSettings: [{
                imageId: "tk-element-image402",
                hotspotId: "divHotspots0_1",
                action: "popup",
                accessText: "System Requirements link"
            }],
            SuccessPopup: {
                popupBtnId: "k-element-button404",
                action: "next"
            }
        },
        41: {
            NextPageId: 42,
            HotspotSettings: [{
                imageId: "tk-element-image412",
                hotspotId: "divHotspots0_1",
                action: "next",
                accessText: "File Explorer Icon"
            }],
            PageLoadPopup: {
                popupBtnId: "tk-element-button413",
                action: "close"
            }
        },
        42: {
            NextPageId: 43,
            HotspotSettings: [{
                imageId: "tk-element-image422",
                hotspotId: "divHotspots0_2",
                action: "next",
                accessText: "System properties button"
            }],
        },
        43: {
            NextPageId: 44,
            HotspotSettings: [{
                imageId: "tk-element-image432",
                hotspotId: "divHotspots0_1",
                action: "popup",
                accessText: "Installed memory (RAM)"
            }],
            SuccessPopup: {
                popupBtnId: "k-element-button434",
                action: "next"
            }
        },
        44: {
            NextPageId: 45,
            HotspotSettings: [{
                imageId: "tk-element-image442",
                hotspotId: "divHotspots0_1",
                action: "next",
                accessText: "Back button"
            }],
            PageLoadPopup: {
                popupBtnId: "tk-element-button443",
                action: "close"
            }
        },
        45: {
            NextPageId: 46,
            HotspotSettings: [{
                imageId: "tk-element-image452",
                hotspotId: "divHotspots0_1",
                action: "popup",
                accessText: "Local Disk (C:)"
            }],
            SuccessPopup: {
                popupBtnId: "k-element-button454",
                action: "next"
            }
        },
        46: {
            NextPageId: 47,
            HotspotSettings: [{
                imageId: "tk-element-image462",
                hotspotId: "divHotspots0_1",
                action: "next",
                accessText: "Microsoft Edge icon"
            }],
            PageLoadPopup: {
                popupBtnId: "tk-element-button463",
                action: "close"
            },
        },
        47: {
            NextPageId: 55,
            HotspotSettings: [{
                imageId: "tk-element-image472",
                hotspotId: "divHotspots0_1",
                action: "popup",
                accessText: "Download full installation button"
            }],
            SuccessPopup: {
                popupBtnId: "k-element-button474",
                action: "next"
            }
        }
    }


    _popupWidthCheckPoint = 460;

    //Private Functions, accessible only inside ITSimModule.

    function SetPageScore() {
        if (isReview)
            return;
        var totalScore = 0;
        debugger;
        for (var i = 0; i < pagesDataArray.length; i++) {
            var score = 0;
            var currentPageScore = Number(pagesDataArray[i].Score);

            score += GetHintScore(pagesDataArray[i].GroupName, i);
            score += GetStepByStepScore(pagesDataArray[i].GroupName, i);


            score += currentPageScore;
            pagesDataArray[i].ScoreObtained = score;
            totalScore += score;
        }
        simTotalScore = totalScore;
        //$(".SimPageScoreField p").html("<span style='color:white; font-size:13px;font-family:\"Open Sans\"'>" + STR_Score + simTotalScore + "</span>");
        Utility.replaceText('.SimPageScoreField', STR_Score + simTotalScore);
        Utility.replaceText('.SimPageProgressField', STR_ModuleProgress + $(".pagingText").find(".progressForeground").css("width"));
        $(".SimPageScoreField").attr({
            "aria-label": $(".SimPageScoreField").text()
        });
        $(".SimPageProgressField").attr({
            "aria-label": $(".SimPageProgressField").text()
        });
        fSetScoreForReviewMode();
    }
    //Get hint score only once if hint button pressed for same group
    function GetHintScore(gpname, oldI) {
        var hintScore = 0;
        for (var i = 0; i < pagesDataArray.length; i++) {
            if (pagesDataArray[i].GroupName == gpname) {
                if (pagesDataArray[i].IsHint && typeof pagesDataArray[i].HintScore !== 'undefined') {
                    if (i < oldI) {
                        break;
                    }
                    hintScore = pagesDataArray[i].HintScore;
                    break;
                }
            }
        }
        return hintScore;
    }
    //Get step by step score only once if step by step button pressed for same group
    function GetStepByStepScore(gpname, oldI) {
        var sbysScore = 0,
            scoreFound = false;
        for (var i = 0; i < pagesDataArray.length; i++) {
            if (pagesDataArray[i].GroupName == gpname) {
                if (i < oldI) {
                    // if no score
                    if (typeof pagesDataArray[i].StepByStepScore === 'undefined') {
                        continue;
                    } else {
                        scoreFound = true;
                    }
                }
                if (i > oldI) {
                    return 0;
                }
                // if score is present
                if (pagesDataArray[i].IsStepByStep && typeof pagesDataArray[i].StepByStepScore !== 'undefined') {
                    if (scoreFound) {
                        break;
                    }
                    sbysScore = pagesDataArray[i].StepByStepScore;
                    break;
                }
            }
        }
        return sbysScore;
    }

    function ApplyEmbeding() {

        var settings = PageSettings[gCurrPageObj.PageId];
        if (settings != undefined && settings.EmbedSettings != undefined && !Array.isArray(settings.EmbedSettings)) {
            var child = $("#" + settings.EmbedSettings.childId);
            var parent = $("#" + settings.EmbedSettings.parentId);
            if (parent.closest(".k-element-box").find(".EmbededElement").length <= 0) {
                var childTemplate = "";
                if (settings.EmbedSettings.type == "input") {
                    if (isReview) {
                        var reviewText = $("#" + settings.EmbedSettings.childId).html();
                        childTemplate = "<div class='EmbededElement OpenSansFont' style='font-size:12px;' type='text' placeholder='" + child.text() + "' embedfor='" + settings.EmbedSettings.childId + "'>" + reviewText + "</div>";
                    } else {
                        childTemplate = "<input class='EmbededElement OpenSansFont' style='font-size:12px;' type='text' placeholder='" + child.text() + "' embedfor='" + settings.EmbedSettings.childId + "'/>"
                    }
                }
                if (parent.closest(".k-element-box").attr("temptype") == "Image") {
                    //to handle image scroll autofocus issue
                    if (!k_DeviceManager.Is_Android_or_iOs()) {
                        if (($.browser.safari)) {
                            var imgTabi = parent.attr('tabindex');
                            parent.closest(".k-element-box").attr({
                                'tabindex': imgTabi,
                                'aria-label': parent.attr('asset-title')
                            });
                            parent.removeAttr('tabindex');
                            parent.removeAttr('alt');
                            parent.attr('aria-hidden', 'true');
                        }
                    }
                    //end
                    parent.after(childTemplate);
                    var newtop = child.closest(".k-element-box").position().top - parent.closest(".k-element-box").position().top;
                    var newleft = child.closest(".k-element-box").position().left - parent.closest(".k-element-box").position().left;
                    var newwidth = child.closest(".k-element-box").width();

                    parent.closest(".k-element-box").find(".EmbededElement").attr("style", child.closest(".k-element-box").attr("style"))
                    if (settings.EmbedSettings.cssstyle != undefined) {
                        if (settings.EmbedSettings.cssstyle.left != undefined)
                            newleft = settings.EmbedSettings.cssstyle.left;
                        if (settings.EmbedSettings.cssstyle.top != undefined)
                            newtop = settings.EmbedSettings.cssstyle.top;
                        if (settings.EmbedSettings.cssstyle.width != undefined)
                            newwidth = settings.EmbedSettings.cssstyle.width;
                    }
                    parent.closest(".k-element-box").find(".EmbededElement").attr("aria-hidden", "true");
                    parent.closest(".k-element-box").find(".EmbededElement").css({
                        "width": newwidth,
                        "top": newtop + "px",
                        "left": newleft + "px",
                        "border-width": "0px"
                    })
                    if (isReview) {
                        if (settings.ReviewTextId != undefined && $("#" + settings.ReviewTextId).length > 0) {
                            reviewbox = $("#" + settings.ReviewTextId).closest(".k-element-box");
                            reviewbox.css({
                                "left": newleft + "px",
                                "top": parseInt(newtop + 20) + "px"
                            })
                            parent.after(reviewbox);
                        }
                    }
                }
            }
            child.closest(".k-element-box").hide();
        }
    }

    function ApplyMultipleEmbeding() {
        debugger;
        var mode = k_DeviceManager.GetDeviceMode();
        $(".EmbededElement").remove();
        $(".clonedelement").remove();
        var settings = PageSettings[gCurrPageObj.PageId];
        if (settings != undefined && settings.EmbedSettings != undefined && Array.isArray(settings.EmbedSettings)) {
            for (var i = 0; i < settings.EmbedSettings.length; i++) {
                if (settings.ReviewTextId != undefined && settings.EmbedSettings[i].childId == settings.ReviewTextId && !isReview)
                    continue;
                var child = $("#" + settings.EmbedSettings[i].childId);
                var parent = $("#" + settings.EmbedSettings[i].parentId);
                //if (parent.closest(".k-element-box").find(".EmbededElement").length <= 0) {
                var childTemplate = "";
                if (settings.EmbedSettings[i].type == "image" || settings.EmbedSettings[i].type == "text" || settings.EmbedSettings[i].type == "droppable" || settings.EmbedSettings[i].type == "checklist") {
                    childTemplate = child.closest(".k-element-box").clone();
                    childTemplate.addClass("clonedelement")
                    child.closest(".k-element-box").addClass("originalelement");
                    if (settings.EmbedSettings[i].cloneId != undefined) {
                        if (settings.EmbedSettings[i].type == "checklist") {
                            childTemplate.find(".k-element-checklist").attr("id", settings.EmbedSettings[i].cloneId)
                        }
                    }
                }
                if (settings.EmbedSettings[i].type == "input") {

                    if (isReview) {
                        var reviewText = $("#" + settings.EmbedSettings[i].childId).html();
                        childTemplate = "<div class='EmbededElement OpenSansFont' style='font-size:12px;' type='text' placeholder='" + child.text() + "' embedfor='" + settings.EmbedSettings[i].childId + "'>" + reviewText + "</div>"

                    } else {
                        childTemplate = "<input class='EmbededElement OpenSansFont' style='font-size:12px;' type='text' placeholder='" + child.text() + "' embedfor='" + settings.EmbedSettings[i].childId + "'/>"
                    }
                }

                var imgTabi = parseInt(parent.attr('tabindex'));
                if (parent.closest(".k-element-box").attr("temptype") == "Image") {
                    //to handle image scroll autofocus issue
                    if (!k_DeviceManager.Is_Android_or_iOs()) {
                        if (($.browser.safari)) {
                            parent.closest(".k-element-box").attr({
                                'tabindex': imgTabi,
                                'aria-label': parent.attr('asset-title')
                            });
                            parent.removeAttr('tabindex');
                            parent.removeAttr('alt');
                            parent.attr('aria-hidden', 'true');
                        }
                    }
                    //end
                    parent.after(childTemplate);

                    var newtop = child.closest(".k-element-box").position().top - parent.closest(".k-element-box").position().top;
                    var newleft = child.closest(".k-element-box").position().left - parent.closest(".k-element-box").position().left;
                    var newwidth = child.closest(".k-element-box").width();

                    if (settings.EmbedSettings[i].type == "input")
                        parent.closest(".k-element-box").find(".EmbededElement").attr("style", child.closest(".k-element-box").attr("style"))
                    if (settings.EmbedSettings[i].cssstyle != undefined) {
                        if (settings.EmbedSettings[i].cssstyle.left != undefined) {
                            if (mode.Id == "default") {
                                newleft = ((settings.EmbedSettings[i].cssstyle.left / 760) * 100) + "%";
                            } else {
                                newleft = settings.EmbedSettings[i].cssstyle.left + "px";
                            }
                        }
                        if (settings.EmbedSettings[i].cssstyle.top != undefined) {
                            if (mode.Id == "default") {
                                newtop = ((settings.EmbedSettings[i].cssstyle.top / 597) * 100) + "%";
                            } else {
                                newtop = settings.EmbedSettings[i].cssstyle.top + "px";
                            }
                        }
                        if (settings.EmbedSettings[i].cssstyle.width != undefined)
                            newwidth = settings.EmbedSettings[i].cssstyle.width;

                    }

                    //parent.closest(".k-element-box").find(".EmbededElement").attr("aria-hidden", "true");
                    if (settings.EmbedSettings[i].type == "input") {
                        parent.closest(".k-element-box").find(".EmbededElement").css({
                            "width": newwidth,
                            "top": newtop,
                            "left": newleft,
                            "border-width": "0px"
                        });
                        parent.closest(".k-element-box").find(".EmbededElement").attr({
                            "tabindex": parseInt(imgTabi + i + 1)
                        });
                        child.closest(".k-element-box").hide();
                    } else {
                        // childTemplate = parent.closest(".k-element-box").find("#" + settings.EmbedSettings[i].childId).closest(".k-element-box");

                        $(".originalelement").hide();
                        $(".clonedelement").show();

                        childTemplate.css({
                            "width": newwidth,
                            "top": newtop,
                            "left": newleft
                        });
                        if (settings.EmbedSettings[i].type == "checklist") {
                            childTemplate.removeAttr("tabindex");
                            childTemplate.find("input[type='checkbox']").each(function () {
                                $(this).attr("tabindex", parseInt(imgTabi + i + 1))
                            })

                        } else {
                            childTemplate.attr({
                                "tabindex": parseInt(imgTabi + i + 1),
                                "aria-label": settings.EmbedSettings[i].arialabel
                            });
                        }
                    }




                }
                //}
            }

        }
    }

    function ApplyWrapperToButtonImg() {
        var _QLOptions = $(".k-element-box[temptype='Button']:visible");
        if (_QLOptions.length > 1) {
            for (var i = 0; i < _QLOptions.length; i++) {
                var imgObj = $(_QLOptions[i]).find("img.lblImg:visible");
                if (imgObj.length > 0) {
                    var imgwrapper = "<span class='btnImgWrapper' style='float:left;'>" + imgObj.get(0).outerHTML + "</span>";
                    if (imgObj.closest("span.btnImgWrapper").length <= 0) {
                        imgObj.replaceWith(imgwrapper);
                    }
                }
            }
        }
    }

    function InitPageData() {
        if (isReview) {
            return;
        }
        var obj = {};
        var isPageAdded = false;
        obj.PageID = gCurrPageObj.PageId;
        obj.Score = 0;
        obj.GroupName = $(".SimPageStepByStepBtn").attr("groupname"); //need to check
        for (var i = 0; i < pagesDataArray.length; i++) {
            if (pagesDataArray[i].PageID == gCurrPageObj.PageId) {
                isPageAdded = true;
            }
        }
        if (!isPageAdded) {
            pagesDataArray.push(obj);
        }
    }

    function GetPageData(pageId) {
        var retObj;
        for (var i = 0; i < pagesDataArray.length; i++) {
            if (pageId == pagesDataArray[i].PageID) {
                retObj = pagesDataArray[i];
            }
        }
        return retObj;
    }

    function HandleCommonPageLoadFunctionality() {
        //Accessibility Set code
        //to handle iPAD issue for accessibility on question and summary page
        if ((gCurrPageObj.PageId == 55) && isIOS) {
            $(".SimPageHeadingLevel1").attr({
                "role": "heading",
                "aria-level": "1",
                "aria-label": $(".SimPageHeadingLevel1").text()
            });
        } else {
            $(".SimPageHeadingLevel1").attr({
                "role": "heading",
                "aria-level": "1",
                "aria-label": $(".SimPageHeadingLevel1").text()
            });
            $(".SimPageHeadingLevel2").attr({
                "role": "heading",
                "aria-level": "2",
                "aria-label": $(".SimPageHeadingLevel2").text()
            });
        }
        //if ((/Firefox[\/\s](\d+\.\d+)/.test(navigator.userAgent)) || isIE11version || (/Edge/.test(navigator.userAgent))) {
        $(".SimPageHintBtn").find(".k-element-button").attr({
            "role": "button",
            "aria-label": "Hint"
        });
        $(".SimPageStepByStepBtn").find(".k-element-button").attr({
            "role": "button",
            "aria-label": "Step by Step"
        });
        $(".SimPageScoreBtn").find(".k-element-button").attr({
            "role": "button",
            "aria-label": "About Scoring"
        });
        /*} else {
                $(".SimPageHintBtn").attr({
                    "role": "button",
                    "aria-label": "Hint"
                });
                $(".SimPageStepByStepBtn").attr({
                    "role": "button",
                    "aria-label": "Step by Step"
                });
                $(".SimPageScoreBtn").attr({
                    "role": "button",
                    "aria-label": "About Scoring"
                });
            }*/
        //end

        $(".divHotSpot").each(function () {
            //if edge then tabindex attached to its kbox
            if (navigator.userAgent.toLowerCase().indexOf('edge') > -1) {
                $(this).attr('tabindex', $(this).closest(".k-element-box").attr('tabindex'));
            } else {
                $(this).attr('tabindex', $(this).closest(".k-element-box").find('img').attr('tabindex'));
            }
            //$(this).attr('tabindex', $(this).closest(".k-element-box").find('img').attr('tabindex'));
        });
        debugger;
        //tabindex for image auto scroll focus issue
        var imgElem1 = $("#tk-element-image" + gCurrPageObj.PageId + "1");
        imgElem1.closest(".k-element-box").addClass('SimPageHeaderBgImg').css('overflow', 'hidden');

        if (!k_DeviceManager.Is_Android_or_iOs()) {
            if (($.browser.safari)) {
                var imgElem2 = $("#tk-element-image" + gCurrPageObj.PageId + "2");
                var imgTabi = imgElem2.attr('tabindex');
                imgElem2.closest(".k-element-box").attr({
                    'tabindex': imgTabi,
                    'aria-label': imgElem2.attr('asset-title')
                });
                imgElem2.removeAttr('tabindex');
                imgElem2.removeAttr('alt');
                imgElem2.attr('aria-hidden', 'true');

                //fix for accessibility reading issue when hotspot inside image
                var _box = $("#tk-element-image" + gCurrPageObj.PageId + "2").closest(".k-element-box");
                if (_box.length > 0) {
                    $(_box[0]).die("blur").live("blur", function (event) {
                        var settings = PageSettings[gCurrPageObj.PageId];
                        if (settings != undefined && settings.HotspotSettings != undefined) {
                            for (var x = 0; x < settings.HotspotSettings.length; x++) {
                                var setting = settings.HotspotSettings[x];
                                var hotspotid = $("#" + setting.hotspotId);
                                hotspotid.removeAttr("aria-hidden");
                                hotspotid.attr({
                                    "aria-label": setting.accessText
                                });
                            }
                        }
                        if (settings != undefined && settings.EmbedSettings != undefined) {
                            var parent = $("#" + settings.EmbedSettings.parentId);
                            parent.closest(".k-element-box").find(".EmbededElement").removeAttr("aria-hidden");
                        }
                    });

                    $(_box[0]).die("focus").live("focus", function (event) {
                        var settings = PageSettings[gCurrPageObj.PageId];
                        if (settings != undefined && settings.HotspotSettings != undefined) {
                            for (var x = 0; x < settings.HotspotSettings.length; x++) {
                                var setting = settings.HotspotSettings[x];
                                var hotspotid = $("#" + setting.hotspotId);
                                hotspotid.removeAttr("aria-label");
                                hotspotid.attr({
                                    "aria-hidden": "true"
                                });
                            }
                        }
                        if (settings != undefined && settings.EmbedSettings != undefined) {
                            var parent = $("#" + settings.EmbedSettings.parentId);
                            parent.closest(".k-element-box").find(".EmbededElement").attr("aria-hidden", "true");
                        }
                    });
                }
            }
        }
        //end

        var settings = PageSettings[gCurrPageObj.PageId];
        if (settings != undefined && settings.PageLoadPopup == undefined) {
            setTimeout(function () {
                $(".SimPageHeadingLevel2").focus();
            }, 0);
        }

        setTimeout(function () {
            $(".SimPageHeaderBgImg").removeAttr("tabindex").attr("aria-hidden", "true")
            $(".SimPageHeaderBgImg").find(".k-element-image").removeAttr("tabindex").attr("aria-hidden", "true")
            $("#tk-element-image11").removeAttr("tabindex").attr("aria-hidden", "true")
            $("#tk-element-image11").closest(".k-element-box").removeAttr("tabindex").attr("aria-hidden", "true")
        }, 200);
    }

    function GetTotalSimScore() {
        return simTotalScore;
    }
    return {
        // Properties
        //Get review data 
        //NM-Revel Integration Changes
        SetCompletionStatus: function (p_status) {
            completionStatus = p_status;
        },
        GetCompletionStatus: function (p_status) {
            return completionStatus;
        },
        GoToBookmarkPage: function () {
            if (bookmarkPage != undefined
                && (bookmarkPage + "") != ""
                && (bookmarkPage + "") != (gCurrPageObj.PageId + "")) {

                var lastvisitedPage = GetPage(bookmarkPage)
                if (lastvisitedPage != undefined) {
                    setTimeout(function () { GotoPageId(bookmarkPage); }, 100);
                }
            }
        },
        //End-Revel
        SetScore: function (scoreobj) {
            totalScore = scoreobj;
        },
        GetScore: function () {
            return totalScore;
        },
        GetAllPagesData: function () {
            return pagesDataArray;
        },
        GetReviewData: function () {
            return reviewData;
        },
        GetReviewDataForPage: function () {
            if (reviewData != undefined && reviewData.length > 0) {
                for (var i = 0; i < reviewData.length; i++) {
                    if (reviewData[i].pageId == gCurrPageObj.PageId) {
                        return reviewData[i];
                    }
                }
            }
        },
        SetReviewData: function (rData) {
            reviewData = rData;
        },
        SimTotalScore: function () {
            return GetTotalSimScore();
        },
        TestSimTotalScore: simTotalScore,
        // Functions
        GetScormString: function () { //to save to server
            /*
                  var scormString = '';
                  scormString += bookmarkPage + '###';
                  scormString += simTotalScore + '###';
                  scormString += JSON.stringify(pagesDataArray) + "###";
                  scormString += JSON.stringify(assessmentObj) + "###";
                  scormString += JSON.stringify(reviewData) + "###";
                  scormString += visitedNodesArray + "###";
                  scormString += JSON.stringify(totalScore) // gp added line to save total score  
                  return scormString;
                  */
            //NM-Revel Integration Changes
            var scormObject = {}
            scormObject.bookmarkPage = bookmarkPage;
            scormObject.simTotalScore = simTotalScore;
            scormObject.pagesDataArray = pagesDataArray;
            scormObject.assessmentObj = assessmentObj;
            scormObject.reviewData = reviewData;
            scormObject.visitedNodesArray = visitedNodesArray;
            scormObject.totalScore = totalScore;
            scormObject.completionStatus = completionStatus;

            return JSON.stringify(scormObject);
            //End-Revel

        },
        SetScormString: function (scormString) { //to retrieve
            /*
                  var splittedString = scormString.split('###');
                  bookmarkPage = splittedString[0];
                  simTotalScore = splittedString[1];
                  pagesDataArray = JSON.parse(splittedString[2]);
                  assessmentObj = JSON.parse(splittedString[3])
                  this.SetReviewData(JSON.parse(splittedString[4]));
                  visitedNodesArray += splittedString[5];
                  this.SetScore(JSON.parse(splittedString[6])) // gp added line to set total score  
                  */
            //NM-Revel Integration Changes

            //RA-2Aug18_Code changed to handle suspend data error
            var isCorrect = true;
            try {
                var tempData = JSON.parse(scormString);
            } catch (expn) {
                isCorrect = false;
            }

            if (isCorrect) {
                var scormObject = JSON.parse(scormString);
                bookmarkPage = scormObject.bookmarkPage;
                simTotalScore = scormObject.simTotalScore;
                pagesDataArray = scormObject.pagesDataArray;
                assessmentObj = scormObject.assessmentObj;
                this.SetReviewData(scormObject.reviewData);
                visitedNodesArray += scormObject.visitedNodesArray;
                this.SetScore(scormObject.totalScore);
                completionStatus = scormObject.completionStatus;
            }

            return isCorrect;
            //End-Revel
        },
        BookmarkPage: function () {
            bookmarkPage = gCurrPageObj.PageId;
        },
        GetBookmarkPageId: function () {
            return bookmarkPage;
        },
        Init: function () {
            $('body').attr({
                "id": "thebody",
                "onmousedown": "document.getElementById('thebody').classList.add('no-focus');",
                "onkeydown": "document.getElementById('thebody').classList.remove('no-focus');"
            });
            this.AppendStyles();
        },
        OnPageLoad: function () {
            debugger;
            //Private Function Calls
            if (gCurrPageObj.PageId == 55) {
                updateAssessmentDataonPageLoad();
            }
            if (gCurrPageObj.PageId == 56) {
                updateAssessmentSummaryonPageLoad();
            }
            InitPageData();
            HandleCommonPageLoadFunctionality();
            ApplyEmbeding();
            ApplyMultipleEmbeding();
            this.ApplyHotspots();
            ApplyWrapperToButtonImg();
            SetPageScore();
            //Public Function Calls
            this.BookmarkPage();
            this.ProgressBar();
            this.ShowPageLoadPopup();
            fSetScoreForReviewMode();
            //RA-1Nov17 - default focus to heading on module load
            if (disableHintStepButtonArray.indexOf(parseInt(gCurrPageObj.PageId)) >= 0 || isReview) {
                $(".SimPageHintBtn").addClass("disabled").css({ "opacity": "0.5" });
                $(".SimPageStepByStepBtn").addClass("disabled").css({ "opacity": "0.5" });
                $('.SimPageHintBtn').find(".k-element-button").attr({ "role": "button", "aria-disabled": "true" });
                $('.SimPageStepByStepBtn').find(".k-element-button").attr({ "role": "button", "aria-disabled": "true" });
            }
            if (gCurrPageObj.PageId == 1) {
                $('.IntroHeadingLevel1').focus();
                if (isReview) {
                    $("#tk-element-button11").closest(".k-element-box").addClass("disabled");
                    $("#tk-element-button11").closest(".k-element-box").css({ "opacity": "0.5" });
                }
            }
            UpdateCEPHotspots(gCurrPageObj);
            if (isReview)
                updateReviewFooterPos();


        },
        OnOrientaionChange: function () {
            if (IsRevel()) {
                //need logic to figureout width and height
                //LifeCycleEvents.OnResize({ width:0, height: 0 })
            }
            //Private Function Calls
            if (gCurrPageObj.PageId == 8) {
                CustomReviewModeForTextEntry()
            }
            HandleCommonPageLoadFunctionality();
            ApplyEmbeding();
            ApplyMultipleEmbeding();
            SetPageScore();
            //Public Function Calls
            this.ProgressBar();
            if (gCurrPageObj.PageId == 56) {
                updateSummaryScore();
            }
            if (gCurrPageObj.PageId == 55) {
                buildAssessmentQuestion();
            }
            if (disableHintStepButtonArray.indexOf(parseInt(gCurrPageObj.PageId)) >= 0 || isReview) {
                $(".SimPageHintBtn").addClass("disabled").css({ "opacity": "0.5" });
                $(".SimPageStepByStepBtn").addClass("disabled").css({ "opacity": "0.5" });
                $('.SimPageHintBtn').find(".k-element-button").attr({ "role": "button", "aria-disabled": "true" });
                $('.SimPageStepByStepBtn').find(".k-element-button").attr({ "role": "button", "aria-disabled": "true" });
            }
            if (gCurrPageObj.PageId == 1) {
                $("#tk-element-button11").attr("role", "button");
                $("#tk-element-button13").attr("role", "button");
            }
            //RA-1Nov17 - Fix overlay height/width issue on resize
            var wrapperLeft = $(".pageWrapper")[0].offsetLeft;
            var wrapperWidth = $(".pageWrapper")[0].scrollWidth;
            $("#fancybox-overlay").css({
                "left": wrapperLeft + "px",
                "width": wrapperWidth + "px"
            });
            UpdateCEPHotspots(gCurrPageObj);
            if (isReview)
                updateReviewFooterPos()
        },
        ProgressBar: function () {
            debugger;
            //RA-1Nov17 - Fix double progress bar on bookmark
            $(".SimPageProgressField").find(".progressBackground").remove();
            $(".BrandingBarContainer, .BrandingBarClone").hide();
            var progressBar = $(".progressBackground").clone();
            progressBar.attr("id", "progressBackground");
            progressBar.removeAttr('title');
            var mode = k_DeviceManager.GetDeviceMode();
            if (mode.Abbr == "i8") {
                progressBar.css("width", 120);
            } else {
                progressBar.css("width", 140);
            }
            //if ($(".SimPageProgressField").find(".progressBackground").length > 0) {
            //    $(".SimPageProgressField").find(".progressBackground").remove();
            //}
            $(".SimPageProgressField").find(".k-element-text").append(progressBar);
        },
        UseHint: function () {
            //NM-Revel Integration Changes
            if (IsRevel()) {
                LifeCycleEvents.OnInteraction("Hint button click.")
            }
            var retObj = GetPageData(gCurrPageObj.PageId);
            if (!retObj.IsHint) {
                retObj.IsHint = true;
                if (!isNaN(Number($(".SimPageHintBtn").attr('score'))))
                    retObj.HintScore = Number($(".SimPageHintBtn").attr('score'));
            }
            SetPageScore();
        },
        UseStepByStep: function () {
            //NM-Revel Integration Changes
            if (IsRevel()) {
                LifeCycleEvents.OnInteraction("Step-By-Step button click.")
            }
            var retObj = GetPageData(gCurrPageObj.PageId);
            if (!retObj.IsStepByStep) {
                retObj.IsStepByStep = true;
                if (!isNaN(Number($(".SimPageStepByStepBtn").attr('score'))))
                    retObj.StepByStepScore = Number($(".SimPageStepByStepBtn").attr('score'));
            }
            SetPageScore();
        },
        UpdatePageData: function (pageID, componentID, score) {
            var retObj = GetPageData(pageID);
            if (retObj) {
                retObj.ComponentID = componentID;
                retObj.Score = score;
            }
            SetPageScore();
        },
        AppendStyles: function () {
            var css = "";
            css += ".progressBackground{margin-top:-23px;height: 6px;}";
            css += "[device='iPhone6PlusLandscape'] .progressBackground{margin:-23px 0 0 10px;height: 6px;}";
            css += "body[device='iPhone6PlusPortrait'] .progressBackground{}";

            //NM - 21-08-2017 - accessibility change
            css += ".restOftheContent{border: 1px solid rgb(134, 134, 134) !important;}";
            //NM - 21-08-2017 - accessibility change - need to identify if it required to enable below css. Qualsim is having it.
            //css += ".restOftheContent{margin-top: -1px;}";

            css += ".SimPageHintBtn, .SimPageStepByStepBtn{border-radius:3px !important;}";
            //NM - 21-08-2017 - accessibility change - set score field Color.
            css += ".SimPageScoreField{color:#FFFFFF;}";

            //End - explicit outline.
            if ((/Firefox[\/\s](\d+\.\d+)/.test(navigator.userAgent))) {
                css += "body{overflow-x: hidden;overflow-y: auto;}.CaseTitle{padding-top: 7px !important;}";
            }

            if (isIE11version == true) {
                css += "body{overflow-x: hidden;}";
            }

            css += ".levelfooterdiv {width: 500px;height: 33px;position: fixed;left: 0;right: 0;margin: 0 auto;background-color: transparent;text-align: center;z-index: 200;display: inline-block; bottom:10px; } span.menutitle {vertical-align: middle;top: -12px;position: relative;margin-left: -15px;font-size: 18px;font-family: Arial Narrow;}.navBtn {cursor: pointer;width: 20px;height: 100%;display: inline-block;background-color: #1a76cb;text-align: center;padding: 8px;height: 17px;font-size: 17px; } .boxleveldropdown {cursor: pointer;width: 100px;height: 100%;display: inline-block;background-color: #1a76cb;text-align: center;padding: 18px 8px 0px 8px;height: 15px;font-size: 16px;font-family: Arial Narrow;}.navBtn.prev {border-top-left-radius: 7px;border-bottom-left-radius: 7px;} .navBtn.prev a {background: url(/assets/145/images/back-arrow.png) no-repeat;display: block;height: 13px;width: 13px;margin: 3px 5px; }.navBtn.next { border-top-right-radius: 7px;border-bottom-right-radius: 7px;} .navBtn.next a {background: url(/assets/145/images/next-arrow.png) no-repeat;display: block;height: 13px;width: 13px;margin: 3px 7px; } .levelmenu li, .levelmenu ul, ul.levelmenu {list-style-type: none;margin: 0;padding: 0;}ul.levelmenu {display: inline-block;position: relative;list-style: none;max-width: 80px;cursor: pointer;color: #FFFFFF;text-decoration: none;font-weight: 700; } .levelsubMenu{display: block;text-align: center;line-height: 1.4em;font-weight: normal;white-space: nowrap;position: absolute;background-color: #1a76cb;color: #FFF;z-index: 1000;padding: 10px;text-align: center;width: 177px;border-radius: 5px;margin-top: -102px;margin-left: -36px;width: 150px;height: 40px;}.menuArrow {background: url(/assets/145/images/up-arrow.png) no-repeat;display: inline-block;height: 13px;width: 13px;position: relative;margin-left: 10px;position: absolute;margin-top: -5px; }";

            Utility.injectCss(css);

        },
        ApplyHotspots: function () {
            var settings = PageSettings[gCurrPageObj.PageId];
            if (settings != undefined && settings.HotspotSettings != undefined) {
                for (var x = 0; x < settings.HotspotSettings.length; x++) {
                    var setting = settings.HotspotSettings[x];

                    var imageid = $("#" + setting.imageId);
                    var hotspotid = $("#" + setting.hotspotId);
                    var selector = '[imageid="' + setting.imageId + '"]#' + setting.hotspotId;
                    var _that = this;

                    //to handle image scroll autofocus issue
                    if (isIOS || isChrome || isIE11version || /Edge/.test(navigator.userAgent)) {
                        //$("#" + setting.imageId).insertAfter($("#" + setting.hotspotId));
                        //$("#" + setting.imageid).attr("z-index", "20");
                        $("#" + setting.hotspotId).attr("role", "button");
                    }
                    if (!k_DeviceManager.Is_Android_or_iOs()) {
                        if (($.browser.safari)) {
                            var imgTabi = imageid.attr('tabindex');
                            imageid.closest(".k-element-box").attr({
                                'tabindex': imgTabi,
                                'aria-label': imageid.attr('asset-title')
                            });
                            imageid.removeAttr('tabindex');
                            imageid.removeAttr('alt');
                            imageid.attr('aria-hidden', 'true');
                        }
                    }
                    //if (isIOS) {
                    //if (gCurrPageObj.PageId == 42) {
                    //    $("#" + setting.hotspotId).insertAfter($("#" + setting.imageId));
                    //    $("#" + setting.hotspotId).attr("z-index", "9999");
                    //}
                    //}
                    //end

                    //RA-6Sep17-to handle hotspot focus
                    if (!k_DeviceManager.Is_Android_or_iOs()) {
                        //if (isChrome) {
                        imageid.closest(".k-element-box").css("z-index", "0");
                        hotspotid.css("opacity", "1");
                        if (($.browser.safari)) {
                            hotspotid.attr({
                                "aria-hidden": true
                            });
                        } else {
                            hotspotid.attr({
                                "aria-label": setting.accessText
                            });
                        }
                        //}
                    } else {
                        hotspotid.attr({
                            "aria-label": setting.accessText
                        });
                    }
                    //end
                    //Bind event to image
                    $("#" + setting.imageId).closest('.k-element-box').find('.div-edit-properties1').off('click').on('click', function (event) {

                        AddEditPropertiesClick(event, $("#" + setting.imageId));
                    });
                    //Bind the event to hotspots
                    BindEventFunction(selector, function (event) {
                        //NM-Revel Integration Changes
                        if (IsRevel()) {
                            LifeCycleEvents.OnInteraction("Hotspot click.")
                        }
                        if (isReview) {
                            return false;
                        }
                        //call scorm function
                        AddHotspotClick(event, $(selector), $("#" + setting.imageId));
                        var simScore = 0;
                        var page = GetPage(gCurrPageObj.PageId);
                        for (var n12 = 0; n12 < page.ImageHotspots.length; n12++) {
                            for (var n13 = 0; n13 < page.ImageHotspots[n12].Hotspots.length; n13++) {
                                if (page.ImageHotspots[n12].Hotspots[n13].score != "") {
                                    simScore = page.ImageHotspots[n12].Hotspots[0].score;
                                }
                            }
                        }
                        ITSimModule.UpdatePageData(gCurrPageObj.PageId, selector, simScore);
                        var settings = PageSettings[gCurrPageObj.PageId];
                        if (settings != undefined && setting != undefined) {
                            if (setting.action == "next") {
                                GotoPageId(settings.NextPageId);
                            }
                            if (setting.action == "popup") {
                                _that.ShowSuccessPopup();
                            }
                        }
                    });

                    //$("#" + setting.hotspotId).insertBefore($("#" + setting.imageId));
                }
            }
        },
        ShowPageLoadPopup: function () {
            if (isReview) {
                return false;
            }
            var settings = PageSettings[gCurrPageObj.PageId];
            if (settings != undefined && settings.PageLoadPopup != undefined) {
                var popBtn = $("#" + settings.PageLoadPopup.popupBtnId);
                popBtn.closest(".k-element-box").addClass("SimPagePopupBtn");
                popBtn.trigger('click');
            } else {
                $.fancybox.close();
            }
        },
        ShowSuccessPopup: function () {
            if (isReview) {
                return false;
            }
            var settings = PageSettings[gCurrPageObj.PageId];
            if (settings != undefined && settings.SuccessPopup != undefined) {
                var popBtn = $("#" + settings.SuccessPopup.popupBtnId);
                popBtn.closest(".k-element-box").addClass("SimPageSuccessPopupBtn");
                popBtn.trigger('click');
            }
        },
        SetPWCP: function (prmValue) {
            _popupWidthCheckPoint = prmValue;
        },
        GetPWCP: function (prmValue) {
            return _popupWidthCheckPoint;
        },
        ShowPopup: function (_popupText, pageID, poptype) {
            if (isReview) {
                return false;
            }
            //NM-Revel Integration Changes
            if (IsRevel()) {
                LifeCycleEvents.OnFeedback()
            }
            var _this = this;
            var mode = k_DeviceManager.GetDeviceMode();
            var tPage = GetPage(pageID);
            var tmphtmlContent = GetTemplateString(tPage, $("#Template_CEP").html());
            var find = 'ui-draggable';
            tmphtmlContent = tmphtmlContent.replace(new RegExp(find, 'g'), '');
            var navcontent = $("<div>" + tmphtmlContent + "</div>");
            var pwcheckpoint = navcontent.find(".column").width();
            console.log(pwcheckpoint);
            _this.SetPWCP(pwcheckpoint);
            var width = mode.Width < pwcheckpoint ? "98%" : pwcheckpoint + "px";
            if ($("body").width() > pwcheckpoint && mode.Width < pwcheckpoint) {
                width = (((mode.Width * 98) / 100).toFixed(2)) + "px"
            }
            if (width != "98%") {
                navcontent.find(".column").css("width", width);
                navcontent.find(".band").css("width", width);
            }
            navcontent.find(".PopupText").html(_popupText); //#tk-element-text71

            $.fancybox({
                content: navcontent.html(),
                showCloseButton: false,
                centerOnScroll: false,
                hideOnOverlayClick: false,
                'width': width,
                'onComplete': function () {
                    if (isIE11version || (/Edge/.test(navigator.userAgent))) {
                        $(".PopupText").closest(".k-element-box").attr({
                            "role": "application"
                        });
                    } else {
                        if (!isChrome) {
                            $(".PopupText").closest(".k-element-box").attr({
                                "role": "text",
                                "aria-label": $(".PopupText").text()
                            });
                        }
                        else {
                            $(".PopupText").closest(".k-element-box").attr({
                                "role": "alert",
                                "aria-label": $(".PopupText").text()
                            });
                        }
                    }
                    $('#fancybox-content .band').css("width", "100%");
                    $('#fancybox-content .column').css("width", "100%");
                    var dmode = k_DeviceManager.GetDeviceMode();
                    var boxes = $('#fancybox-content .column').find(".k-element-box");
                    for (var i = 0; i < boxes.length; i++) {
                        var boxwdt = $(boxes[i]).width();
                        var percentwdt = (boxwdt / ITSimModule.GetPWCP() * 100).toFixed(2);
                        var boxleft = $(boxes[i]).position().left;
                        var percentleft = (boxleft / ITSimModule.GetPWCP() * 100).toFixed(2);
                        if ($(boxes[i]).attr("temptype") == "Button") {
                            if (dmode.Width < ITSimModule.GetPWCP()) {
                                percentleft = percentleft - 4;
                                percentwdt = percentwdt + 4;
                                $(boxes[i]).find("span.OpenSansFont").css({ "font-size": "14px" })
                            }
                        }
                        $(boxes[i]).css({ "width": percentwdt + "%", "left": percentleft + "%" })
                    }

                    $("#fancybox-wrap").find("div:visible").removeAttr("aria-hidden");
                    $("#fancybox-wrap").removeAttr("aria-hidden");
                    $(".pageWrapper").attr("aria-hidden", "true");
                    $("[aria-describedby]").removeAttr("aria-describedby");

                    $(".PopupNext").closest(".k-element-box").removeAttr("title");
                    $(".PopupNext").closest(".k-element-box").attr({
                        "role": "button",
                        "aria-label": "Next"
                    });

                    $('#fancybox-content').find(".k-element-strip, .k-asset-Resize, .block-controls, .comHght, .comWdt, .comPos, .colNum, .colWdt").remove();

                    var popuptextheight = $('.PopupText').outerHeight();
                    $(".PopupNext").css('top', popuptextheight + 15);

                    if (poptype.indexOf('SimPageSuccessPopupBtn') !== -1) {
                        BindEventFunction('.PopupNext', function (event) {
                            //NM-Revel Integration Changes
                            $(".pageWrapper").removeAttr("aria-hidden");
                            if (IsRevel()) {
                                LifeCycleEvents.OnInteraction("Popup close button click.")
                            }
                            var settings = PageSettings[gCurrPageObj.PageId];
                            if (settings != undefined && settings.SuccessPopup != undefined) {
                                if (settings.SuccessPopup.action == "next") {
                                    GotoPageId(settings.NextPageId);
                                }
                            }
                        });
                    } else {
                        BindEventFunction('.PopupNext', function (event) {
                            debugger;
                            //NM-Revel Integration Changes
                            $(".pageWrapper").removeAttr("aria-hidden");
                            if (IsRevel()) {
                                LifeCycleEvents.OnInteraction("Popup close button click.")
                            }
                            var settings = PageSettings[gCurrPageObj.PageId];
                            if (settings != undefined && settings.PageLoadPopup != undefined) {
                                if (settings.PageLoadPopup.action == "next") {
                                    GotoPageId(settings.NextPageId);
                                }
                                if (settings.PageLoadPopup.action == "close") {
                                    $(".popup2elements").removeClass("popup2elements");
                                    $(".popupelement").removeClass("popupelement")
                                    closeClicked = true;
                                    if (isIE11version || (/Edge/.test(navigator.userAgent))) {
                                        $.fancybox.close();
                                        setTimeout(function () {
                                            $(".SimPageHeadingLevel2").focus();
                                            closeClicked = false;

                                        }, 500);
                                    }
                                    else {
                                        setTimeout(function () {
                                            $.fancybox.close();
                                            setTimeout(function () {
                                                $(".SimPageHeadingLevel2").focus();
                                                closeClicked = false;
                                            }, 100)
                                        }, 50);
                                    }
                                }
                            } else {
                                closeClicked = true;
                                if (isIE11version || (/Edge/.test(navigator.userAgent))) {
                                    $.fancybox.close();
                                    setTimeout(function () {
                                        $(".SimPageHeadingLevel2").focus();
                                        closeClicked = false;

                                    }, 500);
                                }
                                else {
                                    setTimeout(function () {
                                        $.fancybox.close();
                                        setTimeout(function () {
                                            $(".SimPageHeadingLevel2").focus();
                                            closeClicked = false;
                                        }, 100)
                                    }, 50);
                                }
                            }
                        });
                    }

                    //Next btn height = 30 + (margin 10px + 10px) + (removed margin 10px + 10px)
                    var totalHeightOfPopup = 70 + popuptextheight;
                    $($(".column").get(1)).css("height", totalHeightOfPopup);
                    $($(".column").get(1)).closest(".band").css("height", totalHeightOfPopup);

                    //set the fancybox overlay properties
                    $('#fancybox-overlay').css({
                        'width': parseInt($('.column').css('width')),
                        'height': parseInt($('.column').css('height')) + 5,
                        'left': ($(window).width() - parseInt($('.column').css('width'))) / 2,
                    });
                    //set the fancybox wrap top
                    if (isAndroid) {
                        setTimeout(function () {
                            var screenHeight = $(window).height();
                            var columnHeight = parseInt($('.column').css('height'));
                            var popupHeight = parseInt($('#fancybox-wrap').css('height'));
                            var topValue = (parseInt($('.column').css('height')) - parseInt($('#fancybox-wrap').css('height'))) / 2;
                            var deviceTopValue = (parseInt(screenHeight) - parseInt(popupHeight)) / 2;

                            if ((popupHeight > screenHeight)) {
                                $('#fancybox-wrap').css({
                                    'top': 15,
                                    'bottom': 'auto'
                                });
                            } else {
                                $('#fancybox-wrap').css({
                                    'top': deviceTopValue,
                                    'bottom': 'auto'
                                });
                            }

                            var wrapperLeft = $(".pageWrapper")[0].offsetLeft;
                            var wrapperWidth = $(".pageWrapper")[0].scrollWidth;
                            $("#fancybox-overlay").css({ "left": wrapperLeft + "px", "width": wrapperWidth + "px" });
                        }, 0);
                    } else {
                        //setTimeout(function () {
                        var screenHeight = $(window).height();
                        var columnHeight = parseInt($('.column').css('height'));
                        var popupHeight = parseInt($('#fancybox-wrap').css('height'));
                        var topValue = (parseInt($('.column').css('height')) - parseInt($('#fancybox-wrap').css('height'))) / 2;
                        var deviceTopValue = (parseInt(screenHeight) - parseInt(popupHeight)) / 2;
                        if (isAndroid || isIOS) {
                            if ((popupHeight > screenHeight)) {
                                $('#fancybox-wrap').css({
                                    'top': 15,
                                    'bottom': 'auto'
                                });
                            } else {
                                $('#fancybox-wrap').css({
                                    'top': deviceTopValue,
                                    'bottom': 'auto'
                                });
                            }
                        } else {
                            if (topValue > 0) {
                                $('#fancybox-wrap').css({
                                    'top': topValue,
                                    'bottom': 'auto'
                                });
                            } else {
                                $('#fancybox-wrap').css({
                                    'top': 15,
                                    'bottom': 'auto'
                                });
                            }
                        }
                        var wrapperLeft = $(".pageWrapper")[0].offsetLeft;
                        var wrapperWidth = $(".pageWrapper")[0].scrollWidth;
                        $("#fancybox-overlay").css({ "left": wrapperLeft + "px", "width": wrapperWidth + "px" });
                        //}, 0);
                    }

                    $('#fancybox-content .column').find(".k-element-box").each(function () {
                        $(this).addClass("popupelement popup2elements");
                    })

                    if ((/Firefox[\/\s](\d+\.\d+)/.test(navigator.userAgent))) {
                        setTimeout(function () {
                            $(".SimPageHeadingLevel1").focus();
                        }, 100);
                        setTimeout(function () {
                            $('.PopupText').closest(".k-element-box").focus();
                        }, 200);
                    } else {
                        setTimeout(function () {
                            $('.PopupText').closest(".k-element-box").focus();
                            $("html, body").scrollTop(0);
                        }, 200);
                    }
                }
            });
            $('#fancybox-content').find(".k-element-strip, .k-asset-Resize, .block-controls, .comHght, .comWdt, .comPos, .colNum, .colWdt").remove();

        },
        ShowAboutScoringPopup: function (pageID) {
            //NM-Revel Integration Changes
            if (IsRevel()) {
                LifeCycleEvents.OnInteraction("About the scoring click.")
            }
            var _this = this;
            var mode = k_DeviceManager.GetDeviceMode();
            var tPage = GetPage(pageID);
            var tmphtmlContent = GetTemplateString(tPage, $("#Template_CEP").html());
            var find = 'ui-draggable';
            tmphtmlContent = tmphtmlContent.replace(new RegExp(find, 'g'), '');
            var navcontent = $("<div>" + tmphtmlContent + "</div>");
            var pwcheckpoint = navcontent.find(".column").width();
            console.log(pwcheckpoint);
            _this.SetPWCP(pwcheckpoint);
            var width = mode.Width < pwcheckpoint ? "98%" : pwcheckpoint + "px";
            if ($("body").width() > pwcheckpoint && mode.Width < pwcheckpoint) {
                width = (((mode.Width * 98) / 100).toFixed(2)) + "px"
            }
            if (width != "98%") {
                navcontent.find(".column").css("width", width);
                navcontent.find(".band").css("width", width);
            }

            $.fancybox({
                content: navcontent.html(),
                showCloseButton: false,
                centerOnScroll: false,
                hideOnOverlayClick: false,
                'width': width,
                'onComplete': function () {
                    $('#fancybox-content').css({
                        "width": "100%",
                        "border-width": 0
                    });
                    if (isIE11version || (/Edge/.test(navigator.userAgent))) {
                        $("#tk-element-text602").closest(".k-element-box").attr({
                            "tabindex": "1",
                            "aria-label": "heading," + $("#tk-element-text602").text()
                        });
                        $(".PopupText").closest(".k-element-box").attr({
                            "tabindex": "1",
                            "aria-label": "In this Simulation your score will be the average of the simulation activity and the quiz. If you use the Step-by-Step assistance, you will have 1 point deducted whenever it is used."
                        });
                    } else {
                        if (isSafari) {
                            $("#tk-element-text602").closest(".k-element-box").attr({
                                "role": "heading",
                                "tabindex": "1",
                                "aria-label": $("#tk-element-text602").text(),
                                "aria-level": "1"
                            });

                        }
                        else {
                            $("#tk-element-text602").closest(".k-element-box").attr({
                                "role": "heading",
                                "tabindex": "1",
                                "aria-label": $("#tk-element-text602").text()
                            });
                        }
                        $(".PopupText").closest(".k-element-box").attr({
                            "role": "text",
                            "tabindex": "1",
                            "aria-label": "In this Simulation your score will be the average of the simulation activity and the quiz. If you use the Step-by-Step assistance, you will have 1 point deducted whenever it is used."
                        });
                    }
                    $('#fancybox-content .band').css("width", "100%");
                    $('#fancybox-content .column').css("width", "100%");
                    var dmode = k_DeviceManager.GetDeviceMode();
                    var boxes = $('#fancybox-content .column').find(".k-element-box");
                    for (var i = 0; i < boxes.length; i++) {
                        var boxwdt = $(boxes[i]).width();
                        var percentwdt = (boxwdt / ITSimModule.GetPWCP() * 100).toFixed(2);
                        var boxleft = $(boxes[i]).position().left;
                        var percentleft = (boxleft / ITSimModule.GetPWCP() * 100).toFixed(2);
                        if ($(boxes[i]).attr("temptype") == "Button") {
                            if (dmode.Width < ITSimModule.GetPWCP()) {
                                percentleft = percentleft - 4;
                                percentwdt = percentwdt + 4;
                                $(boxes[i]).find("span.OpenSansFont").css({ "font-size": "14px" })
                            }
                        }
                        $(boxes[i]).css({ "width": percentwdt + "%", "left": percentleft + "%" })
                    }

                    $("#fancybox-wrap").find("div:visible").removeAttr("aria-hidden");
                    $("#fancybox-wrap").removeAttr("aria-hidden");
                    $(".pageWrapper").attr("aria-hidden", "true");
                    $("[aria-describedby]").removeAttr("aria-describedby");

                    $(".PopupNext").closest(".k-element-box").removeAttr("title");
                    $(".PopupNext").closest(".k-element-box").attr({
                        "role": "button",
                        "tabindex": "1",
                        "aria-label": "Close"
                    });

                    $('#fancybox-content').find(".k-element-strip, .k-asset-Resize, .block-controls, .comHght, .comWdt, .comPos, .colNum, .colWdt").remove();

                    var popuptextheight1 = $('#tk-element-text602').closest(".k-element-box").outerHeight();
                    var popuptextheight = $('.PopupText').outerHeight();
                    $(".PopupNext").css('top', popuptextheight + popuptextheight1 + 30);

                    BindEventFunction('.PopupNext', function () {
                        $(".pageWrapper").removeAttr("aria-hidden");
                        $.fancybox.close();
                        //NM-Revel Integration Changes
                        closeClicked = true;
                        if (IsRevel()) {
                            LifeCycleEvents.OnInteraction("Popup close button click.")
                        }
                        if (isIE11version || (/Edge/.test(navigator.userAgent))) {//gp fix for ie reading button after closing popup
                            if (gCurrPageObj.PageId == 1) {
                                setTimeout(function () {
                                    $(".IntroHeadingLevel1").focus();
                                    closeClicked = false;
                                }, 500);
                            } else {
                                setTimeout(function () {
                                    $(".SimPageHeadingLevel2").focus();
                                    closeClicked = false;
                                }, 500);
                            }
                        }
                        else {
                            if (gCurrPageObj.PageId == 1) {
                                setTimeout(function () {
                                    $(".IntroHeadingLevel1").focus();
                                    closeClicked = false;
                                }, 0);
                            } else {
                                setTimeout(function () {
                                    $(".SimPageHeadingLevel2").focus();
                                    closeClicked = false;
                                }, 0);
                            }
                        }
                    });

                    //Next btn height = 30 + margin 10px
                    var totalHeightOfPopup = 80 + popuptextheight + popuptextheight1;
                    $($(".column").get(1)).css("height", totalHeightOfPopup);
                    $($(".column").get(1)).closest(".band").css("height", totalHeightOfPopup);

                    //set the fancybox overlay properties
                    $('#fancybox-overlay').css({
                        'width': parseInt($('.column').css('width')),
                        'height': parseInt($('.column').css('height')) + 5,
                        'left': ($(window).width() - parseInt($('.column').css('width'))) / 2,
                    });
                    //set the fancybox wrap top
                    if (isAndroid) {
                        setTimeout(function () {
                            var screenHeight = $(window).height();
                            var columnHeight = parseInt($('.column').css('height'));
                            var popupHeight = parseInt($('#fancybox-wrap').css('height'));
                            var topValue = (parseInt($('.column').css('height')) - parseInt($('#fancybox-wrap').css('height'))) / 2;
                            var deviceTopValue = (parseInt(screenHeight) - parseInt(popupHeight)) / 2;
                            if ((popupHeight > screenHeight)) {
                                $('#fancybox-wrap').css({
                                    'top': 15,
                                    'bottom': 'auto'
                                });
                            } else {
                                $('#fancybox-wrap').css({
                                    'top': deviceTopValue,
                                    'bottom': 'auto'
                                });
                            }
                            var wrapperLeft = $(".pageWrapper")[0].offsetLeft;
                            var wrapperWidth = $(".pageWrapper")[0].scrollWidth;
                            $("#fancybox-overlay").css({ "left": wrapperLeft + "px", "width": wrapperWidth + "px" });
                        }, 0);
                    } else {
                        //setTimeout(function () {
                        var screenHeight = $(window).height();
                        var columnHeight = parseInt($('.column').css('height'));
                        var popupHeight = parseInt($('#fancybox-wrap').css('height'));
                        var topValue = (parseInt($('.column').css('height')) - parseInt($('#fancybox-wrap').css('height'))) / 2;
                        var deviceTopValue = (parseInt(screenHeight) - parseInt(popupHeight)) / 2;
                        if (isAndroid || isIOS) {
                            if ((popupHeight > screenHeight)) {
                                $('#fancybox-wrap').css({
                                    'top': 15,
                                    'bottom': 'auto'
                                });
                            } else {
                                $('#fancybox-wrap').css({
                                    'top': deviceTopValue,
                                    'bottom': 'auto'
                                });
                            }
                        } else {
                            if (topValue > 0) {
                                $('#fancybox-wrap').css({
                                    'top': topValue,
                                    'bottom': 'auto'
                                });
                            } else {
                                $('#fancybox-wrap').css({
                                    'top': 15,
                                    'bottom': 'auto'
                                });
                            }
                        }
                        var wrapperLeft = $(".pageWrapper")[0].offsetLeft;
                        var wrapperWidth = $(".pageWrapper")[0].scrollWidth;
                        $("#fancybox-overlay").css({ "left": wrapperLeft + "px", "width": wrapperWidth + "px" });
                        //}, 0);
                    }
                    $('#fancybox-content .column').find(".k-element-box").each(function () {
                        $(this).addClass("popupelement");
                    })
                    setTimeout(function () {
                        $("#tk-element-text602").closest(".k-element-box").focus();
                        $("html, body").scrollTop(0);
                        //$('.PopupText').closest(".k-element-box").focus();
                    }, 200);
                }

            });
            $('#fancybox-content').find(".k-element-strip, .k-asset-Resize, .block-controls, .comHght, .comWdt, .comPos, .colNum, .colWdt").remove();
        }
    };
})();

//Hint Button
$(".SimPageHintBtn, .SimPageStepByStepBtn, .SimPagePopupBtn, .SimPageSuccessPopupBtn, .SimPageScoreBtn").die('click').live('click', function (event) {
    if (!($(this).hasClass("SimPageScoreBtn")) && isReview) {
        return false;
    }
    if ($(this).hasClass("disabled") || $(this).find(".k-element-button").hasClass("disabled")) {
        return false;
    }
    if ($(this).hasClass("SimPageScoreBtn")) {
        ITSimModule.ShowAboutScoringPopup(60);
    } else {
        var fed = $(this).find(".k-element-button").attr("feedbacktext");
        var fedtemp = fed.replace("<p>", "<span>");
        fedtemp = fedtemp.replace("</p>", "</span>");
        ITSimModule.ShowPopup(fedtemp, 7, this.className);
    }

    if (this.className.indexOf('SimPageHintBtn') !== -1) {
        ITSimModule.UseHint();
    }
    if (this.className.indexOf('SimPageStepByStepBtn') !== -1) {
        ITSimModule.UseStepByStep();
    }
    if (this.className.indexOf('SimPageSuccessPopupBtn') !== -1) {
        //ITSimModule.UseStepByStep();
    }
    fSetScoreForReviewMode();
});

$(".SimPageHintBtn, .SimPageStepByStepBtn, .SimPagePopupBtn, .SimPageSuccessPopupBtn, .SimPageScoreBtn").die("keyup").live('keyup', function (event) {
    if (window.event) {
        key = window.event.keyCode;
    } else if (event) {
        key = event.keyCode;
    }
    if (key == 13) {
        $(this).trigger('click');
    }
});

//About Scoring Button
$("#tk-element-button13").die('click').live('click', function (event) {
    if ($(this).hasClass("disabled") || $(this).find(".k-element-button").hasClass("disabled")) {
        return false;
    }
    ITSimModule.ShowAboutScoringPopup(60);
});

$("#tk-element-button13").die("keyup").live('keyup', function (event) {
    if (window.event) {
        key = window.event.keyCode;
    } else if (event) {
        key = event.keyCode;
    }
    if (key == 13) {
        $(this).trigger('click');
    }
});

//NM - this section will contain events for embeded components only.
$("input.EmbededElement").die("keydown").live("keydown", function (event) {
    if ($(this).attr("disabled") || $(this).hasClass("disabled")) {
        event.preventDefault();
        return;
    }
    if (window.event) {
        key = window.event.keyCode;
    } else if (event) {
        key = event.keyCode;
    }
    if (key == 13) {
        if ($.trim($(this).val()) != "") {

            var pageReviewData;
            var found = false;


            var actualCompId = $(this).attr("embedfor");
            var _box = $("#" + actualCompId).closest(".k-element-box");
            var vcheck = _box.attr("validationcheck");
            var vtext = _box.attr("validationtext");
            var vtextarr = vtext.split("~~~")
            var isVRequired = false;
            if (vcheck == "true") {
                for (var i = 0; i < vtextarr.length; i++) {
                    if (($.trim(vtextarr[i])).toLowerCase() == ($.trim($(this).val())).toLowerCase()) {
                        isVRequired = true;
                        break;
                    }
                }
            } else {
                isVRequired = true;
            }

            var str = $.trim($(this).val());
            var reviewData = ITSimModule.GetReviewData();
            if (reviewData != undefined) {
                for (var r = 0; r < reviewData.length; r++) {
                    if (reviewData[r].pageId == gCurrPageObj.PageId) {
                        if (reviewData[r].textEntry.length < 2) {
                            reviewData[r].textEntry.push(str);
                        } else {
                            reviewData[r].textEntry.splice(0, 1);
                            reviewData[r].textEntry.push(str);
                        }
                        pageReviewData = reviewData[r];
                        found = true;
                    }
                }
            }

            if (!found) {
                var _obj = {};
                _obj.pageId = gCurrPageObj.PageId;
                _obj.textEntry = [str];
                _obj.isCorrect = true;
                reviewData.push(_obj);
                pageReviewData = _obj
            }

            ITSimModule.SetReviewData(reviewData);
            fSetScoreForReviewMode();


            if (isVRequired) {
                var simScore = 0;
                if (_box.attr("score") != undefined) {
                    simScore = Number(_box.attr("score"))
                }
                ITSimModule.UpdatePageData(gCurrPageObj.PageId, actualCompId, simScore);
                var settings = PageSettings[gCurrPageObj.PageId];
                if (settings != undefined) {
                    if (settings.action == "next") {
                        GotoPageId(settings.NextPageId);
                    }
                }
            }


        }
    }
});

function UpdateCEPHotspots(pageObj) {
    debugger;
    if (pageObj.ImageHotspots != undefined && pageObj.ImageHotspots.length != 0) {
        for (var j = 0; j <= pageObj.ImageHotspots.length - 1; j++) {
            var currImg = $("#" + pageObj.ImageHotspots[j].ImageId);
            if (pageObj.ImageHotspots[j].Hotspots != undefined && pageObj.ImageHotspots[j].Hotspots.length != 0) {
                for (var i = 0; i <= pageObj.ImageHotspots[j].Hotspots.length - 1; i++) {
                    var _compType = "image";
                    var hsId = pageObj.ImageHotspots[j].Hotspots[i].HotspotId;
                    var imgId = pageObj.ImageHotspots[j].ImageId.substring(pageObj.ImageHotspots[j].ImageId.indexOf(_compType));
                    var urlFields = "";
                    if (pageObj.ImageHotspots[j].Hotspots[i].URLType == "blank" || pageObj.ImageHotspots[j].Hotspots[i].URLType == "") {
                        urlFields = "data-URLType = 'none'";
                    } else if (pageObj.ImageHotspots[j].Hotspots[i].URLType == "URL") {
                        urlFields = "data-URLType = 'URL'  data-href='" + pageObj.ImageHotspots[j].Hotspots[i].URL + "'";
                    } else {
                        urlFields = "data-URLType = 'Knowd'  data-knowdId = '" + pageObj.ImageHotspots[j].Hotspots[i].URL + "'";
                    }
                    var scoreFields = "";
                    scoreFields = GetScoreFieldsForHotspot(pageObj.ImageHotspots[j].Hotspots[i]);
                    if (scoreFields == undefined || scoreFields == null) {
                        scoreFields = "";
                    }
                    var imgobj = currImg.closest(".k-element-box");
                    var orw = imgobj.attr("original-width")
                    var orh = imgobj.attr("original-height")

                    var pleft, ptop, pheight, pwidth;
                    pleft = pageObj.ImageHotspots[j].Hotspots[i].left;
                    ptop = pageObj.ImageHotspots[j].Hotspots[i].top;
                    pheight = pageObj.ImageHotspots[j].Hotspots[i].height;
                    pwidth = pageObj.ImageHotspots[j].Hotspots[i].width;
                    if ((pageObj.ImageHotspots[j].Hotspots[i].left + "").indexOf("px") != -1) {
                        pleft = getPerc(Number(pageObj.ImageHotspots[j].Hotspots[i].left.replace("px", "").replace("%", "")), orw) + "%";
                        ptop = getPerc(Number(pageObj.ImageHotspots[j].Hotspots[i].top.replace("px", "").replace("%", "")), orh) + "%";
                        pheight = getPerc(Number(pageObj.ImageHotspots[j].Hotspots[i].height.replace("px", "").replace("%", "")), orh) + "%";
                        pwidth = getPerc(Number(pageObj.ImageHotspots[j].Hotspots[i].width.replace("px", "").replace("%", "")), orh) + "%";
                    }
                    else if (imgobj.attr("showcontainer") == "True") {
                        ptop = parseInt(currImg.css('height'), 10) * parseFloat(ptop, 10) / 100 + 'px';
                        pleft = parseInt(currImg.css('width'), 10) * parseFloat(pleft, 10) / 100 + 'px';
                        pheight = parseInt(currImg.css('height'), 10) * parseFloat(pheight, 10) / 100 + 'px';
                        pwidth = parseInt(currImg.css('width'), 10) * parseFloat(pwidth, 10) / 100 + 'px';
                    }

                    $("#divHotspots" + j + "_" + hsId).css({ "left": pleft, "top": ptop, "height": pheight, "width": pwidth });
                }
            }
        }
    }
}
//End - embeded comp events.

function updateReviewFooterPos() {
    var tempWHeight = Number(window.innerHeight);
    var tempCHeight = parseInt($('.column').css('height'));
    if (tempWHeight > tempCHeight)
        $(".levelfooterdiv").css("top", (tempCHeight - 40) + "px");
    else if (tempWHeight < tempCHeight)
        $(".levelfooterdiv").css("top", (tempWHeight - 40) + "px");
    else
        $(".levelfooterdiv").css("top", (tempWHeight - 40) + "px");
}

var shiftTab = false;
var closeClicked = false;
$(".popupelement").die("blur").live("blur", function (event) {
    if (closeClicked)
        return;


    if ($(this).hasClass("popup2elements")) {
        var index = $(this).index(".popup2elements");
        var next = $(".popup2elements").get((index + 1))
        if (next != undefined) {
            next.focus()
        }
        else {
            var prev = $(".popup2elements").get((index - 1))
            prev.focus();
        }
    }
    else {
        var index = $(this).index(".popupelement");

        if (index == 0 && shiftTab) {
            if (gCurrPageObj.PageId == 1) {
                if (isChrome) {
                    setTimeout(function () {
                        $(".popupelement:nth-child(3)").focus();
                    }, 500);
                }
                else {
                    $(".popupelement:nth-child(3)").focus();
                }
            }
            else {
                $(".popupelement:last").focus();
            }
        }
        else {
            var next = $(".popupelement").get((index + 1))
            if (next == undefined && !shiftTab) {
                $(".popupelement:first").focus();
            }
        }
    }


});


$(".popupelement").die("keydown").live('keydown', function (event) {
    if (window.event) {
        key = window.event.keyCode;
    } else if (event) {
        key = event.keyCode;
    }

    if (key == 16) {
        shiftTab = true;
    }
});
$(".popupelement").die("keyup").live('keyup', function (event) {
    if (window.event) {
        key = window.event.keyCode;
    } else if (event) {
        key = event.keyCode;
    }

    if (key == 16) {
        shiftTab = false;
    }
});